"""
committer.py - Database writes for the ARxTracker Allocation Engine.

The only file in the allocation package that writes to the database.
Receives the result dict from engine.allocate_claims() and commits
three writes inside a single transaction:

    1. Updates Claim.current_owner for every assigned claim.
    2. Flips Claim.lifecycle_state from UNASSIGNED to NEW_UNWORKED.
    3. Creates a ClaimAssignment audit record for every assignment.
"""

from django.db import transaction
from django.utils import timezone

from core.models import Claim, ClaimAssignment, WorkUnit, User


def commit_assignments(
    allocation_result: dict,
    work_unit: WorkUnit,
    assigned_by: User | None = None,
) -> dict:
    """
    Write allocation engine results to the database.

    Takes the result dict from engine.allocate_claims() and:
      1. Sets Claim.current_owner for every assigned claim
      2. Flips Claim.lifecycle_state UNASSIGNED → NEW_UNWORKED
      3. Creates a ClaimAssignment record for each (append-only)

    Pre-write race condition guard:
      Before writing, filters for claims that are still in
      UNASSIGNED state with current_owner=None. Claims that
      were assigned by a concurrent run since the engine
      computed are silently skipped — never overwritten.

    All writes happen inside one transaction.atomic() block.
    Either every write commits, or none do.

    Args:
        allocation_result: The dict returned by engine.allocate_claims().
            Must contain "assignments" key: {claim_id: user_id, ...}
            Only the "assignments" field is used. All other fields
            (counts, unassigned_claim_ids, agents_at_capacity) are
            summary data for __init__.py — the committer ignores them.

        work_unit: The WorkUnit being allocated. Used for the
            ClaimAssignment FK and to derive work_unit.client
            for tenant isolation.

        assigned_by: The User who triggered this allocation run.
            None for scheduled/system runs. Stored on each
            ClaimAssignment for audit.

    Returns:
        {
            "claims_written": int,
            "claims_skipped": int,
            "assignments_created": int,
        }
    """
    assignments = allocation_result.get("assignments", {})

    if not assignments:
        return {
            "claims_written": 0,
            "claims_skipped": 0,
            "assignments_created": 0,
        }

    claim_ids = list(assignments.keys())
    client = work_unit.client

    with transaction.atomic():

        # ── Pre-write race condition guard ───────────────
        #
        # Between the time the engine ran and now, another
        # allocation run may have assigned some of these claims.
        # Filter for claims that are STILL unassigned.
        #
        # This is NOT business logic. It is a data integrity
        # guard. Claims that were already assigned are silently
        # skipped — never overwritten.
        #
        # select_for_update locks these rows for the duration
        # of the transaction. skip_locked=True means if another
        # concurrent transaction already locked a row, we skip
        # it rather than waiting (prevents deadlocks).

        still_unassigned_ids = set(
            Claim.objects.filter(
                work_unit=work_unit,
                id__in=claim_ids,
                current_owner__isnull=True,
                lifecycle_state=Claim.LifecycleState.UNASSIGNED,
            )
            .select_for_update(skip_locked=True)
            .values_list("id", flat=True)
        )

        # Filter assignments to only claims that passed the guard
        safe_assignments = {
            claim_id: agent_id
            for claim_id, agent_id in assignments.items()
            if claim_id in still_unassigned_ids
        }

        claims_skipped = len(assignments) - len(safe_assignments)

        if not safe_assignments:
            # Every claim was already assigned by a concurrent run
            return {
                "claims_written": 0,
                "claims_skipped": claims_skipped,
                "assignments_created": 0,
            }

        # ── Write 1 + 2: Claim.current_owner + lifecycle_state ─
        #
        # bulk_update with explicit update_fields. Never a full
        # model save — only touches current_owner and lifecycle_state.
        # No other field on the Claim is modified.

        now = timezone.now()

        claims_to_update = [
            Claim(
                id=claim_id,
                current_owner_id=agent_id,
                lifecycle_state=Claim.LifecycleState.NEW_UNWORKED,
                updated_at=now,
            )
            for claim_id, agent_id in safe_assignments.items()
        ]

        Claim.objects.bulk_update(
            claims_to_update,
            fields=["current_owner", "lifecycle_state", "updated_at"],
            batch_size=1000,
        )

        # ── Write 3: ClaimAssignment audit records ───────
        #
        # ClaimAssignment is append-only (save() raises on
        # update, delete() raises). Each record captures:
        # who was assigned, by whom, when, which bucket.
        #
        # bucket=ACTIVE because the allocation engine only
        # distributes into the Active Bucket.

        assignment_records = [
            ClaimAssignment(
                claim_id=claim_id,
                assigned_to_id=agent_id,
                assigned_by=assigned_by,
                work_unit=work_unit,
                client=client,
                bucket=ClaimAssignment.Bucket.ACTIVE,
            )
            for claim_id, agent_id in safe_assignments.items()
        ]

        ClaimAssignment.objects.bulk_create(
            assignment_records,
            batch_size=1000,
        )

    # ── Return write summary (outside transaction) ───────
    return {
        "claims_written": len(safe_assignments),
        "claims_skipped": claims_skipped,
        "assignments_created": len(assignment_records),
    }