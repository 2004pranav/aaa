"""
engine.py - The allocation algorithm for ARxTracker.

Distributes unowned claims to eligible AR agents using
most-loaded-first selection. Each claim goes to the agent
with the least free capacity, never pushing past 60.

ZERO Django imports. ZERO database access. ZERO logging.
Takes plain dicts in, returns a plain dict out.
"""

from core.services.allocation.exceptions import NoEligibleAgentsError

# Constants--------------------------------------------------------------------

DEFAULT_BUCKET_CAP: int = 60

# Priority tier sort key - P1 is highest priority (sorted first).
# The engine only sees tiers 1-5. P0 does not exist here.
_TIER_SORT_ORDER: dict[str, int] = {
    "P1": 1, "P2": 2, "P3": 3, "P4": 4, "P5": 5,
}



# Internal Helpers---------------------------------------------------------------

def _sort_pool(pool: list[dict]) -> list[dict]:
    """
    Defensive sort: priority_tier ASC (P1 first), then
    aging_days DESC (oldest first within each tier).

    The engine must be correct regardless of what the caller
    passes in. This is not a trust issue - it is a correctness
    guarantee. loader.py pre-sorts, but the engine does not 
    rely on that.
    """
    return sorted(
        pool,
        key=lambda c: (
            _TIER_SORT_ORDER.get(c["priority_tier"], 99),
            -(c.get("aging_days") or 0),
        ),
    )


def _build_agent_states(
        agents: list[dict],
) -> dict[str, dict]:
    """
    Create internal working copies of agent states.

    Each agent gets a state dict tracking:
        - current_load: the load value from loader.py
          (NEW_UNWORKED + FOLLOW_UP_DUE already in their bucket)
        - assigned_this_run: how many new claims the engine
          has given them during this run (starts at 0)
    
    Never mutates the input dicts
    """
    states = {}
    for agent in agents:
        agent_id = agent["user_id"]
        states[agent_id] = {
            "current_load": agent["current_load"],
            "assigned_this_run": 0,
        }
    return states


def _find_most_loaded_agent(
        agent_states: dict[str, dict],
        bucket_cap: int,
) -> str | None:
    """
    Find the eligible agent with the least free capacity
    (most loaded) who still has room below the cap.
    """
    best_agent = None
    best_free = bucket_cap + 1  # Higher than any possible value

    for agent_id, state in agent_states.items():
        effective_load = state["current_load"] + state["assigned_this_run"]
        free = bucket_cap - effective_load

        if free <= 0:
            continue  # Agent is full

        # Most-loaded-first: smallest free capacity wins
        if free < best_free:
            best_free = free
            best_agent = agent_id

    return best_agent


# Public Entry Point-------------------------------------------------------------

def allocate_claims(
        agents: list[dict],
        claims: list[dict],
        bucket_cap: int = DEFAULT_BUCKET_CAP,
) -> dict:
    """
    The allocation engine's sole entry point.

    Distributes unowned claims to agents using most-loaded-first
    selection. Each claim goes to the agent with the least free
    capacity, never pushing past bucket_cap.

    Args:
        agents: Eligible AR agents with their current load.
            [{"user_id": "uuid-A", "current_load": 55},
             {"user_id": "uuid-B", "current_load": 30}, ...]
            
        claims: Unowned claims to distribute.
            [{"claim_id": "uuid-1", "priority_tier": "P1",
              "aging_days": 200}, ...]

        bucket_cap: Maximum Active Bucket size per agent.
            Defaults to 60. An agent's effective_load never 
            exceeds this.

    Returns: AllocationResult dict

    Raises: NoEligibleAgentsError if agents list is empty

    No logging. No side effects. No database access.
    Pure computation.
    """

    # Decision 1: Pre-condition check
    if not agents:
        raise NoEligibleAgentsError(
            "No eligible agents provided for allocation."
        )

    # Decision 2: Defensive sort
    sorted_claims = _sort_pool(claims)

    # Decision 3: Never mutate input
    agent_states = _build_agent_states(agents)

    # Distribution loop
    assignments: dict[str, str] = {}
    unassigned_claim_ids: list[str] = []

    for claim in sorted_claims:
        # Decision 4: Most-loaded-first selection
        best_agent = _find_most_loaded_agent(agent_states, bucket_cap)

        if best_agent is None:
            # Decision 7: Unassigned is valid output
            unassigned_claim_ids.append(claim["claim_id"])
            continue

        # Decision 5: 60-cap enforcement
        # _find_most_loaded_agent already enforces free > 0.
        # Incrementing assigned_this_run updates the effective
        # load for the next iteration's selection
        assignments[claim["claim_id"]] = best_agent
        agent_states[best_agent]["assigned_this_run"] += 1

    # Decision 11: Result dict construction
    agents_at_capacity = [
        agent_id
        for agent_id, state in agent_states.items()
        if (state["current_load"] + state["assigned_this_run"]) >= bucket_cap
    ]

    return {
        "assignments": assignments,
        "claims_assigned": len(assignments),
        "claims_unassigned": len(unassigned_claim_ids),
        "unassigned_claim_ids": unassigned_claim_ids,
        "agents_at_capacity": agents_at_capacity,
    }

