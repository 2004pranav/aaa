"""
Custom exceptions for the ARxTracker Allocation Engine.

These are raised by the allocation package when the engine
encounters a condition that prevents correct claim distribution
"""

class AllocationError(Exception):
    """
    Base exception for all allocation engine errors

    Raised when the engine encounters any problem that prevents
    correct claim distribution - whether from missing agents,
    invalid input data, or constraint violations.

    All allocation exceptions inherit from this class so callers
    can catch AllocationError to handle every allocation failure 
    in one except block
    """
    pass


class NoEligibleAgentsError(AllocationError):
    """
    Raised when no AR agents are eligible for allocation in
    the requested WorkUnit.

    This means one of:
        - No users with role=AR exist in the system
        - No AR users have an active UserWorkUnitMapping
          for this WorkUnit
        - All mapped AR users have is_active=False 
    """
    pass