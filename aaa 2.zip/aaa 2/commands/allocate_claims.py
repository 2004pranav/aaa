"""
Management command to run the daily allocation workflow for a WorkUnit.

Usage:
    # Full run - surface follow-ups, then allocate unowned claims:
    py manage.py allocate_claims --work-unit=<uuid>

    # Dry run - preview without writing to DB:
    py manage.py allocate_claims --work-unit=<uuid> --dry-run

    # Project-scope run — allocate only claims in a specific project:
    py manage.py allocate_claims --work-unit=<uuid> --project=<uuid>

Purpose:
    This command runs two independent steps in sequence:

    Step 1 - Follow-Up Surfacing:
        Flips Claim.lifecycle_state from FOLLOW_UP_SCHEDULED to
        FOLLOW_UP_DUE for claims whose next_follow_up_date has arrived.
        Must run before allocation so load_agent_loads() sees the 
        correct FOLLOW_UP_DUE count.

    Step 2 - Allocation Engine:
        Distributes unowned claims to AR agents using most-loaded-first
        selection. Each claim goes to the agent with the least free 
        capacity, never past the 60-cap. Flips lifecycle_state from
        UNASSIGNED to NEW_UNWORKED and creates ClaimAssignment records.
"""

import time

from django.core.management.base import BaseCommand, CommandError
from django.db import OperationalError

from core.models import WorkUnit, Project
from core.services.followup import run_surfacing
from core.services.allocation import run_allocation
from core.services.allocation.engine import DEFAULT_BUCKET_CAP
from core.services.allocation.exceptions import NoEligibleAgentsError


class Command(BaseCommand):
    help = (
        "Run the daily allocation workflow for a WorkUnit: "
        "surface follow-ups (Step 1), then allocate unowned claims "
        "(Step 2). Use --dry-run to preview without writing."
    )

    # Argument Definitions

    def add_arguments(self, parser):
        parser.add_argument(
            "--work-unit",
            required=True,
            dest="work_unit_id",
            help="UUID of the WorkUnit to run allocation for.",
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            default=False,
            dest="dry_run",
            help=(
                "Preview the allocation without writing to the database. "
                "Both surfacing and allocation run in dry-run mode. "
                "Safe to run at any time."
            ),
        )
        parser.add_argument(
            "--project",
            required=False,
            default=None,
            dest="project_id",
            help=(
                "UUID of a Project to scope the allocation to. "
                "Only claims tagged to this Project will be distributed. "
                "Omit for the daily run (all unowned non-project claims)."
            ),
        )
        parser.add_argument(
            "--skip-surfacing",
            action="store_true",
            default=False,
            dest="skip_surfacing",
            help=(
                "Skip the Follow-Up Surfacing step. Use only when "
                "surfacing was already run separately or when re-running "
                "allocation after a failed previous attempt."
            ),
        )

    # Entry Point

    def handle(self, *args, **options):
        total_start = time.time()

        work_unit_id = options["work_unit_id"]
        dry_run = options["dry_run"]
        project_id = options["project_id"]
        skip_surfacing = options["skip_surfacing"]

        # Resolve WorkUnit
        try:
            work_unit = (
                WorkUnit.objects
                .select_related("client", "process", "sub_process")
                .get(id=work_unit_id, is_active=True)
            )
        except WorkUnit.DoesNotExist:
            raise CommandError(
                f"WorkUnit '{work_unit_id}' not found or is inactive.\n"
                f"To list active WorkUnits:\n"
                f"  py manage.py shell -c \""
                f"from core.models import WorkUnit; "
                f"[print(str(w.id), '|', w) for w in "
                f"WorkUnit.objects.filter(is_active=True)]\""
            )

        # Resolve Project (optional)
        project = None
        if project_id:
            try:
                project = Project.objects.get(
                    id=project_id,
                    work_unit=work_unit,
                    status=Project.Status.ACTIVE,
                )
            except Project.DoesNotExist:
                raise CommandError(
                    f"Project '{project_id}' not found, not active, "
                    f"or does not belong to WorkUnit '{work_unit}'.\n"
                    f"To list active Projects for this WorkUnit:\n"
                    f"  py manage.py shell -c \""
                    f"from core.models import Project; "
                    f"[print(str(p.id), '|', p.name) for p in "
                    f"Project.objects.filter(work_unit_id='{work_unit_id}', "
                    f"status='active')]\""
                )

        # Print header
        self._print_header(work_unit, project, dry_run)

        # STEP 1: Follow-Up Surfacing
        surfacing_result = None

        if skip_surfacing:
            self.stdout.write(
                self.style.WARNING(
                    "  STEP 1 — Follow-Up Surfacing: SKIPPED (--skip-surfacing)"
                )
            )
            self.stdout.write("")
        else:
            try:
                surfacing_result = run_surfacing(
                    work_unit=work_unit,
                    dry_run=dry_run,
                )
            except OperationalError as e:
                self.stderr.write("")
                self.stderr.write(self.style.ERROR(
                    "  ✗ STEP 1 FAILED — DATABASE ERROR"
                ))
                self.stderr.write(self.style.ERROR(f"    {e}"))
                self.stderr.write("")
                raise CommandError(
                    "Follow-Up Surfacing failed. Allocation was NOT run."
                ) from e
            except Exception as e:
                self.stderr.write("")
                self.stderr.write(self.style.ERROR(
                    "  ✗ STEP 1 FAILED — UNEXPECTED ERROR"
                ))
                self.stderr.write(self.style.ERROR(
                    f"    {type(e).__name__}: {e}"
                ))
                self.stderr.write("")
                raise CommandError(
                    "Follow-Up Surfacing failed. Allocation was NOT run."
                ) from e

            self._print_surfacing_result(surfacing_result)

        # STEP 2: Allocation Engine
        try:
            allocation_result = run_allocation(
                work_unit=work_unit,
                project=project,
                dry_run=dry_run,
                assigned_by=None,
            )
        except NoEligibleAgentsError as e:
            self.stderr.write("")
            self.stderr.write(self.style.ERROR(
                "  ✗ STEP 2 FAILED — NO ELIGIBLE AGENTS"
            ))
            self.stderr.write(self.style.ERROR(f"    {e}"))
            self.stderr.write("")
            self.stderr.write(
                "  Assign AR users to this WorkUnit via "
                "UserWorkUnitMapping before running allocation."
            )
            self.stderr.write("")
            raise CommandError(
                "Allocation failed — no eligible agents."
            ) from e
        except OperationalError as e:
            self.stderr.write("")
            self.stderr.write(self.style.ERROR(
                "  ✗ STEP 2 FAILED — DATABASE ERROR"
            ))
            self.stderr.write(self.style.ERROR(f"    {e}"))
            self.stderr.write("")
            raise CommandError(
                "Allocation failed — database error."
            ) from e
        except Exception as e:
            self.stderr.write("")
            self.stderr.write(self.style.ERROR(
                "  ✗ STEP 2 FAILED — UNEXPECTED ERROR"
            ))
            self.stderr.write(self.style.ERROR(
                f"    {type(e).__name__}: {e}"
            ))
            self.stderr.write("")
            raise CommandError("Allocation failed.") from e

        # Print results
        self._print_allocation_result(allocation_result)

        # Footer
        total_elapsed = round(time.time() - total_start, 3)
        self._print_footer(total_elapsed)

    # Display Helpers

    def _print_header(self, work_unit, project, dry_run):
        self.stdout.write("")
        self.stdout.write(self.style.HTTP_INFO("=" * 60))
        self.stdout.write(self.style.HTTP_INFO(
            f"  ARxTracker — Daily Allocation Run"
            f"{'  (DRY RUN)' if dry_run else ''}"
        ))
        self.stdout.write(self.style.HTTP_INFO("=" * 60))
        self.stdout.write(f"  WorkUnit:     {work_unit}")
        self.stdout.write(f"  Client:       {work_unit.client.name}")
        self.stdout.write(f"  Bucket Cap:   {DEFAULT_BUCKET_CAP}")

        if project:
            self.stdout.write(f"  Project:      {project.name}")
        else:
            self.stdout.write(
                f"  Project:      (daily run — no project scope)"
            )

        if dry_run:
            self.stdout.write(self.style.WARNING(
                "  Mode:         DRY RUN — no writes"
            ))
        else:
            self.stdout.write(f"  Mode:         LIVE RUN")

        self.stdout.write(self.style.HTTP_INFO("-" * 60))
        self.stdout.write("")

    def _print_surfacing_result(self, result):
        self.stdout.write(
            self.style.HTTP_INFO("  STEP 1 — Follow-Up Surfacing")
        )

        if result["dry_run"]:
            self.stdout.write(
                f"  Would surface:    {result['candidates_found']}  "
                f"(SCHEDULED → DUE)"
            )
        else:
            self.stdout.write(
                f"  Claims surfaced:  {result['claims_surfaced']}  "
                f"(SCHEDULED → DUE)"
            )

        self.stdout.write(
            f"  Elapsed:          {result['elapsed_seconds']:.3f}s"
        )
        self.stdout.write("")
        self.stdout.write(self.style.HTTP_INFO("-" * 60))
        self.stdout.write("")

    def _print_allocation_result(self, result):
        self.stdout.write(
            self.style.HTTP_INFO("  STEP 2 — Allocation Engine")
        )
        self.stdout.write(
            f"  Agents eligible:  {result['agents_eligible']}"
        )
        self.stdout.write(
            f"  Pool size:        {result['pool_size']} unowned claims"
        )

        if result["dry_run"]:
            self.stdout.write(
                f"  Would assign:     {result['claims_assigned']}"
            )
            self.stdout.write(
                f"  Would leave:      {result['claims_unassigned']}  "
                f"(agents full)"
            )
        else:
            self.stdout.write(
                f"  Assigned:         {result['claims_assigned']}"
            )
            self.stdout.write(
                f"  Unassigned:       {result['claims_unassigned']}  "
                f"(agents full)"
            )
            self.stdout.write(
                f"  Written:          {result['claims_written']}"
            )
            self.stdout.write(
                f"  Skipped (race):   {result['claims_skipped']}"
            )

        cap_count = len(result["agents_at_capacity"])
        self.stdout.write(
            f"  Agents at cap:    {cap_count} / {result['agents_eligible']}"
        )
        self.stdout.write(
            f"  Elapsed:          {result['elapsed_seconds']:.3f}s"
        )
        self.stdout.write("")

    def _print_footer(self, total_elapsed):
        self.stdout.write(self.style.HTTP_INFO("-" * 60))
        self.stdout.write(f"  Total elapsed:    {total_elapsed:.3f}s")
        self.stdout.write(self.style.HTTP_INFO("=" * 60))
        self.stdout.write("")
