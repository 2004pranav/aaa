"""
ARxTracker — Django Admin Panel
=================================
Primary management and testing interface until the React frontend is built.

Organization:
  1. Inline Classes
  2. Foundation        — Client, User, Process, SubProcess
  3. WorkUnit Config   — WorkUnit, UserWorkUnitMapping
  4. Field Config      — StandardField, ColumnMapping,
                         ClaimIdentityRule, LineItemIdentityRule
  5. Action Config     — ActionType, SubActionType,
                         EscalationCategory, WorkUnitEscalationMapping
  5.5 Priority Config  — PriorityRule, PriorityConditionGroup,
                         PriorityCondition
  6. Ingestion         — FileUpload
  7. Core AR Data      — Claim, ClaimLineItem
  8. Workflow          — ClaimAssignment, FollowUpEvent, Escalation

Testing workflow (use this order to set up a WorkUnit for ingestion):
  Step 1   Create a Client
  Step 2   Create a Process  (e.g. "Accounts Receivable", code="AR")
  Step 3   Create a SubProcess  (e.g. "NPNR", code="NPNR")
  Step 4   Create a WorkUnit  (Client + Process + SubProcess + ingestion_mode)
  Step 5   Verify StandardField records exist (pre-populated)
  Step 6   Configure ColumnMappings on the WorkUnit
  Step 7   Configure ClaimIdentityRules on the WorkUnit
  Step 8   Configure LineItemIdentityRules on the WorkUnit (CPT-Level only)
  Step 9   Run the management command:
             python manage.py ingest_ar_file --file=path/to/file.xlsx
                                             --work-unit=<uuid>
  Step 10  Review FileUpload status, Claims, and ClaimLineItems here

Priority Rules Testing (run after Step 10):
  Step 11  Configure Priority Rules for the WorkUnit:
             a) Create a PriorityRule (e.g. P1 for this WorkUnit)
             b) Create PriorityConditionGroups under that rule
                (each group = one OR-branch)
             c) Create PriorityConditions under each group
                (each condition = one field/operator/value check)
  Step 12  Run the priority evaluation management command:
             python manage.py evaluate_priority_rules
                 --work-unit=<uuid> --dry-run
             Review the tier distribution. If correct, remove --dry-run.
  Step 13  Review Claims here — priority_tier should now reflect P1-P4.
             Filter by priority_tier in the Claims list view.
"""

from django.contrib import admin
from django.utils.html import format_html
from django.utils import timezone

from .models import (
    ActionType,
    Claim,
    ClaimAssignment,
    ClaimIdentityRule,
    ClaimLineItem,
    Client,
    ColumnMapping,
    EscalationCategory,
    Escalation,
    FileUpload,
    FollowUpSession,
    FollowUpEvent,
    LineItemIdentityRule,
    Process,
    StandardField,
    SubActionType,
    SubProcess,
    User,
    UserWorkUnitMapping,
    WorkUnit,
    WorkUnitEscalationMapping,
    ConfigChangeLog,
    PriorityCondition,          
    PriorityConditionGroup,      
    PriorityRule,
    Project,
    ProjectClaim,  
)


# ═══════════════════════════════════════════════════════════════════════════
# 1. INLINE CLASSES
# ═══════════════════════════════════════════════════════════════════════════


class ColumnMappingInline(admin.TabularInline):
    """
    Show column mappings directly inside the WorkUnit edit page.
    The Admin configures which source column maps to which standard field
    without needing to navigate away from the WorkUnit.
    """
    model = ColumnMapping
    extra = 1
    fields = ["source_column_name", "standard_field"]
    ordering = ["standard_field"]
    autocomplete_fields = ["standard_field"]


class ClaimIdentityRuleInline(admin.TabularInline):
    """
    Show claim identity rules directly inside the WorkUnit edit page.
    status is READ-ONLY here — every new rule automatically defaults
    to TRACKING on creation (Decision 8-A) and can only ever be
    promoted to ACTIVE through apply_identity_change(), via the
    change_identity_rules management command. There is no manual
    status picker, by design — this prevents bypassing the threshold
    check, recomputation, and audit log.
    """
    model = ClaimIdentityRule
    extra = 1
    fields = ["standard_field_name", "field_order", "status"]
    readonly_fields = ["status"]
    ordering = ["field_order"]


class LineItemIdentityRuleInline(admin.TabularInline):
    """
    Show line item identity rules inside the WorkUnit edit page.
    Only relevant for CPT-Level WorkUnits. status is READ-ONLY here
    for the same reason as ClaimIdentityRuleInline — new rules always
    default to TRACKING; promotion only happens via
    apply_identity_change().
    """
    model = LineItemIdentityRule
    extra = 1
    fields = ["standard_field_name", "field_order", "allow_blank"]
    ordering = ["field_order"]


class UserWorkUnitMappingInline(admin.TabularInline):
    """Show user assignments directly inside the WorkUnit edit page."""
    model = UserWorkUnitMapping
    extra = 1
    fields = ["user", "assigned_by", "is_active", "assigned_at"]
    readonly_fields = ["assigned_at"]
    ordering = ["-assigned_at"]


class SubActionTypeInline(admin.TabularInline):
    """Show sub-actions directly inside the ActionType edit page."""
    model = SubActionType
    extra = 1
    fields = ["name", "code", "sort_order", "is_active"]
    ordering = ["sort_order", "name"]


class ClaimLineItemInline(admin.TabularInline):
    """
    Show line items directly inside the Claim edit page.
    All fields are read-only — line items are managed by the ingestion pipeline.
    Useful for verifying ingestion results without navigating away.
    """
    model = ClaimLineItem
    extra = 0
    fields = [
        "line_item_uid", "cpt_code",
        "current_balance", "current_charge",
        "is_active",
        "resolution_date",
    ]
    readonly_fields = [
        "line_item_uid", "cpt_code",
        "current_balance", "current_charge",
        "is_active",
        "resolution_date",
    ]
    ordering = ["cpt_code"]

    def has_add_permission(self, request, obj=None):
        """Line items are created by the pipeline, not manually."""
        return False

    def has_delete_permission(self, request, obj=None):
        """Line items should not be manually deleted."""
        return False
    


class PriorityConditionInline(admin.TabularInline):
    """
    Individual conditions within a PriorityConditionGroup.
    Each row is one atomic field-operator-value comparison.
    ALL conditions in this group must pass for the group to match
    (AND logic within a group).

    field_name must be a field that exists in FIELD_TYPE_MAP in
    operators.py AND is mapped in this WorkUnit's ColumnMapping.
    The frontend will enforce this restriction via dropdown — for
    now, the admin accepts any string and clean() validates it.

    operator must be compatible with the field's type:
      - int/decimal: eq, neq, gt, gte, lt, lte, in, not_in, between, is_null
      - date:        eq, neq, gt, gte, lt, lte, between, is_null
      - string:      eq, neq, in, not_in, is_null

    value is always stored as a string regardless of field type.
    For IN/NOT_IN: comma-separated list, e.g. "Medicare,Medicaid".
    For BETWEEN: value = lower bound, value2 = upper bound.
    For IS_NULL: value = "true" (field is null) or "false" (not null).
    """
    model  = PriorityCondition
    extra  = 1
    fields = ["field_name", "operator", "value", "value2"]


class PriorityConditionGroupInline(admin.TabularInline):
    """
    Condition groups within a PriorityRule.
    Each group is one OR-branch — the tier matches if ANY group passes.
    Conditions within a group are configured by clicking the group's
    change link (show_change_link=True below).

    group_order controls evaluation sequence. Lower numbers are
    evaluated first. For OR logic, order doesn't affect the logical
    result, but it affects which group is logged as the match.

    label is optional but strongly recommended — it appears in
    debug logs and makes rule troubleshooting much easier.
    Example labels: "High-balance Medicare", "Aged over 180 days".
    """
    model            = PriorityConditionGroup
    extra            = 1
    fields           = ["group_order", "label"]
    show_change_link = True
    # show_change_link=True lets the Admin click through to the full
    # PriorityConditionGroupAdmin page where individual conditions
    # (PriorityConditionInline) can be added and edited.
    # This is the flat-admin approach for MVP — the full rule tree
    # is accessible in two clicks without third-party nested inline packages.


class PriorityRuleInline(admin.TabularInline):
    """
    Read-only summary of configured priority tiers on the WorkUnit page.
    Shows which tiers have rules, whether they are active, and how many
    condition groups each tier has.

    This is display-only — all configuration happens via the dedicated
    PriorityRuleAdmin page. The inline is here so the Admin can see
    priority configuration at a glance without leaving the WorkUnit page.
    """
    model        = PriorityRule
    extra        = 0
    fields       = ["priority_tier", "is_active", "group_count"]
    readonly_fields = ["priority_tier", "is_active", "group_count"]
    show_change_link = True
    ordering     = ["priority_tier"]

    def has_add_permission(self, request, obj=None):
        """
        Add priority rules via the PriorityRule admin page, not here.
        This inline is read-only summary display only.
        """
        return False

    def has_delete_permission(self, request, obj=None):
        """Prevent accidental deletion from the WorkUnit page."""
        return False

    @admin.display(description="Condition Groups")
    def group_count(self, obj):
        count = obj.condition_groups.count()
        if count == 0:
            return format_html(
                '<span style="color:#DC2626;">{}</span>',
                "0 — no groups configured",
            )
        return count


# ═══════════════════════════════════════════════════════════════════════════
# 2. FOUNDATION TABLES
# ═══════════════════════════════════════════════════════════════════════════


@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    """
    Healthcare organizations whose AR is being managed.
    Create clients here before creating WorkUnits.
    """
    list_display  = ["code", "name", "is_active", "created_at"]
    list_filter   = ["is_active"]
    search_fields = ["name", "code"]
    readonly_fields = ["id", "created_at"]
    ordering      = ["name"]

    fieldsets = [
        ("Client Information", {
            "fields": ["id", "name", "code", "is_active"],
        }),
        ("Timestamps", {
            "fields": ["created_at", "deactivated_at"],
            "classes": ["collapse"],
        }),
    ]


@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    """
    Internal Jorie Healthcare Partners staff accounts.
    Roles: AR, Team Lead, Manager, Admin, Leadership.
    """
    list_display  = [
        "employee_id", "username", "email",
        "role", "manager_display", "is_active",
    ]
    list_filter   = ["role", "is_active"]
    search_fields = ["employee_id", "username", "email"]
    readonly_fields = ["id", "created_at", "last_login_at"]
    ordering      = ["employee_id"]

    fieldsets = [
        ("User Information", {
            "fields": ["id", "employee_id", "username", "email", "role"],
        }),
        ("Hierarchy", {
            "fields": ["manager", "created_by"],
        }),
        ("Status", {
            "fields": ["is_active", "deactivated_at"],
        }),
        ("System", {
            "fields": ["last_login_at", "created_at"],
            "classes": ["collapse"],
        }),
    ]

    @admin.display(description="Manager")
    def manager_display(self, obj):
        if obj.manager:
            return f"{obj.manager.employee_id} — {obj.manager.username}"
        return "—"


@admin.register(Process)
class ProcessAdmin(admin.ModelAdmin):
    """
    Top-level work categories (e.g. Accounts Receivable).
    Create these before creating SubProcesses and WorkUnits.
    SubProcess is independent — configure it separately.
    """
    list_display  = ["name", "code", "sort_order", "is_active"]
    list_filter   = ["is_active"]
    search_fields = ["name", "code"]
    readonly_fields = ["id", "created_at"]
    ordering      = ["sort_order", "name"]

    fieldsets = [
        ("Process Information", {
            "fields": ["id", "name", "code", "sort_order", "is_active"],
        }),
        ("System", {
            "fields": ["created_at"],
            "classes": ["collapse"],
        }),
    ]


@admin.register(SubProcess)
class SubProcessAdmin(admin.ModelAdmin):
    """
    Sub-categories within a process (e.g. NPNR, Denials, Location A).
    SubProcess is independent — not linked to a specific Process.
    The link is created when you configure a WorkUnit.
    """
    list_display  = ["name", "code", "sort_order", "is_active"]
    list_filter   = ["is_active"]
    search_fields = ["name", "code"]
    readonly_fields = ["id", "created_at"]
    ordering      = ["sort_order", "name"]

    fieldsets = [
        ("SubProcess Information", {
            "fields": ["id", "name", "code", "sort_order", "is_active"],
        }),
        ("System", {
            "fields": ["created_at"],
            "classes": ["collapse"],
        }),
    ]


# ═══════════════════════════════════════════════════════════════════════════
# 3. WORKUNIT CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════


@admin.register(WorkUnit)
class WorkUnitAdmin(admin.ModelAdmin):
    """
    The atomic unit of work — Client + Process + SubProcess.
    Everything in the ingestion pipeline is scoped to a WorkUnit.

    Configure ColumnMappings and Identity Rules in the inlines below
    before running the first ingestion for a WorkUnit.

    Identity rules are no longer locked after first ingestion. Changing
    them is handled through the configuration-change workflow (see
    ClaimIdentityRule / LineItemIdentityRule admin — the 'status'
    field controls whether a rule is ACTIVE or TRACKING).
    """
    list_display = [
        "display_name", "ingestion_mode",
        "tracking_fields_display", "is_active",
        "daily_target", "created_at",
    ]
    list_filter  = ["ingestion_mode", "is_active", "client", "process"]
    search_fields = [
        "client__name", "client__code",
        "process__name", "sub_process__name",
    ]
    readonly_fields = ["id", "created_at", "bucket_capacity"]
    ordering = ["client__name", "process__name", "sub_process__name"]

    inlines = [
        ColumnMappingInline,
        ClaimIdentityRuleInline,
        LineItemIdentityRuleInline,
        UserWorkUnitMappingInline,
        PriorityRuleInline, 
    ]

    fieldsets = [
        ("WorkUnit Identity", {
            "fields": [
                "id", "client", "process", "sub_process",
                "ingestion_mode",
            ],
            "description": (
                "The combination of Client + Process + SubProcess must be unique. "
                "ingestion_mode controls whether the file has one row per claim "
                "(CLAIM_LEVEL) or one row per CPT code (CPT_LEVEL)."
            ),
        }),
        ("Operational Settings", {
            "fields": [
                "daily_target", "bucket_capacity",
                "follow_up_window_days",
            ],
        }),
        ("Status", {
            "fields": ["is_active", "deactivated_at", "created_by", "created_at"],
            "classes": ["collapse"],
        }),
    ]

    @admin.display(description="WorkUnit")
    def display_name(self, obj):
        return f"{obj.client.code} | {obj.process.code} | {obj.sub_process.code}"

    @admin.display(description="Tracking Fields")
    def tracking_fields_display(self, obj):
        """
        Shows any identity fields currently in TRACKING status for this
        WorkUnit, with their last known readiness percentage — a quick
        glance at whether a configuration change is in progress.
        """
        tracking = list(
            obj.identity_rules.filter(status=ClaimIdentityRule.Status.TRACKING)
            .values_list("standard_field_name", flat=True)
        )
        if not tracking:
            return "—"
        return ", ".join(tracking)


@admin.register(UserWorkUnitMapping)
class UserWorkUnitMappingAdmin(admin.ModelAdmin):
    """
    Which users are assigned to which WorkUnits.
    Can also be managed from the WorkUnit page via the inline.
    """
    list_display  = ["user", "work_unit", "is_active", "assigned_by", "assigned_at"]
    list_filter   = ["is_active", "work_unit__client"]
    search_fields = [
        "user__employee_id", "user__username",
        "work_unit__client__name",
    ]
    readonly_fields = ["id", "assigned_at"]
    ordering = ["work_unit__client__name", "user__employee_id"]


# ═══════════════════════════════════════════════════════════════════════════
# 4. FIELD AND IDENTITY CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════


@admin.register(StandardField)
class StandardFieldAdmin(admin.ModelAdmin):
    """
    Master list of canonical ARxTracker field names.
    These are the standard names all client data is mapped to.

    Pre-populated with 28+ fields. Required fields must be mapped
    in every WorkUnit's ColumnMapping before ingestion can run.
    This table is primarily read-only during testing — modify only
    if adding new canonical fields.
    """
    list_display  = [
        "field_name", "display_name", "data_type",
        "category_badge", "sort_order", "is_active",
    ]
    list_filter   = ["data_type", "category", "is_active"]
    search_fields = ["field_name", "display_name"]
    readonly_fields = ["id", "created_at"]
    ordering      = ["sort_order", "display_name"]

    fieldsets = [
        ("Field Definition", {
            "fields": [
                "id", "field_name", "display_name",
                "data_type", "category", "description",
            ],
        }),
        ("Display", {
            "fields": ["sort_order", "is_active"],
        }),
        ("System", {
            "fields": ["created_at"],
            "classes": ["collapse"],
        }),
    ]

    @admin.display(description="Category")
    def category_badge(self, obj):
        color = "#059669" if obj.category == "required" else "#6B7280"
        return format_html(
            '<span style="color:{}; font-weight:bold;">{}</span>',
            color, obj.get_category_display(),
        )


@admin.register(ColumnMapping)
class ColumnMappingAdmin(admin.ModelAdmin):
    """
    Maps client-specific column headers to ARxTracker standard field names.
    Can also be configured from the WorkUnit page via the inline.

    source_column_name: the exact header from the client's file
    standard_field:     the ARxTracker canonical field it maps to
    """
    list_display  = [
        "work_unit", "source_column_name",
        "standard_field_display", "created_at",
    ]
    list_filter   = ["work_unit__client", "standard_field__category"]
    search_fields = [
        "source_column_name",
        "standard_field__field_name",
        "work_unit__client__name",
    ]
    readonly_fields = ["id", "created_at"]
    ordering = ["work_unit__client__name", "standard_field__field_name"]
    autocomplete_fields = ["standard_field"]

    fieldsets = [
        ("Mapping", {
            "fields": ["work_unit", "source_column_name", "standard_field"],
            "description": (
                "source_column_name must exactly match the column header "
                "in the client's AR file (case-sensitive, whitespace matters)."
            ),
        }),
        ("System", {
            "fields": ["id", "created_at"],
            "classes": ["collapse"],
        }),
    ]

    @admin.display(description="Standard Field")
    def standard_field_display(self, obj):
        return f"{obj.standard_field.field_name} ({obj.standard_field.get_category_display()})"


@admin.register(ClaimIdentityRule)
class ClaimIdentityRuleAdmin(admin.ModelAdmin):
    """
    Defines which fields combine to generate the claim_uid for a WorkUnit.
    Evaluated in field_order sequence. status=ACTIVE fields are used for
    UID generation; status=TRACKING fields are captured into
    identity_values but not yet used for UID generation.

    status is READ-ONLY in this admin. Every new rule automatically
    defaults to TRACKING on creation. Promotion to ACTIVE happens
    ONLY through apply_identity_change() (run via the
    change_identity_rules management command), which re-validates
    readiness fresh and writes a permanent ConfigChangeLog entry.
    There is no manual override here — this is intentional, not an
    oversight.

    Can also be configured from the WorkUnit page via the inline.
    """
    list_display  = [
        "work_unit", "field_order", "standard_field_name", "status_badge",
    ]
    list_filter   = ["work_unit__client", "status"]
    search_fields = [
        "standard_field_name",
        "work_unit__client__name",
    ]
    readonly_fields = ["status"]
    ordering = ["work_unit__client__name", "field_order"]

    fieldsets = [
        ("Identity Rule", {
            "fields": ["work_unit", "standard_field_name", "field_order", "status"],
            "description": (
                "standard_field_name must match a canonical field name "
                "that is mapped in this WorkUnit's ColumnMapping. "
                "field_order determines the sequence ACTIVE fields are "
                "joined with '|' to produce the claim UID. New rules "
                "always start as TRACKING automatically — use "
                "'python manage.py change_identity_rules' to promote a "
                "field to ACTIVE once it reaches readiness."
            ),
        }),
    ]

    @admin.display(description="Status")
    def status_badge(self, obj):
        if obj.status == ClaimIdentityRule.Status.ACTIVE:
            return format_html(
                '<span style="color:#059669; font-weight:bold;">{}</span>',
                "● Active",
            )
        return format_html(
            '<span style="color:#D97706; font-weight:bold;">{}</span>',
            "◐ Tracking",
        )


@admin.register(LineItemIdentityRule)
class LineItemIdentityRuleAdmin(admin.ModelAdmin):
    """
    Defines which CPT-level fields combine to generate the line_item_uid.
    Only applies to CPT-Level WorkUnits. Evaluated in field_order sequence.

    Config versioning is CLAIM-LEVEL ONLY — line-item identity rules do
    not have an ACTIVE/TRACKING promotion workflow. The status field is
    vestigial and has no active behavior. All line-item identity fields
    are used for UID generation immediately upon configuration.
    """
    list_display  = [
        "work_unit", "field_order", "standard_field_name",
        "allow_blank", "status_badge",
    ]
    list_filter   = ["work_unit__client", "allow_blank", "status"]
    search_fields = [
        "standard_field_name",
        "work_unit__client__name",
    ]
    readonly_fields = ["status"]
    ordering = ["work_unit__client__name", "field_order"]

    fieldsets = [
        ("Line Item Identity Rule", {
            "fields": [
                "work_unit", "standard_field_name", "field_order",
                "allow_blank", "status",
            ],
            "description": (
                "Only configurable for CPT-Level WorkUnits. "
                "Typically cpt_code alone is sufficient. Add a second field "
                "(e.g. modifier) only if the same CPT can appear twice on one claim. "
                "Check 'allow_blank' for fields where a blank value is itself "
                "meaningful (e.g. no modifier present) rather than missing data. "
                "New rules always start as TRACKING automatically — line-item "
                "promotion is not yet built (deferred until claim-level is confirmed)."
            ),
        }),
    ]

    @admin.display(description="Status")
    def status_badge(self, obj):
        if obj.status == LineItemIdentityRule.Status.ACTIVE:
            return format_html(
                '<span style="color:#059669; font-weight:bold;">{}</span>',
                "● Active",
            )
        return format_html(
            '<span style="color:#D97706; font-weight:bold;">{}</span>',
            "◐ Tracking",
        )


# ═══════════════════════════════════════════════════════════════════════════
# 5. ACTION AND ESCALATION CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════


@admin.register(ActionType)
class ActionTypeAdmin(admin.ModelAdmin):
    """
    Top-level action categories (global — not client-specific).
    AR callers select from these when logging follow-up events.
    Sub-actions are configured in the inline below.
    """
    list_display  = ["name", "code", "sort_order", "is_active", "sub_action_count"]
    list_filter   = ["is_active"]
    search_fields = ["name", "code"]
    readonly_fields = ["id", "created_at"]
    ordering      = ["sort_order", "name"]

    inlines = [SubActionTypeInline]

    @admin.display(description="Sub-Actions")
    def sub_action_count(self, obj):
        count = obj.sub_actions.filter(is_active=True).count()
        return count


@admin.register(SubActionType)
class SubActionTypeAdmin(admin.ModelAdmin):
    """
    Sub-categories under each ActionType.
    Can also be configured from the ActionType page via the inline.
    """
    list_display  = ["name", "code", "action_type", "sort_order", "is_active"]
    list_filter   = ["is_active", "action_type"]
    search_fields = ["name", "code", "action_type__name"]
    readonly_fields = ["id", "created_at"]
    ordering      = ["action_type__sort_order", "sort_order", "name"]


@admin.register(EscalationCategory)
class EscalationCategoryAdmin(admin.ModelAdmin):
    """
    Global pool of escalation categories.
    Which categories apply to a WorkUnit is configured in
    WorkUnitEscalationMapping.
    """
    list_display  = ["name", "code", "sort_order", "is_active"]
    list_filter   = ["is_active"]
    search_fields = ["name", "code"]
    readonly_fields = ["id", "created_at"]
    ordering      = ["sort_order", "name"]


@admin.register(WorkUnitEscalationMapping)
class WorkUnitEscalationMappingAdmin(admin.ModelAdmin):
    """
    Controls which escalation categories are available for each WorkUnit,
    and whether each is handled internally or by the client.
    """
    list_display  = [
        "work_unit", "escalation_category",
        "handling_type", "is_active",
    ]
    list_filter   = ["handling_type", "is_active", "work_unit__client"]
    search_fields = [
        "work_unit__client__name",
        "escalation_category__name",
    ]
    readonly_fields = ["id", "created_at"]
    ordering = ["work_unit__client__name", "escalation_category__name"]



# ═══════════════════════════════════════════════════════════════════════════
# 5.5 PRIORITY RULES CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════


@admin.register(PriorityConditionGroup)
class PriorityConditionGroupAdmin(admin.ModelAdmin):
    """
    One OR-branch within a PriorityRule's ruleset.
    A claim matches the tier if ANY condition group passes.
    Within this group, ALL conditions must pass (AND logic).

    Configure conditions in the PriorityConditionInline below.
    Each condition is one field-operator-value comparison.

    Testing tip: add a descriptive label to each group — it appears
    in the evaluate_priority_rules terminal output and in Django logs
    when --verbosity=2 is used, making it easy to confirm which
    group caused a claim to match a tier.
    """
    list_display  = [
        "rule", "group_order", "label", "condition_count",
        "rule_tier", "rule_is_active",
    ]
    list_filter   = [
        "rule__work_unit__client",
        "rule__priority_tier",
        "rule__is_active",
    ]
    search_fields = [
        "label",
        "rule__work_unit__client__name",
    ]
    readonly_fields = ["id"]
    ordering = ["rule__priority_tier", "group_order"]

    inlines = [PriorityConditionInline]

    fieldsets = [
        ("Group Identity", {
            "fields": ["rule", "group_order", "label"],
            "description": (
                "This group belongs to the rule above. "
                "group_order controls evaluation sequence (lower first). "
                "label is optional but appears in debug logs — use something "
                "descriptive like 'High-balance Medicare' or 'Aged 180+ days'."
            ),
        }),
        ("System", {
            "fields": ["id"],
            "classes": ["collapse"],
        }),
    ]

    @admin.display(description="Conditions")
    def condition_count(self, obj):
        count = obj.conditions.count()
        if count == 0:
            return format_html(
                '<span style="color:#DC2626; font-weight:bold;">{}</span>',
                "0 — add conditions",
            )
        return count

    @admin.display(description="Tier")
    def rule_tier(self, obj):
        colors = {
            "P1": "#DC2626",
            "P2": "#D97706",
            "P3": "#2563EB",
            "P4": "#6B7280",
        }
        color = colors.get(obj.rule.priority_tier, "#6B7280")
        return format_html(
            '<span style="color:{}; font-weight:bold;">{}</span>',
            color, obj.rule.priority_tier,
        )

    @admin.display(description="Rule Active")
    def rule_is_active(self, obj):
        if obj.rule.is_active:
            return format_html(
                '<span style="color:#059669; font-weight:bold;">{}</span>',
                "●",
            )
        return format_html(
            '<span style="color:#DC2626; font-weight:bold;">{}</span>',
            "○ Inactive",
        )

    def get_queryset(self, request):
        return (
            super().get_queryset(request)
            .select_related("rule", "rule__work_unit", "rule__work_unit__client")
        )


@admin.register(PriorityCondition)
class PriorityConditionAdmin(admin.ModelAdmin):
    """
    One atomic condition within a PriorityConditionGroup.
    field_name + operator + value = one comparison against a claim field.

    All conditions in a group must pass for the group to match (AND).
    If any condition fails, the group fails and the next group is tried.

    Validation (via clean()):
      1. field_name must exist in operators.FIELD_TYPE_MAP
      2. operator must be valid for that field's type
      3. value must be castable to that field's type
      4. BETWEEN requires value2 with lower < upper

    Common configuration errors caught here at save time — you will
    see a validation error rather than a silent wrong result.

    For testing: after saving a condition, run:
      py manage.py evaluate_priority_rules --work-unit=<uuid> --dry-run
    to see how this condition affects the tier distribution.
    """
    list_display  = [
        "group_display", "field_name", "operator_badge",
        "value", "value2", "condition_tier",
    ]
    list_filter   = [
        "operator",
        "group__rule__priority_tier",
        "group__rule__work_unit__client",
    ]
    search_fields = [
        "field_name",
        "value",
        "group__label",
        "group__rule__work_unit__client__name",
    ]
    readonly_fields = ["id"]
    ordering = ["group__rule__priority_tier", "group__group_order", "id"]

    fieldsets = [
        ("Condition", {
            "fields": ["group", "field_name", "operator", "value", "value2"],
            "description": (
                "field_name: the Claim field to evaluate (e.g. 'aging_days', "
                "'current_balance', 'current_insurance'). Must match an entry "
                "in operators.FIELD_TYPE_MAP. "
                "operator: the comparison to perform. Must be valid for the "
                "field's type (e.g. gt/gte/lt/lte not valid for string fields). "
                "value: the comparison value as a string (e.g. '180', '5000.00', "
                "'Medicare'). Always stored as string — cast to correct type at "
                "evaluation time. "
                "value2: upper bound for BETWEEN operator only. Leave blank "
                "for all other operators."
            ),
        }),
        ("System", {
            "fields": ["id"],
            "classes": ["collapse"],
        }),
    ]

    @admin.display(description="Group")
    def group_display(self, obj):
        label = obj.group.label or f"Group {obj.group.group_order}"
        return f"{obj.group.rule} | {label}"

    @admin.display(description="Operator")
    def operator_badge(self, obj):
        # Color-code operators by category for quick visual scanning
        comparison_ops = {"eq", "neq"}
        numeric_ops    = {"gt", "gte", "lt", "lte", "between"}
        list_ops       = {"in", "not_in"}
        null_ops       = {"is_null"}

        if obj.operator in numeric_ops:
            color = "#2563EB"   # blue — numeric comparison
        elif obj.operator in list_ops:
            color = "#7C3AED"   # purple — list membership
        elif obj.operator in null_ops:
            color = "#D97706"   # amber — null check
        else:
            color = "#059669"   # green — equality

        return format_html(
            '<span style="color:{}; font-family:monospace; '
            'font-weight:bold;">{}</span>',
            color, obj.get_operator_display(),
        )

    @admin.display(description="Tier")
    def condition_tier(self, obj):
        return obj.group.rule.priority_tier

    def get_queryset(self, request):
        return (
            super().get_queryset(request)
            .select_related(
                "group",
                "group__rule",
                "group__rule__work_unit",
                "group__rule__work_unit__client",
            )
        )


@admin.register(PriorityRule)
class PriorityRuleAdmin(admin.ModelAdmin):
    """
    Top-level container for one priority tier's rules within a WorkUnit.
    One row per tier per WorkUnit. A WorkUnit can have rules for P1 and P2
    only — P3, P4, and P5 don't need to be configured.

    P5 is NEVER configured here. It is the system default — assigned
    automatically to any claim that matches no configured rule.

    is_active=False temporarily disables all rules for this tier.
    Claims that would have matched fall through to the next tier or P5.
    The condition groups and conditions are preserved — nothing is deleted.

    After creating or modifying rules, run:
      py manage.py evaluate_priority_rules --work-unit=<uuid> --dry-run
    to preview the effect on claim distribution before committing.

    The UniqueConstraint on (work_unit, priority_tier) prevents duplicate
    tier configurations for the same WorkUnit. If you need to reconfigure
    P1, edit the existing P1 rule — do not create a second one.
    """
    list_display  = [
        "work_unit_display", "priority_tier_badge",
        "is_active", "group_count", "condition_count_total",
        "updated_at",
    ]
    list_filter   = [
        "priority_tier",
        "is_active",
        "work_unit__client",
        "work_unit__ingestion_mode",
    ]
    search_fields = [
        "work_unit__client__name",
        "work_unit__client__code",
    ]
    readonly_fields = ["id", "created_at", "updated_at"]
    ordering = ["work_unit__client__name", "priority_tier"]

    inlines = [PriorityConditionGroupInline]

    fieldsets = [
        ("Rule Identity", {
            "fields": ["work_unit", "priority_tier", "is_active"],
            "description": (
                "One PriorityRule per tier per WorkUnit. "
                "priority_tier P1-P4 only — P5 is the system default, never configured. "
                "is_active=False disables this entire tier without deleting its "
                "condition groups. Use this when reconfiguring rules — disable, "
                "edit, re-enable."
            ),
        }),
        ("System", {
            "fields": ["id", "created_at", "updated_at"],
            "classes": ["collapse"],
        }),
    ]

    @admin.display(description="WorkUnit")
    def work_unit_display(self, obj):
        return str(obj.work_unit)

    @admin.display(description="Tier")
    def priority_tier_badge(self, obj):
        colors = {
            "P1": "#DC2626",   # red — highest priority
            "P2": "#D97706",   # amber
            "P3": "#2563EB",   # blue
            "P4": "#6B7280",   # grey — lowest configured
        }
        color = colors.get(obj.priority_tier, "#6B7280")
        return format_html(
            '<span style="color:{}; font-weight:bold; font-size:1.1em;">{}</span>',
            color, obj.priority_tier,
        )

    @admin.display(description="Groups")
    def group_count(self, obj):
        count = obj.condition_groups.count()
        if count == 0:
            return format_html(
                '<span style="color:#DC2626;">{}</span>',
                "0 — add groups",
            )
        return count

    @admin.display(description="Total Conditions")
    def condition_count_total(self, obj):
        """
        Total conditions across all groups — gives a quick sense of
        rule complexity without opening the rule.
        """
        total = sum(len(g.conditions.all()) for g in obj.condition_groups.all())

        if total == 0:
            return format_html(
                '<span style="color:#DC2626;">{}</span>',
                "0 — add conditions",
            )
        return total

    def get_queryset(self, request):
        return (
            super().get_queryset(request)
            .select_related("work_unit", "work_unit__client")
            .prefetch_related("condition_groups__conditions")
        )



# ═══════════════════════════════════════════════════════════════════════════
# 6. INGESTION — FILE UPLOAD
# ═══════════════════════════════════════════════════════════════════════════


@admin.register(FileUpload)
class FileUploadAdmin(admin.ModelAdmin):
    """
    Tracks every AR file upload — who uploaded it, when, and the result.
    Records are created automatically by the ingestion pipeline.

    Status meanings:
      PROCESSING — pipeline is actively running
      COMPLETED  — all rows processed (check error_count for skipped rows)
      FAILED     — pipeline crashed (transaction rolled back — no data written)
      PENDING    — created but not yet processed (stale record)

    For testing: after running the management command, look here first
    to verify the upload was processed correctly before checking Claims.
    """
    list_display  = [
        "file_name", "work_unit_display",
        "status_badge", "record_count", "error_count",
        "uploaded_by_display", "file_date", "uploaded_at",
        "mass_resolution_warning_badge",
    ]
    list_filter   = ["status", "work_unit__client"]
    search_fields = [
        "file_name", "file_hash",
        "work_unit__client__name",
    ]
    readonly_fields = [
        "id", "file_hash", "uploaded_at", "completed_at",
        "record_count", "error_count", "status",
        "work_unit", "client", 
        "mass_resolution_warning_message",
        "has_mass_resolution_warning",
    ]
    ordering = ["-uploaded_at"]

    fieldsets = [
        ("File Information", {
            "fields": [
                "id", "work_unit", "client",
                "file_name", "file_date", "uploaded_by",
            ],
        }),
        ("Processing Results", {
            "fields": ["status", "record_count", "error_count",
                        "has_mass_resolution_warning", "mass_resolution_warning_message"],
            "description": (
                "record_count = claims created + updated. "
                "error_count = rows skipped due to data errors."
            ),
        }),
        ("Technical", {
            "fields": ["file_hash", "uploaded_at", "completed_at"],
            "classes": ["collapse"],
        }),
    ]

    def has_add_permission(self, request):
        """FileUploads are created by the pipeline, not manually."""
        return False
    
    @admin.display(description="Mass Resolution")
    def mass_resolution_warning_badge(self, obj):
        if obj.has_mass_resolution_warning:
            return format_html(
                '<span style="color:#DC2626; font-weight:bold;">{}</span>',
                "⚠ Warning",
            )
        return format_html(
            '<span style="color:#059669;">{}</span>',
            "✓ OK",
        )

    @admin.display(description="WorkUnit")
    def work_unit_display(self, obj):
        return str(obj.work_unit)

    @admin.display(description="Status")
    def status_badge(self, obj):
        colors = {
            "Completed":  "#059669",
            "Processing": "#D97706",
            "Pending":    "#6B7280",
            "Failed":     "#DC2626",
        }
        color = colors.get(obj.status, "#6B7280")
        return format_html(
            '<span style="color:{}; font-weight:bold;">{}</span>',
            color, obj.get_status_display(),
        )

    @admin.display(description="Uploaded By")
    def uploaded_by_display(self, obj):
        if obj.uploaded_by:
            return obj.uploaded_by.username
        return "System"


# ═══════════════════════════════════════════════════════════════════════════
# 7. CORE AR DATA — CLAIM AND LINE ITEM
# ═══════════════════════════════════════════════════════════════════════════


@admin.register(Claim)
class ClaimAdmin(admin.ModelAdmin):
    """
    Core AR claim records. Created and updated by the ingestion pipeline.
    Do not manually create claims — they must come from file uploads.

    Key fields for testing ingestion:
      claim_number  — the generated UID (e.g. "P001|2024-01-15")
      current_balance — aggregate of active line item balances
      aging_bucket  — computed from service_date at ingestion time
      priority_tier — P5 until priority rules are evaluated
      last_upload   — which FileUpload last refreshed this claim's data

    Line items are visible in the inline below.
    """
    list_display  = [
        "claim_number", "work_unit_display",
        "patient_name", "current_insurance",
        "balance_display", "aging_bucket",
        "priority_tier", "is_active", "owner_display",
        "last_upload_display", "created_at",
    ]
    list_filter   = [
        "aging_bucket", "priority_tier",
        "work_unit__client",
        "work_unit__ingestion_mode",
        "is_active",
    ]
    search_fields = [
        "claim_number", "patient_name",
        "patient_id", "account_number",
        "work_unit__client__name",
    ]
    readonly_fields = [
        "id", "created_at", "updated_at",
        "claim_number", "work_unit", "client",
        "aging_days", "aging_bucket",
        "current_balance", "current_charge",
        "last_upload", "identity_values",
        "is_active"
    ]
    ordering = ["-created_at"]

    inlines = [ClaimLineItemInline]

    fieldsets = [
        ("Claim Identity", {
            "fields": [
                "id", "work_unit", "client", "claim_number", "identity_values",
            ],
        }),
        ("Patient", {
            "fields": [
                "patient_name", "patient_id",
                "patient_dob", "account_number",
            ],
        }),
        ("Service", {
            "fields": [
                "service_date", "last_billed_date",
                "primary_dx_code",
            ],
        }),
        ("Insurance", {
            "fields": [
                "current_insurance", "primary_insurance",
                "secondary_insurance", "insurance_type", "group_no",
            ],
        }),
        ("Providers", {
            "fields": [
                "billing_provider_name", "billing_provider_npi",
                "rendering_provider", "rendering_provider_npi",
            ],
            "classes": ["collapse"],
        }),
        ("Facility", {
            "fields": ["facility_location", "facility_location_state"],
            "classes": ["collapse"],
        }),
        ("Financials & Aging", {
            "fields": [
                "current_balance", "current_charge",                
                "is_active", "aging_days", "aging_bucket",
            ],
            "description": (
                "current_balance = sum of active line item balances. "
                "is_active = whether this claim has at least one active "
                "line item; False means fully resolved. Both are "
                "recalculated on every upload. "
                "aging_days and aging_bucket are computed from service_date "
                "at the time of upload."
            ),
        }),
        ("Workflow", {
            "fields": [
                "priority_tier", "current_owner",
                "next_follow_up_date", "original_assign_date",
            ],
            "description": (
                "priority_tier is set by priority rules after ingestion. "
                "current_owner, next_follow_up_date are set by the "
                "allocation and follow-up workflow, never by ingestion."
            ),
        }),
        ("System", {
            "fields": [
                "last_upload", "created_by",
                "created_at", "updated_at",
            ],
            "classes": ["collapse"],
        }),
    ]

    def has_add_permission(self, request):
        """Claims are created by the ingestion pipeline, not manually."""
        return False
    
    def has_delete_permission(self, request, obj=None):
        """
        Claims must not be manually deleted — they are resolved through
        the feed-driven resolution process only. Deleting a claim would
        cascade-delete all its line items, follow-up events, and
        assignment history.
        """
        return False

    @admin.display(description="WorkUnit")
    def work_unit_display(self, obj):
        return str(obj.work_unit)

    @admin.display(description="Balance")
    def balance_display(self, obj):
        if obj.current_balance is not None:
            return f"${obj.current_balance:,.2f}"
        return "—"

    @admin.display(description="Owner")
    def owner_display(self, obj):
        if obj.current_owner:
            return f"{obj.current_owner.employee_id}"
        return "Unassigned"

    @admin.display(description="Last Upload")
    def last_upload_display(self, obj):
        if obj.last_upload:
            return obj.last_upload.file_name
        return "—"


@admin.register(ClaimLineItem)
class ClaimLineItemAdmin(admin.ModelAdmin):
    """
    Individual CPT-level line items under each claim.
    Created and updated by the ingestion pipeline.

    Key fields for testing ingestion:
      line_item_uid  — generated UID (e.g. "P001|2024-01-15|99213")
      is_active      — True = present in most recent upload
      current_balance — balance for this specific CPT code
      resolution_date — set when absent from a subsequent upload
    """
    list_display  = [
        "line_item_uid", "claim_number_display",
        "cpt_code", "balance_display",
        "is_active",
        "last_updated_at",
    ]
    list_filter   = [
        "is_active",
        "claim__work_unit__client",
    ]
    search_fields = [
        "line_item_uid", "cpt_code",
        "claim__claim_number",
        "claim__patient_name",
    ]
    readonly_fields = [
        "id", "claim", "client", "work_unit",
        "line_item_uid", "identity_values", "cpt_code",
        "current_balance", "current_charge",
        "is_active",
        "resolution_date", "archived_at",
        "first_seen_at", "last_updated_at",
    ]
    ordering = ["-last_updated_at"]

    fieldsets = [
        ("Identity", {
            "fields": [
                "id", "claim", "client", "work_unit",
                "line_item_uid", "identity_values", "cpt_code",
            ],
        }),
        ("Financials", {
            "fields": ["current_balance", "current_charge"],
            "description": "Updated in place on every upload.",
        }),
        ("Resolution", {
            "fields": [
                "is_active",
                "resolution_date", "archived_at",
            ],
            "description": (
                "is_active=False means this line item was absent from "
                "the most recent upload (resolved)."
            ),
        }),
        ("System", {
            "fields": ["first_seen_at", "last_updated_at"],
            "classes": ["collapse"],
        }),
    ]

    def has_add_permission(self, request):
        """Line items are created by the pipeline, not manually."""
        return False

    def has_delete_permission(self, request, obj=None):
        """Line items should not be manually deleted."""
        return False

    @admin.display(description="Claim #")
    def claim_number_display(self, obj):
        return obj.claim.claim_number
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related("claim", "work_unit", "client")

    @admin.display(description="Balance")
    def balance_display(self, obj):
        if obj.current_balance is not None:
            return f"${obj.current_balance:,.2f}"
        return "—"



@admin.register(ConfigChangeLog)
class ConfigChangeLogAdmin(admin.ModelAdmin):
    """
    Permanent, append-only audit trail of every identity rule change.
    Never editable or deletable through the admin — this is the
    compliance record of what changed, who approved it, and what the
    recomputation outcome was.
    """
    list_display = [
        "work_unit", "change_type", "achieved_percent",
        "threshold_percent", "active_claims_recomputed",
        "active_claims_blocked", "changed_by", "changed_at",
    ]
    list_filter = ["change_type", "work_unit__client"]
    search_fields = ["work_unit__client__name"]
    readonly_fields = [
        "id", "work_unit", "change_type", "old_rules", "new_rules",
        "active_claims_total", "active_claims_recomputed", "active_claims_blocked",
        "resolved_claims_total", "resolved_claims_recomputed", "resolved_claims_blocked",
        "line_items_recomputed", "threshold_percent", "achieved_percent",
        "changed_by", "changed_at",
    ]
    ordering = ["-changed_at"]

    def has_add_permission(self, request):
        """ConfigChangeLog entries are created only by the configuration-change workflow."""
        return False

    def has_change_permission(self, request, obj=None):
        """Append-only — no editing allowed."""
        return False

    def has_delete_permission(self, request, obj=None):
        """Permanent audit trail — cannot be deleted."""
        return False



# ═══════════════════════════════════════════════════════════════════════════
# 7.5 PROJECTS
# ═══════════════════════════════════════════════════════════════════════════

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    """
    Batch/campaign records that temporarily elevate a curated set of
    claims to top priority (P0) in the AR worklist, independent of 
    their normal P1-P5 priority_tier.

    Created directly here, before any file is attached. Claims are 
    linked only via a project-scoped upload
    (ingest_ar_file --project=<uuid>) - never selected manually here
    """
    list_display = [
        "name", "work_unit_display", "status_badge",
        "progress_display", "claims_locked_at",
        "created_by_display", "created_at",
    ]
    list_filter = ["status", "work_unit__client"]
    search_fields = ["name", "work_unit__client__name"]
    readonly_fields = [
        "id", "client", "total_line_items",
        "worked_line_items", "claims_locked_at", "created_at",
    ]
    ordering = ["-created_at"]

    fieldsets = [
        ("Project Information", {
            "fields": ["id", "work_unit", "client", "name", "created_by"],
        }),
        ("Status", {
            "fields": ["status", "closed_at"],
            "description": (
                "ACTIVE claims are elevated to P0. Switching to completed "
                "or Cancelled closes the project immediately and removes "
                "P0 from every claim in it."
            ),
        }),
        ("Progress (read-only, pipeline-managed)", {
            "fields": ["total_line_items", "worked_line_items", "claims_locked_at"],
            "classes": ["collapse"],
        }),
    ]

    def save_model(self, request, obj, form, change):
        obj.client = obj.work_unit.client
        if change and "status" in form.changed_data and obj.status != Project.Status.ACTIVE:
            obj.closed_at = timezone.now()
        super().save_model(request, obj, form, change)

    @admin.display(description="WorkUnit")
    def work_unit_display(self, obj):
        return str(obj.work_unit)
    
    @admin.display(description="Status")
    def status_badge(self, obj):
        colors = {
            "active": "#D97706",
            "completed": "#059669",
            "cancelled": "#DC2626",
        }
        color = colors.get(obj.status, "#6B7280")
        return format_html(
            '<span style="color:{}; font-weight:bold;">{}</span>',
            color, obj.get_status_display(),
        )
    
    @admin.display(description="Progress")
    def progress_display(self, obj):
        if obj.total_line_items == 0:
            return "-"
        pct = round(obj.worked_line_items / obj.total_line_items * 100)
        return f"{obj.worked_line_items} / {obj.total_line_items} ({pct}%)"
    
    @admin.display(description="Created By")
    def created_by_display(self, obj):
        if obj.created_by:
            return obj.created_by.username
        return "-"
    

@admin.register(ProjectClaim)
class ProjectClaimAdmin(admin.ModelAdmin):
    """
    Membership log linking claims to the projects that elevate them.
    Created only by a project-scoped file upload - never manually.
    Locked after creation: a project's claim set is fixed at upload
    (Point 2 of the Projects design) - editing or deleting these rows
    would silently change that fixed set after the fact.
    """
    list_display = [
        "claim_number_display", "project_display",
        "client_display", "progress_display", "added_at",
    ]
    list_filter = ["project__status", "client"]
    search_fields = ["claim__claim_number", "project__name"]
    readonly_fields = [
        "id", "project", "claim", "client", "added_at",
        "total_line_items", "worked_line_items",
    ]
    ordering = ["-added_at"]

    def has_add_permission(self, request):
        """ProjectClaims are created by a project-scoped upload, never manually."""
        return False
    
    def has_change_permission(self, request, obj=None):
        """Locked after creation - a project's claim set is fixed at upload."""
        return False
    
    def has_delete_permission(self, request, obj=None):
        """Cannot be deleted - would silently shrink a project's fixed claim set."""
        return False
    
    @admin.display(description="Claim #")
    def claim_number_display(self, obj):
        return obj.claim.claim_number
    
    @admin.display(description="Project")
    def project_display(self, obj):
        return obj.project.name
    
    @admin.display(description="Client")
    def client_display(self, obj):
        return obj.client.name
    
    @admin.display(description="Progress")
    def progress_display(self, obj):
        if obj.total_line_items == 0:
            return "-"
        pct = round(obj.worked_line_items / obj.total_line_items * 100)
        return f"{obj.worked_line_items} / {obj.total_line_items} ({pct}%)"


# ═══════════════════════════════════════════════════════════════════════════
# 8. WORKFLOW TABLES
# ═══════════════════════════════════════════════════════════════════════════


@admin.register(ClaimAssignment)
class ClaimAssignmentAdmin(admin.ModelAdmin):
    """
    Append-only log of every claim-to-user assignment event.
    Cannot be edited or deleted — it is the permanent audit trail
    of all allocation activity.
    """
    list_display  = [
        "claim_number_display", "assigned_to_display",
        "bucket", "assigned_by_display",
        "assigned_at", "completed_at",
    ]
    list_filter   = ["bucket", "work_unit__client"]
    search_fields = [
        "claim__claim_number",
        "assigned_to__employee_id",
        "assigned_to__username",
    ]
    readonly_fields = [
        "id", "client", "work_unit", "claim",
        "assigned_to", "assigned_by",
        "bucket", "assigned_at", "completed_at",
    ]
    ordering = ["-assigned_at"]

    def has_add_permission(self, request):
        """ClaimAssignments are created by the allocation workflow."""
        return False

    def has_change_permission(self, request, obj=None):
        """ClaimAssignment is append-only — no editing allowed."""
        return False

    def has_delete_permission(self, request, obj=None):
        """ClaimAssignment records cannot be deleted."""
        return False

    @admin.display(description="Claim #")
    def claim_number_display(self, obj):
        return obj.claim.claim_number

    @admin.display(description="Assigned To")
    def assigned_to_display(self, obj):
        if obj.assigned_to:
            return f"{obj.assigned_to.employee_id} — {obj.assigned_to.username}"
        return "—"

    @admin.display(description="Assigned By")
    def assigned_by_display(self, obj):
        if obj.assigned_by:
            return obj.assigned_by.username
        return "System"


@admin.register(FollowUpEvent)
class FollowUpEventAdmin(admin.ModelAdmin):
    """
    Append-only log of every action taken by AR callers on claims.
    Cannot be edited or deleted — it is the permanent audit trail
    of all AR work.
    """
    list_display  = [
        "claim_number_display", "worked_by_display",
        "action_type", "sub_action_type",
        "activity_code", "worked_at",
    ]
    list_filter   = ["action_type", "client"]
    search_fields = [
        "claim__claim_number",
        "worked_by__employee_id",
        "worked_by__username",
    ]
    readonly_fields = [
        "id", "session", "client", "claim", "line_item",
        "worked_by", "action_type", "sub_action_type",
        "activity_code", "worked_at",
    ]
    ordering = ["-worked_at"]

    def has_add_permission(self, request):
        """FollowUpEvents are created by the follow-up workflow."""
        return False

    def has_change_permission(self, request, obj=None):
        """FollowUpEvent is append-only — no editing allowed."""
        return False

    def has_delete_permission(self, request, obj=None):
        """FollowUpEvent records cannot be deleted."""
        return False

    @admin.display(description="Claim #")
    def claim_number_display(self, obj):
        return obj.claim.claim_number

    @admin.display(description="Worked By")
    def worked_by_display(self, obj):
        if obj.worked_by:
            return f"{obj.worked_by.employee_id} — {obj.worked_by.username}"
        return "—"

@admin.register(FollowUpSession)
class FollowUpSessionAdmin(admin.ModelAdmin):
    """
    Append-only claim-level header for a follow-up working session.
    Holds the note, pending_on, and next_follow_up_date for the whole claim;
    per-line-item action are child FollowUpEvent rows. Cannot be edited or deleted.
    """
    list_display = [
        "claim_number_display", "worked_by_display",
        "pending_on", "next_follow_up_date", "logged_at",
    ]
    list_filter = ["pending_on", "client"]
    search_fields = [
        "claim__claim_number",
        "worked_by__employee_id",
        "worked_by__username",
        "note",
    ]
    readonly_fields = [
        "id", "client", "work_unit", "claim", "worked_by",
        "note", "pending_on", "next_follow_up_date", "logged_at",
    ]
    ordering = ["-logged_at"]

    def has_add_permission(self, request):
        return False
    
    def has_change_permission(self, request, obj=None):
        return False
    
    def has_delete_permission(self, request, obj=None):
        return False
    
    @admin.display(description="Claim #")
    def claim_number_display(self, obj):
        return obj.claim.claim_number
    
    @admin.display(description="Worked By")
    def worked_by_display(self, obj):
        return obj.worked_by.username if obj.worked_by else "System"
    

@admin.register(Escalation)
class EscalationAdmin(admin.ModelAdmin):
    """
    Escalations raised by AR callers for Team Lead review.
    Team Leads review escalations and set status to OKAY or ROUTED_BACK.
    """
    list_display  = [
        "claim_number_display", "escalated_by_display",
        "escalation_category", "handling_type",
        "status_badge", "reviewed_by_display",
        "escalated_at",
    ]
    list_filter   = ["status", "handling_type", "client"]
    search_fields = [
        "claim__claim_number",
        "reason",
        "escalated_by__employee_id",
        "escalated_by__username",
    ]
    readonly_fields = ["id", "escalated_at"]
    ordering = ["-escalated_at"]

    fieldsets = [
        ("Escalation", {
            "fields": [
                "claim", "work_unit", "client",
                "follow_up_event",
                "escalated_by", "escalation_category",
                "handling_type", "reason",
            ],
        }),
        ("Review", {
            "fields": [
                "status", "assigned_to",
                "reviewed_by", "review_notes", "reviewed_at",
            ],
        }),
        ("System", {
            "fields": ["id", "escalated_at"],
            "classes": ["collapse"],
        }),
    ]

    @admin.display(description="Claim #")
    def claim_number_display(self, obj):
        return obj.claim.claim_number

    @admin.display(description="Escalated By")
    def escalated_by_display(self, obj):
        if obj.escalated_by:
            return f"{obj.escalated_by.employee_id} — {obj.escalated_by.username}"
        return "—"

    @admin.display(description="Reviewed By")
    def reviewed_by_display(self, obj):
        if obj.reviewed_by:
            return obj.reviewed_by.username
        return "—"

    @admin.display(description="Status")
    def status_badge(self, obj):
        colors = {
            "Pending":     "#D97706",
            "Okay":        "#059669",
            "Routed Back": "#2563EB",
        }
        color = colors.get(obj.status, "#6B7280")
        return format_html(
            '<span style="color:{}; font-weight:bold;">{}</span>',
            color, obj.get_status_display(),
        )