from django.db import models, transaction
from django.db.models import F
import uuid
from django.core.exceptions import ValidationError
from django.core.exceptions import FieldDoesNotExist
from django.utils import timezone


def _field_exists_on_model(model_class, field_name: str) -> bool:
    """
    Returns True if field_name is a real column on model_class.

    Used by ClaimIdentityRule/LineItemIdentityRule.save() to detect
    whether a newly-created identity rule's field already has
    historical data sitting on the model — if so, an automatic
    backfill is triggered (Decision 9-A) instead of waiting for
    TRACKING to slowly re-capture it from future uploads.
    """
    try:
        model_class._meta.get_field(field_name)
        return True
    except FieldDoesNotExist:
        return False
    

#client table---------------------------------------------------------
class Client(models.Model):

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, verbose_name="Client ID")
    name = models.CharField(max_length=200, verbose_name="Client Name", help_text="Full legal name of the client organization")
    code = models.CharField(max_length=20, unique=True, verbose_name="Client Code", help_text='Short identifier like "ECA" or "ENTFW"')
    is_active = models.BooleanField(default=True, verbose_name="Active", help_text="Set to False to deactivate (never hard-delete for compliance)")
    created_at = models.DateTimeField(auto_now_add=True)
    deactivated_at = models.DateTimeField(null=True, blank=True, help_text="When this client was deactivated")

    class Meta:
        db_table = "client"
        ordering = ["name"]
        verbose_name_plural = "Clients"

    def __str__(self):
        return f"{self.code} — {self.name}"


#user table---------------------------------------------------------
class User(models.Model):
    
    class Role(models.TextChoices):
        AR = "AR", "Accounts Receivable Person (AR Person)"
        MANAGER = "Manager", "Manager"
        ADMIN = "Admin", "Administrator"
        LEADERSHIP = "Leadership", "Senior Leadership"
        TEAM_LEAD = "Team Lead", "Team Lead"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    employee_id =  models.CharField(max_length=10, unique=True, null=False)
    username = models.CharField(max_length=100)
    email = models.EmailField(max_length=150, unique=True)
    role = models.CharField(max_length=30, choices=Role.choices, default=Role.AR)
    manager = models.ForeignKey("self", on_delete=models.SET_NULL, null=True, blank=True, related_name="direct_reports", help_text="Their direct manager. NULL for top-level leadership")
    created_by = models.ForeignKey("self", on_delete=models.SET_NULL, null=True, blank=True, related_name="created_users", help_text="User who created this account. NULL for system-created or initial users.")
    is_active = models.BooleanField(default=True)
    last_login_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    deactivated_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "user"
        ordering = ["employee_id"]
        verbose_name_plural = "Users"

    def __str__(self):
        return f"{self.employee_id} ({self.get_role_display()})"



#process table---------------------------------------------------------
class Process(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=50)
    code = models.CharField(max_length=50, unique=True, help_text="Short name for the process, e.g., AR for Accounts Receivable")
    is_active = models.BooleanField(default=True)
    sort_order = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "process"
        ordering = ["sort_order", "name"]

    def __str__(self):
        return f"{self.name} ({self.code})"

    

#sub_process table---------------------------------------------------------
class SubProcess(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=50)
    code = models.CharField(max_length=50, unique=True)
    is_active = models.BooleanField(default=True)
    sort_order = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "sub_process"
        ordering = ["sort_order", "name"]

    def __str__(self):
        return f"{self.name} ({self.code})"
    


# work_unit table--------------------------------------------------------
class WorkUnit(models.Model):

    class IngestionMode(models.TextChoices):
        CLAIM_LEVEL = "CLAIM_LEVEL", "Claim-Level (one row per claim)"
        CPT_LEVEL = "CPT_LEVEL", "CPT-Level (one row per line item)"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name="work_units", help_text="The client this work unit belongs to")
    process = models.ForeignKey(Process, on_delete=models.CASCADE, related_name="work_units", help_text="The process, e.g., AR, Payment Posting, Charges, etc.")
    sub_process = models.ForeignKey(SubProcess, on_delete=models.CASCADE, related_name="work_units", help_text="The subprocess")
    ingestion_mode = models.CharField(max_length=20, choices=IngestionMode.choices, default=IngestionMode.CLAIM_LEVEL, help_text="How AR files for this work unit are structured")
    follow_up_window_days = models.IntegerField(default=30, help_text="The default gap before the claim resurfaces")
    daily_target = models.IntegerField(default=20, help_text="Daily productivity target: distinct claims per user per day")
    bucket_capacity = models.IntegerField(default=60, help_text="Not yet honored — MVP uses a global 60 cap")
    is_active = models.BooleanField(default=True, help_text="Set to False to disable a WorkUnit")
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="created_work_units", help_text="Admin who created this WorkUnit")
    created_at = models.DateTimeField(auto_now_add=True)
    deactivated_at = models.DateTimeField(null=True, blank=True, help_text="When this WorkUnit was disabled")

    class Meta:
        db_table = "work_unit"
        constraints = [models.UniqueConstraint(
            fields=["client", "process", "sub_process"],
            name="uq_workunit_client_process_subprocess"
        )]
        ordering = ["client__name", "process__name", "sub_process__name"]
        verbose_name = "Workunit"
        verbose_name_plural = "WorkUnits"

    def __str__(self):
        return f"{self.client.code} | {self.process.code} | {self.sub_process.code}"
    
    @property
    def display_name(self):
        return f"{self.client.name} - {self.process.name} - {self.sub_process.name}"
    


# user_workunit_mapping Table----------------------------------------------------
class UserWorkUnitMapping(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="workunit_mappings", help_text="The user being assigned to a WorkUnit")
    work_unit = models.ForeignKey(WorkUnit, on_delete=models.CASCADE, related_name="user_mappings", help_text="The WorkUnit this user is assigned to")
    assigned_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="workunit_assignments_made", help_text="Admin who assigned this user to the Workunit")
    assigned_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True, help_text="Set to False when user is removed from this WorkUnit")

    class Meta:
        db_table = "user_workunit_mapping"
        constraints = [models.UniqueConstraint(
            fields = ["user", "work_unit"],
            name="uq_user_workunit"
        )]
        ordering = ["user", "-assigned_at"]
        verbose_name = "User WorkUnit Mapping"
        verbose_name_plural = "User WorkUnit Mappings"

    def __str__(self):
        return f"{self.user} → {self.work_unit}"
    


# standard_field Table-----------------------------------------------------------------------------
class StandardField(models.Model):

    class DataType(models.TextChoices):
        STRING = "string", "String"
        NUMERIC = "numeric", "Numeric"
        DATE = "date", "Date"
        BOOLEAN = "boolean", "Boolean"

    class FieldCategory(models.TextChoices):
        REQUIRED = "required", "Required - must be mapped for every WorkUnit"
        OPTIONAL = "optional", "Optional - admin chooses whether to map"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    field_name = models.CharField(max_length=100, unique=True, help_text="Internal canonical field name, e.g., patient_name")
    display_name = models.CharField(max_length=200, help_text="Human-readable name shown in the UI dropdown")
    data_type = models.CharField(max_length=20, choices=DataType.choices, default=DataType.STRING, help_text="Expected data type. Used for validation during ingestion")
    category = models.CharField(max_length=20, choices=FieldCategory.choices, default=FieldCategory.OPTIONAL, help_text="Required or Optional")
    description = models.CharField(max_length=500, blank=True, default="", help_text="Explanation shown to admin during mapping")
    sort_order = models.IntegerField(default=0, help_text="Display order in the dropdown. Required field first")
    is_active = models.BooleanField(default=True, help_text="Set to false to hide from future configurations")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "standard_field"
        ordering = ["sort_order", "display_name"]
        verbose_name = "Standard Field"
        verbose_name_plural = "Standard Fields"

    def __str__(self):
        return f"{self.display_name} ({self.field_name}) [{self.get_category_display()}]"



#column_mapping table---------------------------------------------------------
class ColumnMapping(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    work_unit = models.ForeignKey(WorkUnit, on_delete=models.CASCADE, related_name="column_mappings")
    source_column_name = models.CharField(max_length=200, help_text='Header in the client\'s file, e.g., "Chg Amt"')
    standard_field = models.ForeignKey(StandardField, on_delete=models.PROTECT, related_name="column_mappings", help_text="The ARxTracker canonical field this source column maps to")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table="column_mapping"
        constraints = [
            models.UniqueConstraint(
                fields=["work_unit", "source_column_name"],
                name="uq_colmap_workunit_source"
            ),
            models.UniqueConstraint(
                fields=["work_unit", "standard_field"],
                name="uq_colmap_workunit_standard"
            )
        ]
        ordering = ["work_unit", "standard_field"]

    def __str__(self):
        return f"{self.work_unit}: {self.source_column_name} → {self.standard_field.field_name}"
    


#action_type table---------------------------------------------------------
class ActionType(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length = 100, help_text='Display name')
    code = models.CharField(max_length=50, unique=True, help_text='Machine-readable code')
    is_active = models.BooleanField(default=True)
    sort_order=models.IntegerField(default=0, help_text="Lower numbers appear first in dropdowns")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table="action_type"
        ordering=["sort_order", "name"]

    def __str__(self):
        return self.name



#sub_action_type table---------------------------------------------------------
class SubActionType(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    action_type = models.ForeignKey(ActionType, on_delete=models.CASCADE, related_name="sub_actions")
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=50, unique=True)
    is_active = models.BooleanField(default=True)
    sort_order = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "sub_action_type"
        ordering = ["sort_order", "name"]

    def __str__(self):
        return f"{self.action_type.name} → {self.name}"
    


#escalation_category table---------------------------------------------------------
class EscalationCategory(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=150, help_text="e.g., Medical Coding, Payer Not Responding")
    code = models.CharField(max_length=50, unique=True, help_text="Machine-readable code")
    is_active = models.BooleanField(default=True)
    sort_order = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "escalation_category"
        ordering = ["sort_order", "name"]
        verbose_name_plural = "Escalation Categories"

    def __str__(self):
        return self.name
    


#file_upload Table---------------------------------------------------------
class FileUpload(models.Model):

    class Status(models.TextChoices):
        PENDING = "Pending", "Pending - not yet processed"
        PROCESSING = "Processing", "Processing - worker is parsing"
        COMPLETED = "Completed", "Completed - all rows processed"
        FAILED = "Failed", "Failed - processing error"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    work_unit = models.ForeignKey(WorkUnit, on_delete=models.CASCADE, related_name="file_uploads")
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name="file_uploads")
    project = models.ForeignKey(
        "Project", on_delete=models.SET_NULL, null=True, blank=True, related_name="file_uploads",
        help_text="Which Project this upload was for, if it was a project-scoped upload. NULL for a regular AR upload." 
    )
    uploaded_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name="uploaded_files")
    file_name = models.CharField(max_length=255)
    file_hash = models.CharField(max_length=64, help_text="SHA-256 hash for deduplication")
    file_date = models.DateField(help_text="Business date this file represents")
    record_count = models.IntegerField(default=0)
    error_count = models.IntegerField(default=0)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    has_mass_resolution_warning = models.BooleanField(default=False)
    mass_resolution_warning_message = models.TextField(blank=True, default="")

    class Meta:
        db_table = "file_upload"
        unique_together = [("work_unit", "file_hash")]
        ordering = ["-uploaded_at"]

    def __str__(self):
        return f"{self.file_name} ({self.get_status_display()})"    
    


#claim table---------------------------------------------------------
class Claim(models.Model):
    
    class AgingBucket(models.TextChoices):
        BUCKET_0_30 = "0-30", "0-30 days"
        BUCKET_31_60 = "31-60", "31-60 days"
        BUCKET_61_90 = "61-90", "61-90 days"
        BUCKET_91_120 = "91-120", "91-120 days"
        BUCKET_121_180 = "121-180", "121-180 days"
        BUCKET_181_365 = "181-365", "181-365 days"
        BUCKET_365_PLUS = "365+", "365+ days"

    class PriorityTier(models.TextChoices):
        P1 = "P1", "P1 - Highest Priority"
        P2 = "P2", "P2"
        P3 = "P3", "P3"
        P4 = "P4", "P4"
        P5 = "P5", "P5 - Unclassified (default)"

    class LifecycleState(models.TextChoices):
        UNASSIGNED = "unassigned", "Unassigned — in the distribution pool, no owner"
        NEW_UNWORKED = "new_unworked", "New-Unworked — seated in an agent's Active Bucket, not yet worked"
        FOLLOW_UP_DUE = "follow_up_due", "Follow-Up Due — surfaced back into the Active Bucket"
        FOLLOW_UP_SCHEDULED = "follow_up_scheduled", "Follow-Up Scheduled — Deferred until next_follow_up_date"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    work_unit = models.ForeignKey(WorkUnit, on_delete=models.CASCADE, related_name="claims")
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name="claims")
    claim_number = models.CharField(max_length=1000, help_text="External Claim ID from billing systems")
    identity_values = models.JSONField(default=dict, blank=True, help_text="Raw identity field values used to generate claim_number")
    current_owner = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="owned_claims")
    account_number = models.CharField(max_length=100, null=True, blank=True)
    patient_id = models.CharField(max_length=100, null=True, blank=True)
    patient_name = models.CharField(max_length=200, null=True, blank=True)
    patient_dob = models.DateField(null=True, blank=True)
    service_date = models.DateField(null=True, blank=True, help_text="Date of medical service (DOS). Used to compute aging.")
    last_billed_date = models.DateField(null=True, blank=True)
    current_insurance = models.CharField(max_length=150, null=True, blank=True)
    primary_insurance = models.CharField(max_length=150, null=True, blank=True)
    secondary_insurance = models.CharField(max_length=150, null=True, blank=True)
    insurance_type = models.CharField(max_length=150, null=True, blank=True)
    group_no = models.CharField(max_length=150, null=True, blank=True)
    billing_provider_name = models.CharField(max_length=150, null=True, blank=True)
    billing_provider_npi = models.CharField(max_length=20, null=True, blank=True)
    rendering_provider = models.CharField(max_length=150, null=True, blank=True)
    rendering_provider_npi = models.CharField(max_length=20, null=True, blank=True)
    facility_location = models.CharField(max_length=150, null=True, blank=True)
    facility_location_state = models.CharField(max_length=50, null=True, blank=True)
    primary_dx_code = models.CharField(max_length=20, null=True, blank=True)
    current_charge = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True, help_text="Total charge amount. Updated in place.")
    current_balance = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True, help_text="Aggregate balance = sum of active line items current_balance")
    aging_days = models.IntegerField(null=True, blank=True, help_text="Derived from DOS on upload date, locked for audit")
    aging_bucket = models.CharField(max_length=20, choices=AgingBucket.choices, null=True, blank=True)
    priority_tier = models.CharField(max_length=5, choices=PriorityTier.choices, default=PriorityTier.P5 ,help_text="P1 = Highest Priority, and P5 = Unclassified")
    needs_priority_eval = models.BooleanField(
        default=True,
        help_text=(
            "True = this claim's data changed since priority_tier was last "
            "computed and it needs re-evaluation. Set True by ingestion "
            "(aggregate_claim_balances) whenever this claim is touched. "
            "Set False by the priority engine the moment it commits a new "
            "priority_tier for this claim. New claims start True — "
            "unclassified until first evaluated."
        ),
    )
    next_follow_up_date = models.DateTimeField(null=True, blank=True, db_index=True)
    original_assign_date = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="claims")
    last_upload = models.ForeignKey(FileUpload, on_delete=models.SET_NULL, null=True, blank=True, related_name="updated_claims", help_text="Which upload last updated this claim's data")
    is_active = models.BooleanField(
            null=True,
            blank=True,
            default=None,
            help_text=(
                "True = at least one active ClaimLineItem. False = fully "
                "resolved (all line items inactive). NULL = not yet computed "
                "for this claim (pre-existing claims awaiting backfill)."
            ),
        )
    lifecycle_state = models.CharField(
        max_length=30,
        choices=LifecycleState.choices,
        default=LifecycleState.UNASSIGNED,
        help_text=(
            "Stored allocation/work state, authoritative for the Allocation "
            "Engine and agent worklists. UNASSIGNED = in the distribution "
            "pool. NEW_UNWORKED = seated by an allocation run. FOLLOW_UP_DUE "
            "= a scheduled follow-up whose date has arrived (flipped by the "
            "daily surfacing step). FOLLOW_UP_SCHEDULED = worked and Deferred "
            "until next_follow_up_date. Resolution is signalled by "
            "is_active=False, NOT a lifecycle_state value — every lifecycle "
            "query must also filter is_active=True."
        ),
    )

    class Meta:
        db_table="claim"
        unique_together = [("work_unit", "claim_number")]
        indexes=[
            models.Index(fields=["client", "current_owner"], name="idx_claim_client_owner"),
            models.Index(fields=["current_owner", "priority_tier"], name="idx_claim_owner_priority"),
            models.Index(fields=["aging_bucket", "priority_tier"], name="idx_claim_aging_priority"),
            models.Index(fields=["work_unit", "current_owner"], name="idx_claim_workunit_owner"),
            models.Index(fields=["next_follow_up_date"], name="idx_claim_followup_date"),
            models.Index(fields=["work_unit", "needs_priority_eval", "is_active"], name="idx_claim_priority_dirty"),
            # Allocation Engine — Step 2 loads + Step 7 worklist (owner + state).
            models.Index(fields=["work_unit", "current_owner", "lifecycle_state"], name="idx_claim_owner_lifecycle"),
            # Allocation Engine — Step 1 follow-up surfacing (due scheduled follow-ups).
            models.Index(fields=["work_unit", "lifecycle_state", "next_follow_up_date"], name="idx_claim_surface_due"),
            # Allocation Engine — Step 4 capped unowned-pool read (sorted by priority, aging).
            models.Index(fields=["work_unit", "current_owner", "is_active", "priority_tier", "aging_days"], name="idx_claim_unowned_pool"),
        ]

    def __str__(self):
        return f"Claim {self.claim_number} | {self.patient_name or 'Unknown'} | Balance: {self.current_balance}"




#claim_line_item Table---------------------------------------------------------
class ClaimLineItem(models.Model):

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    claim = models.ForeignKey(Claim, on_delete=models.CASCADE, related_name="line_items", help_text="The parent claim this line item belongs to")
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name="line_items", help_text="Tenant isolation")  # Tenant Isolation
    work_unit = models.ForeignKey(WorkUnit, on_delete=models.CASCADE, related_name="line_items", help_text="WorkUnit scope - denormalized from claim")
    line_item_uid = models.CharField(max_length=500, unique=True, null=True, blank=True, help_text="System generated unique identifier for this line item")
    identity_values = models.JSONField(default=dict, blank=True, help_text="Raw line item identity field values used to generate line_item_uid")
    cpt_code = models.CharField(max_length=20, null=True, blank=True, help_text="CPT/procedure code. Null for Claim-Level uploads")
    resolution_date = models.DateTimeField(null=True, blank=True, help_text="When this line item was resolved (absent from AR feed)")
    archived_at = models.DateTimeField(null=True, blank=True, help_text="When this line item was archived (45 days past-resolution)")
    current_balance = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True, help_text="Outstanding balance from most recent upload. Updated in place")
    current_charge = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True, help_text="Charge amount from most recent upload. Updated in place")
    current_status = models.CharField(max_length=100, null=True, blank=True, help_text="Line item status from most recent upload. Updated in place")
    is_active = models.BooleanField(default=True, help_text="True = present in the most recent upload. False = absent from most recent upload")
    first_seen_at = models.DateTimeField(auto_now_add=True, help_text="When this line item first appeared in any upload")
    last_updated_at = models.DateTimeField(auto_now=True, help_text="When this record was last updated by an upload")
    
    class Meta:
        db_table = "claim_line_item"
        constraints = []
        indexes = [
            models.Index(fields=["claim", "is_active"], name="idx_lineitem_claim_active"),
            models.Index(fields=["client"], name="idx_lineitem_client"),
            models.Index(fields=["work_unit"], name="idx_lineitem_workunit"),
            models.Index(fields=["cpt_code"], name="idx_lineitem_cpt"),
        ]

    def __str__(self):
        if self.cpt_code:
            return(f"{self.line_item_uid} | CPT {self.cpt_code} | Balance: {self.current_balance}")   
        
        return f"{self.line_item_uid} | Balance: {self.current_balance}"
        
    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)
    


# project Table-------------------------------------------------------------------------------
class Project(models.Model):

    class Status(models.TextChoices):
        ACTIVE = "active", "Active - claims elevated to P0"
        COMPLETED = "completed", "Completed - all claims resolved"
        CANCELLED = "cancelled", "Cancelled - closed before completion"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    work_unit = models.ForeignKey(WorkUnit, on_delete=models.CASCADE, related_name="projects", help_text="The WorkUnit this project belongs to")
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name="projects", help_text="Tenant isolation - denormalized from work_unit") # Tenant Isolation
    name = models.CharField(max_length=500, help_text="Descriptive name of the Project")
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.ACTIVE, help_text="ACTIVE claims are elevated to P0 at display time. COMPLETED/CANCELLED claims lose P0 immediately.")
    total_line_items = models.IntegerField(default=0, help_text="Total line items across every claim in this project. Set once, when the one-time upload completes.")
    worked_line_items = models.IntegerField(default=0, help_text="Line items resolved through the feed since claims_locked_at. Auto-closes the project to COMPLETED when this equals total_line_items.")
    claims_locked_at = models.DateTimeField(null=True, blank=True, help_text="When the one-time upload completed and the claim set became permanent. NULL until the upload finishes.")
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="created_projects", help_text="Manager who created this project")
    created_at = models.DateTimeField(auto_now_add=True)
    closed_at = models.DateTimeField(null=True, blank=True, help_text="When status transitioned away from ACTIVE, either COMPLETED or CANCELLED")

    class Meta:
        db_table = "project"
        ordering = ["-created_at"]
        verbose_name = "Project"
        verbose_name_plural = "Projects"

    def __str__(self):
        return f"{self.name} ({self.work_unit}) - {self.get_status_display()}"



# project_claim Table------------------------------------------------------------------------
class ProjectClaim(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="project_claims", help_text="The project this claim belongs to")
    claim = models.ForeignKey(Claim, on_delete=models.CASCADE, related_name="project_claims", help_text="The claim elevated by this project")
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name="project_claims", help_text="Tenant isolation") # Tenant Isolation
    added_at = models.DateTimeField(auto_now_add=True, help_text="When this claim was linked to the project, during the one-time upload")
    total_line_items = models.IntegerField(default=0, help_text="How many active line items this claim had when it joined the project. Set once, at upload time")
    worked_line_items = models.IntegerField(default=0, help_text="How many of this claim's line items have been worked (first follow-up or resolution) since the project started.")

    class Meta:
        db_table = "project_claim"
        constraints = [models.UniqueConstraint(
            fields=["project", "claim"],
            name="uq_projectclaim_project_claim"
        )]
        ordering = ["project", "-added_at"]
        verbose_name = "Project Claim"
        verbose_name_plural = "Project Claims"

    def __str__(self):
        return f"{self.claim.claim_number} → {self.project.name}"



#claim_assignment Table (Append Only)---------------------------------------------------------
class ClaimAssignment(models.Model):

    class Bucket(models.TextChoices):
        ACTIVE = "active", "Active Bucket (New-Unworked + Follow-Up Due, 60 cap)"
        DEFERRED = "deferred", "Deferred Bucket (Follow-Up Scheduled, uncapped)"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name="assignments") # For Tenant Isolation
    work_unit = models.ForeignKey(WorkUnit, on_delete=models.CASCADE, related_name="claim_assignment")
    claim = models.ForeignKey(Claim, on_delete=models.CASCADE, related_name="assignments")
    assigned_to = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="claim_assignments")
    assigned_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="assignments_made", help_text="NULL = system")
    bucket = models.CharField(max_length=30, choices=Bucket.choices)
    assigned_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "claim_assignment"
        indexes = [
            models.Index(fields=["assigned_to", "assigned_at"], name="idx_assign_user_date"),
            models.Index(fields=["claim"], name="idx_assign_claim"),
        ]

    def __str__(self):
        return f"Claim {self.claim.claim_number} → {self.assigned_to} ({self.bucket})"
    
    def save(self, *args, **kwargs):
        if self.pk:
            raise ValueError("ClaimAssignment is append-only")
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise ValueError("ClaimAssignment records cannot be deleted.")



# follow_up_session Table (Append Only)-----------------------------------------------------

class FollowUpSession(models.Model):
    """
    One agent working session on one claim, 
    the claim-level header for a follow-up
    """

    class PendingOn(models.TextChoices):
        PAYER = "Payer", "Waiting on Payer"
        PATIENT = "Patient", "Waiting on Patient"
        PROVIDER = "Provider", "Waiting on Provider"
        INTERNAL = "Internal", "Internal Processing"
        NONE = "None", "No Pending Action"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name="follow_up_sessions", help_text="Tenant isolation")
    work_unit = models.ForeignKey(WorkUnit, on_delete=models.CASCADE, related_name="follow_up_sessions")
    claim = models.ForeignKey(Claim, on_delete=models.CASCADE, related_name="follow_up_sessions")
    worked_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="follow_up_sessions", help_text="The agent who worked the claim in this session")
    note = models.TextField(blank=True, help_text="Claim-level note for this session. One per session, never per line item.")
    pending_on = models.CharField(max_length=50, choices=PendingOn.choices)
    next_follow_up_date = models.DateTimeField(help_text="When to revisit this claim. Shared across every line item worked in this session.")
    logged_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "follow_up_session"
        ordering = ["-logged_at"]
        indexes = [
            models.Index(fields=["claim", "logged_at"], name="idx_fus_claim_date"),
            models.Index(fields=["worked_by", "logged_at"], name="idx_fus_user_date"),
            models.Index(fields=["client"], name="idx_fus_client"),
        ]

    def __str__(self):
        who = self.worked_by.username if self.worked_by else "System"
        return f"Session on {self.claim.claim_number} by {who} @ {self.logged_at:%Y-%m-%d %H:%M}"
    
    def save(self, *args, **kwargs):
        if self.pk and FollowUpSession.objects.filter(pk=self.pk).exists():
            raise ValueError("FollowUpSession records are immutable.")
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise ValueError("FollowUpSession records cannot be deleted.")




#follow_up_event Table (Append Only)---------------------------------------------------------
class FollowUpEvent(models.Model):

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    session = models.ForeignKey(FollowUpSession, on_delete=models.CASCADE, related_name="events", help_text="The claim-level session this line-item action belongs to")
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name="follow_up_events", help_text="Tenant isolation")  # Tenant Isolation
    claim = models.ForeignKey(Claim, on_delete=models.CASCADE, related_name="follow_up_events")
    line_item = models.ForeignKey(ClaimLineItem, on_delete=models.CASCADE, related_name="follow_up_events", help_text="The specific line item this action was taken on")
    worked_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="follow_up_events")
    action_type = models.ForeignKey(ActionType, on_delete=models.PROTECT, related_name="follow_up_events")
    sub_action_type = models.ForeignKey(SubActionType, on_delete=models.PROTECT, related_name="follow_up_events")
    activity_code = models.CharField(max_length = 100, null=True, blank=True, help_text="The activity action taken, eg., Called Payer")
    worked_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "follow_up_event"
        indexes = [
            models.Index(fields=["claim", "worked_at"], name="idx_fue_claim_date"),
            models.Index(fields=["line_item", "worked_at"], name="idx_fue_lineitem_date"),
            models.Index(fields=["worked_by", "worked_at"], name="idx_fue_user_date"),
            models.Index(fields=["session"], name="idx_fue_session"),
            models.Index(fields=["client"], name="idx_fue_client")
        ]

    def __str__(self):
        who = self.worked_by.username if self.worked_by else "System"
        return f"{self.action_type.name} on {self.line_item} by {who}"
    
    def save(self, *args, **kwargs):
        if self.pk and FollowUpEvent.objects.filter(pk=self.pk).exists():
            raise ValueError("FollowUpEvent records are immutable.")
        
        # Derive denormalized fields from the parent session so they can never
        # drift out of sync with it. Callers set only session + line-item fields.
        if self.session_id:
            self.claim_id      = self.session.claim_id
            self.client_id     = self.session.client_id
            self.worked_by_id  = self.session.worked_by_id

        super().save(*args, **kwargs)

        with transaction.atomic():
            active_project_claims = ProjectClaim.objects.filter(
                claim_id=self.claim_id,
                project__status=Project.Status.ACTIVE,
            ).select_related("project")

            for project_claim in active_project_claims:
                claims_locked_at = project_claim.project.claims_locked_at
                if claims_locked_at is None:
                    continue

                already_touched = FollowUpEvent.objects.filter(
                    line_item_id=self.line_item_id,
                    worked_at__gte=claims_locked_at,
                ).exclude(pk=self.pk).exists()

                already_resolved = ClaimLineItem.objects.filter(
                    pk=self.line_item_id,
                    is_active=False,
                    resolution_date__gte=claims_locked_at,
                    resolution_date__lt=self.worked_at,
                ).exists()

                if already_touched or already_resolved:
                    continue

                ProjectClaim.objects.filter(pk=project_claim.pk).update(
                    worked_line_items=F("worked_line_items") + 1
                )
                Project.objects.filter(pk=project_claim.project_id).update(
                    worked_line_items=F("worked_line_items") + 1
                )

                updated_project = Project.objects.get(pk=project_claim.project_id)
                if (
                    updated_project.status == Project.Status.ACTIVE
                    and updated_project.total_line_items > 0
                    and updated_project.worked_line_items >= updated_project.total_line_items
                ):
                    Project.objects.filter(
                        pk=updated_project.pk, status=Project.Status.ACTIVE
                    ).update(
                        status=Project.Status.COMPLETED,
                        closed_at=timezone.now()
                    )

    def delete(self, *args, **kwargs):
        raise ValueError("FollowUpEvent records cannot be deleted")



#escalation Table---------------------------------------------------------
class WorkUnitEscalationMapping(models.Model):

    class HandlingType(models.TextChoices):
        INTERNAL = "Internal", "Internal - handled within the organisation"
        EXTERNAL = "External", "External - handled by client"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    work_unit = models.ForeignKey(WorkUnit, on_delete=models.CASCADE, related_name="escalation_mappings", help_text="The WorkUnit this escalation category is enabled for")
    escalation_category = models.ForeignKey(EscalationCategory, on_delete=models.CASCADE, related_name="workunit_mappings", help_text="The global escalation category")
    handling_type = models.CharField(max_length=20, choices=HandlingType.choices, help_text="Internal = Organisation handles it. External = client handles it.")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "workunit_escalation_mapping"
        constraints = [models.UniqueConstraint(
            fields=["work_unit", "escalation_category"],
            name="uq_workunit_escalation"
        )]
        ordering = ["work_unit", "escalation_category"]
        verbose_name = "WorkUnit Escalation Mapping"
        verbose_name_plural = "WorkUnit Escalation Mappings"

    def __str__(self):
        return f"{self.work_unit} | {self.escalation_category.name} ({self.handling_type})"
    


# escalation Table-------------------------------------------------------------
class Escalation(models.Model):

    class Status(models.TextChoices):
        PENDING = "Pending", "Pending - awaiting review"
        APPROVED = "Approved", "Approved - claim stays in Deferred"
        DENIED = "Denied", "Denied - Claim returns to user's Active Bucket"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    claim = models.ForeignKey(Claim, on_delete=models.CASCADE, related_name="escalations")
    follow_up_event = models.ForeignKey(FollowUpEvent, on_delete=models.CASCADE, related_name="escalation", help_text="The FollowUpEvent that triggered this escalation")
    escalated_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="escalations_raised")
    escalation_category = models.ForeignKey(EscalationCategory, on_delete=models.PROTECT, related_name="escalations", help_text="The category the user selected from the WorkUnit's enabled categories")
    handling_type = models.CharField(max_length=20, choices=WorkUnitEscalationMapping.HandlingType.choices, help_text="Internal or External - captured at escalation time from WorkUnit config.")
    reason = models.TextField(help_text="Why this was escalated (required)")
    assigned_to = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="escalation_queue", help_text="The user responsible for reviewing this escalation")
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    reviewed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="escalations_reviewed", help_text="The user who actually reviewed")
    review_notes = models.TextField(blank=True, null=True)
    reviewed_at = models.DateTimeField(null=True, blank=True)
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name="escalations", help_text="Tenant isolation - denormalized for RLS")  # Tenant Isolation
    work_unit = models.ForeignKey(WorkUnit, on_delete=models.CASCADE, related_name="escalations")
    escalated_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "escalation"
        indexes = [
            models.Index(fields=["status", "escalated_at"], name="idx_esc_status_date"),
            models.Index(fields=["assigned_to", "status"], name="idx_esc_tl_queue"),
            models.Index(fields=["client"], name="idx_esc_client"),
            models.Index(fields=["claim"], name="idx_esc_claim"),
        ]

    def __str__(self):
        return f"Escalation on {self.claim} - {self.get_status_display()}"

    

#claim_identity_rule Table---------------------------------------------------------
class ClaimIdentityRule(models.Model):

    class Status(models.TextChoices):
        ACTIVE = "active", "Active - used for UID generation and matching"
        TRACKING = "tracking", "Tracking - captured into identity_values, not yet used for UID"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    work_unit = models.ForeignKey(WorkUnit, on_delete=models.CASCADE, related_name="identity_rules", help_text="The WorkUnit this identity rule belongs to")
    standard_field_name = models.CharField(max_length=100, help_text="The canonical field that participates in UID creation")
    field_order = models.IntegerField(default=1, help_text="Order in which fields are combined to generate UID(1-4)")
    status = models.CharField(
        max_length=20, 
        choices=Status.choices, 
        blank=True, 
        help_text=(
            "ACTIVE fields are used to generate the claim UID and match "
            "incoming file rows. TRACKING fields are captured into "
            "identity_values on every ingestion but not yet used for "
            "UID generation — used during a transition window before "
            "activating a new identity field across the whole population."
        ),
    )

    class Meta:
        db_table = "claim_identity_rule"
        constraints = [models.UniqueConstraint(
            fields = ["work_unit", "standard_field_name"],
            name="uq_identity_rule_workunit_field"
        )]
        ordering = ["work_unit", "field_order"]

    def save(self, *args, **kwargs):
        is_new = self._state.adding

        if is_new and not self.status:
            has_ingested_before = FileUpload.objects.filter(
                work_unit=self.work_unit,
                status=FileUpload.Status.COMPLETED,
            ).exists()

            if has_ingested_before:
                self.status = ClaimIdentityRule.Status.TRACKING
            else:
                self.status = ClaimIdentityRule.Status.ACTIVE

        super().save(*args, **kwargs)

        if (
            is_new
            and self.status == ClaimIdentityRule.Status.TRACKING
            and _field_exists_on_model(Claim, self.standard_field_name)
        ):
            from core.services.config_change import backfill_identity_values
            backfill_identity_values(
                work_unit=self.work_unit,
                field_name=self.standard_field_name,
                source=self.standard_field_name,
                target_model="claim",
            )



# line_item_identity_rule Table-----------------------------------------------------------------------------
class LineItemIdentityRule(models.Model):

    class Status(models.TextChoices):
        ACTIVE   = "active",   "Active — used for UID generation and matching"
        TRACKING = "tracking", "Tracking — captured into identity_values, not yet used for UID"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    work_unit = models.ForeignKey(WorkUnit, on_delete=models.CASCADE, related_name="line_item_identity_rules", help_text="The WorkUnit this rule belongs to. Must be CPT-Level.")
    standard_field_name = models.CharField(max_length=100, help_text="The CPT-level canonical field used in UID generation.")
    field_order = models.IntegerField(default=1, help_text="Position of this field in the UID")
    allow_blank = models.BooleanField(default=False, help_text="If checked, a blank value in this field is treated as meaningful data")
    status = models.CharField(
        max_length=20,
        choices=Status.choices,
        blank=True,
        help_text=(
            "ACTIVE fields are used to generate the line item UID. "
            "TRACKING fields are captured into identity_values but not "
            "yet used for UID generation — used during a transition "
            "window before activating a new identity field."
        ),
    )
    
    class Meta:
        db_table = "line_item_identity_rule"
        constraints = [models.UniqueConstraint(
            fields=["work_unit", "standard_field_name"],
            name="uq_li_identity_rule_workunit_field"
        )]
        ordering = ["work_unit", "field_order"]
        verbose_name = "Line Item Identity Rule"
        verbose_name_plural = "Line Item Identity Rules"

    def __str__(self):
        return(
            f"{self.work_unit}: LI field {self.field_order}"
            f" → {self.standard_field_name}"
        )

    def save(self, *args, **kwargs):
        if self.work_unit.ingestion_mode != WorkUnit.IngestionMode.CPT_LEVEL:
            raise ValueError(
                f"WorkUnit '{self.work_unit}' is Claim-Level. "
                f"LineItemIdentityRule only applies to CPT-Level WorkUnits. "
                f"Claim-Level WorkUnits use the claim UID as the line item UID."
            )
        super().save(*args, **kwargs)



# ConfigChangeLog table--------------------------------------------

class ConfigChangeLog(models.Model):

    class ChangeType(models.TextChoices):
        CLAIM_IDENTITY = "claim_identity", "Claim Identity Rules Changed"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    work_unit = models.ForeignKey(WorkUnit, on_delete=models.CASCADE, related_name="config_changes")
    change_type = models.CharField(max_length=50, choices=ChangeType.choices, default=ChangeType.CLAIM_IDENTITY)
    old_rules = models.JSONField(help_text="Snapshot of identity rules before the change")
    new_rules = models.JSONField(help_text="Snapshot of identity rules after the change")

    # Active claims - the population the 95% threshold is measured against
    active_claims_total = models.IntegerField(default=0)
    active_claims_recomputed = models.IntegerField(default=0)
    active_claims_blocked = models.IntegerField(default=0)

    # Resolved/archived claims - reported, but excluded from the threshold
    resolved_claims_total = models.IntegerField(default=0)
    resolved_claims_recomputed = models.IntegerField(default=0)
    resolved_claims_blocked = models.IntegerField(default=0)

    line_items_recomputed = models.IntegerField(
        default=0,
        help_text=(
            "Always 0 — config versioning is claim-level only. "
            "Kept for backward compatibility with audit log schema."
        ),
    )
    threshold_percent = models.DecimalField(max_digits=5, decimal_places=2, default=95.00, help_text="The active-claims threshold to allow this change")
    achieved_percent = models.DecimalField(max_digits=5, decimal_places=2, help_text="The actual active-claims recompute percentage achieved")
    changed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="config_changes")
    changed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "config_change_log"
        ordering = ["-changed_at"]
        verbose_name = "Config Change Log"
        verbose_name_plural = "Config Change Logs"

    def __str__(self):
        return (
            f"{self.work_unit} | {self.get_change_type_display()} | "
            f"{self.achieved_percent}% | "
            f"{self.changed_at.strftime('%Y-%m-%d %H:%M') if self.changed_at else 'pending'}"
        )
    


# priority_rule table----------------------------------------------------------------------------------

class PriorityRule(models.Model):

    CONFIGURABLE_TIERS = [
        (Claim.PriorityTier.P1, Claim.PriorityTier.P1.label),
        (Claim.PriorityTier.P2, Claim.PriorityTier.P2.label),
        (Claim.PriorityTier.P3, Claim.PriorityTier.P3.label),
        (Claim.PriorityTier.P4, Claim.PriorityTier.P4.label),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    work_unit = models.ForeignKey(WorkUnit, on_delete=models.CASCADE, related_name="priority_rules")
    priority_tier = models.CharField(max_length=5, choices=CONFIGURABLE_TIERS, help_text="The tier this rule classifies claims into")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "priority_rule"
        constraints = [
            models.UniqueConstraint(
                fields=["work_unit", "priority_tier"],
                name="uq_priority_rule_workunit_tier"
            )
        ]
        ordering = ["work_unit", "priority_tier"]

    def __str__(self):
        return f"{self.work_unit} | {self.priority_tier}"
    


# priority_condition_group Table----------------------------------------------------------------------------

class PriorityConditionGroup(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    rule = models.ForeignKey(PriorityRule, on_delete=models.CASCADE, related_name="condition_groups")
    group_order = models.PositiveIntegerField(default=1)
    label = models.CharField(max_length=200,blank=True)

    class Meta:
        db_table = "priority_condition_group"
        ordering = ["rule", "group_order"]

    def __str__(self):
        label_part = f" — {self.label}" if self.label else ""
        return f"{self.rule} | Group {self.group_order}{label_part}"



# priority_condition Table-----------------------------------------------------------------------------------

class PriorityCondition(models.Model):

    class Operator(models.TextChoices):
        EQ = "eq", "Equals"
        NEQ = "neq", "Not Equals"
        GT = "gt", "Greater Than"
        GTE = "gte", "Greater Than or Equal"
        LT = "lt", "Less Than"
        LTE = "lte", "Less Than or Equal"
        IN = "in", "In List"
        NOT_IN = "not_in", "Not in List"
        BETWEEN = "between", "Between (inclusive)"
        IS_NULL = "is_null", "Is Null / Is Not Null"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    group = models.ForeignKey(PriorityConditionGroup, on_delete=models.CASCADE, related_name="conditions")
    field_name = models.CharField(max_length=100, help_text="The Claim model attribute to evaluate, e.g. 'aging_days")
    operator = models.CharField(max_length=20, choices=Operator.choices, help_text="The comparison operator")
    value = models.CharField(max_length=500, blank=True, help_text="Always stored as a string regardless of the field's actual type")
    value2 = models.CharField(max_length=500, blank=True, help_text="Upper bound for between operator only ")

    class Meta:
        db_table = "priority_condition"
        ordering = ["group", "id"]

    def clean(self):
        from core.services.priority.operators import (
            FIELD_TYPE_MAP, VALID_OPERATORS, CASTERS
        )

        # Check 1: is field_name a valid evaluatable field?
        if self.field_name not in FIELD_TYPE_MAP:
            raise ValidationError(
                f"'{self.field_name}' is not a valid evaluatable claim field. "
                f"Valid fields: {sorted(FIELD_TYPE_MAP.keys())}"
            )
        
        # Check 2 : Is the operator for this field type?
        field_type = FIELD_TYPE_MAP[self.field_name]
        if self.operator not in VALID_OPERATORS.get(field_type, set()):
            raise ValidationError(
                f"Operator '{self.operator}' is not valid for field "
                f"'{self.field_name}' (type: {field_type}). "
                f"Valid operators: {sorted(VALID_OPERATORS[field_type])}"
            )
        
        # Check 3: IS_NULL exists early
        if self.operator == self.Operator.IS_NULL:
            if str(self.value).strip().lower() not in (
                "true", "false", "1", "0", "yes", "no"
            ):
                raise ValidationError(
                    f"IS_NULL requires value to be 'true' or 'false' "
                    f"(got '{self.value}')."
                )
            return
        
        # Check 4: Is value non-empty for non-IS_NULL operators?
        if not self.value.strip():
            raise ValidationError(
                f"Value is required for operator '{self.operator}'."
            )
        
        # Check 5: Can value be cast to the correct type?
        caster = CASTERS.get(field_type)
        try:
            if self.operator in (self.Operator.IN, self.Operator.NOT_IN):
                [caster(v.strip()) for v in self.value.split(",") if v.strip()]
            else:
                caster(self.value.strip())
        except Exception as e:
            raise ValidationError(
                f"Value '{self.value}' cannot be converted to "
                f"{field_type} for field '{self.field_name}': {e}"
            )
        
        # Check 6:  BETWEEN requires value2, and lower must be less than upper
        if self.operator == self.Operator.BETWEEN:
            if not self.value2.strip():
                raise ValidationError(
                    "value2 (upper bound) is required for BETWEEN operator."
                )
            try:
                lower = caster(self.value.strip())
                upper = caster(self.value2.strip())
                if lower >= upper:
                    raise ValidationError(
                        f"BETWEEN lower bound ({self.value}) must be "
                        f"less than upper bound ({self.value2})."
                    )
            except ValidationError:
                raise
            except Exception as e:
                raise ValidationError(
                    f"value2 '{self.value2}' cannot be converted to "
                    f"{field_type}: {e}"
                )
            
    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return (
            f"{self.group} | "
            f"{self.field_name} {self.operator} {self.value}"
        )