"""
test_allocation_integration.py — End-to-end tests across both packages.

Everything above this file tests one layer in isolation. This file tests the
seams, which is where the last four rounds of defects actually lived:

    - run_allocation()  : loader → engine → committer, wired together
    - the two-step flow : surfacing (Step 1) must commit before allocation
                          (Step 2) reads agent loads, or capacity is wrong
    - allocate_claims   : the management command that operators actually run,
                          including its flags and its failure paths

The command tests are the ones that would have caught the reviews' worst
finding — a command calling run_allocation() with a parameter that no longer
existed, and reading six summary keys that were never produced. Calling
through call_command() exercises argument parsing, orchestration, summary-key
access and output rendering in one shot.
"""

from io import StringIO

import pytest
from django.core.management import CommandError, call_command
from django.utils import timezone

from core.models import Claim, ClaimAssignment, Project
from core.services.allocation import run_allocation
from core.services.allocation.exceptions import NoEligibleAgentsError

pytestmark = [pytest.mark.django_db, pytest.mark.integration]

LS = Claim.LifecycleState


def run_command(*args, **kwargs):
    """Runs allocate_claims and returns its stdout."""
    out = StringIO()
    call_command("allocate_claims", *args, stdout=out, stderr=StringIO(), **kwargs)
    return out.getvalue()


# ── run_allocation: the facade ───────────────────────────────────────────────

class TestRunAllocationHappyPath:

    def test_seats_the_pool_and_writes_everything(
        self, work_unit, make_agent, make_claims
    ):
        agent = make_agent(work_unit)
        make_claims(work_unit, 5)

        summary = run_allocation(work_unit)

        assert summary["claims_assigned"] == 5
        assert summary["claims_written"] == 5
        assert summary["assignments_created"] == 5
        assert Claim.objects.filter(
            current_owner=agent, lifecycle_state=LS.NEW_UNWORKED
        ).count() == 5
        assert ClaimAssignment.objects.count() == 5

    def test_summary_contract_keys_are_stable(
        self, work_unit, make_agent, make_claims
    ):
        """allocate_claims.py reads these by name — all must exist."""
        make_agent(work_unit)
        make_claims(work_unit, 2)

        assert set(run_allocation(work_unit)) == {
            "work_unit", "work_unit_id", "project", "dry_run", "assigned_by",
            "bucket_cap", "agents_eligible", "pool_size", "claims_assigned",
            "claims_unassigned", "unassigned_claim_ids", "agents_at_capacity",
            "claims_written", "claims_skipped", "assignments_created",
            "elapsed_seconds",
        }

    def test_respects_the_cap_end_to_end(
        self, work_unit, make_agent, make_claim, make_claims
    ):
        """One agent at 58/60 gets exactly 2 more, no matter the backlog."""
        agent = make_agent(work_unit)
        for _ in range(58):
            make_claim(work_unit, lifecycle_state=LS.NEW_UNWORKED,
                       current_owner=agent)
        make_claims(work_unit, 30)

        summary = run_allocation(work_unit)

        assert summary["claims_assigned"] == 2
        assert Claim.objects.filter(current_owner=agent).count() == 60

    def test_distributes_most_loaded_first_across_real_agents(
        self, work_unit, make_agent, make_claim, make_claims
    ):
        busy, idle = make_agent(work_unit), make_agent(work_unit)
        for _ in range(57):
            make_claim(work_unit, lifecycle_state=LS.NEW_UNWORKED,
                       current_owner=busy)
        make_claims(work_unit, 5)

        run_allocation(work_unit)

        assert Claim.objects.filter(
            current_owner=busy, lifecycle_state=LS.NEW_UNWORKED
        ).count() == 60                      # topped off first
        assert Claim.objects.filter(current_owner=idle).count() == 2

    def test_assigned_by_is_recorded_on_the_audit_rows(
        self, work_unit, make_agent, make_claim
    ):
        make_agent(work_unit)
        manager = make_agent(work_unit)
        make_claim(work_unit)

        run_allocation(work_unit, assigned_by=manager)

        assert ClaimAssignment.objects.first().assigned_by_id == manager.id

    def test_empty_pool_is_a_no_op_not_an_error(self, work_unit, make_agent):
        make_agent(work_unit)

        summary = run_allocation(work_unit)

        assert summary["claims_assigned"] == 0
        assert summary["pool_size"] == 0


class TestRunAllocationDryRun:

    def test_dry_run_writes_absolutely_nothing(
        self, work_unit, make_agent, make_claims
    ):
        make_agent(work_unit)
        claims = make_claims(work_unit, 4)

        summary = run_allocation(work_unit, dry_run=True)

        assert summary["claims_assigned"] == 4      # would seat 4
        assert summary["claims_written"] == 0       # but wrote none
        assert ClaimAssignment.objects.count() == 0
        for claim in claims:
            claim.refresh_from_db()
            assert claim.current_owner_id is None
            assert claim.lifecycle_state == LS.UNASSIGNED


class TestRunAllocationFailureModes:

    def test_no_eligible_agents_raises(self, work_unit, make_claims):
        make_claims(work_unit, 3)

        with pytest.raises(NoEligibleAgentsError):
            run_allocation(work_unit)

    def test_only_ineligible_staff_raises(
        self, work_unit, make_agent, make_claims
    ):
        from core.models import User

        make_agent(work_unit, role=User.Role.MANAGER)
        make_agent(work_unit, role=User.Role.TEAM_LEAD)
        make_claims(work_unit, 3)

        with pytest.raises(NoEligibleAgentsError):
            run_allocation(work_unit)


class TestRunAllocationProjectScope:

    def test_project_run_seats_only_that_projects_claims(
        self, work_unit, make_agent, make_claim, make_project,
        add_claim_to_project
    ):
        make_agent(work_unit)
        project = make_project(work_unit)
        member = make_claim(work_unit)
        add_claim_to_project(project, member)
        ordinary = make_claim(work_unit)

        run_allocation(work_unit, project=project)

        member.refresh_from_db()
        ordinary.refresh_from_db()
        assert member.current_owner_id is not None
        assert ordinary.current_owner_id is None

    def test_daily_run_leaves_active_project_claims_alone(
        self, work_unit, make_agent, make_claim, make_project,
        add_claim_to_project
    ):
        make_agent(work_unit)
        elevated = make_claim(work_unit)
        add_claim_to_project(make_project(work_unit), elevated)
        ordinary = make_claim(work_unit)

        run_allocation(work_unit)

        elevated.refresh_from_db()
        ordinary.refresh_from_db()
        assert elevated.current_owner_id is None
        assert ordinary.current_owner_id is not None

    def test_project_name_is_reported_in_the_summary(
        self, work_unit, make_agent, make_project
    ):
        make_agent(work_unit)
        project = make_project(work_unit, name="Q3 Audit Push")

        summary = run_allocation(work_unit, project=project)

        assert summary["project"] == "Q3 Audit Push"


# ── The two-step ordering contract ───────────────────────────────────────────

class TestSurfacingBeforeAllocationOrdering:
    """
    load_agent_loads() counts FOLLOW_UP_DUE toward capacity, so surfacing must
    commit BEFORE allocation reads loads. These tests pin the consequence in
    both directions — this is the coupling the packages depend on and neither
    can enforce alone.
    """

    def test_surfacing_first_reduces_the_capacity_available_to_new_work(
        self, work_unit, make_agent, make_scheduled_claim, make_claims
    ):
        agent = make_agent(work_unit)
        for _ in range(10):
            make_scheduled_claim(work_unit, agent, days_offset=-1)
        make_claims(work_unit, 60)

        run_command("--work-unit", str(work_unit.id))

        # 10 seats consumed by surfaced follow-ups → only 50 new claims seated
        assert Claim.objects.filter(
            current_owner=agent, lifecycle_state=LS.FOLLOW_UP_DUE
        ).count() == 10
        assert Claim.objects.filter(
            current_owner=agent, lifecycle_state=LS.NEW_UNWORKED
        ).count() == 50

    def test_skipping_surfacing_leaves_that_capacity_available(
        self, work_unit, make_agent, make_scheduled_claim, make_claims
    ):
        """The mirror image: without Step 1 those 10 claims stay deferred,
        so all 60 seats go to new work."""
        agent = make_agent(work_unit)
        for _ in range(10):
            make_scheduled_claim(work_unit, agent, days_offset=-1)
        make_claims(work_unit, 60)

        run_command("--work-unit", str(work_unit.id), "--skip-surfacing")

        assert Claim.objects.filter(
            current_owner=agent, lifecycle_state=LS.FOLLOW_UP_SCHEDULED
        ).count() == 10
        assert Claim.objects.filter(
            current_owner=agent, lifecycle_state=LS.NEW_UNWORKED
        ).count() == 60

    def test_an_agent_full_of_due_follow_ups_receives_no_new_work(
        self, work_unit, make_agent, make_scheduled_claim, make_claims
    ):
        """Principle #12: Follow-Up Due is uncapped, but new work is never
        piled on top of an already-full bucket."""
        agent = make_agent(work_unit)
        for _ in range(60):
            make_scheduled_claim(work_unit, agent, days_offset=-1)
        make_claims(work_unit, 20)

        run_command("--work-unit", str(work_unit.id))

        assert Claim.objects.filter(
            current_owner=agent, lifecycle_state=LS.NEW_UNWORKED
        ).count() == 0
        assert Claim.objects.filter(
            lifecycle_state=LS.UNASSIGNED, current_owner__isnull=True
        ).count() == 20


# ── The management command ───────────────────────────────────────────────────

class TestManagementCommand:

    def test_full_run_performs_both_steps(
        self, work_unit, make_agent, make_scheduled_claim, make_claims, refresh
    ):
        agent = make_agent(work_unit)
        due = make_scheduled_claim(work_unit, agent, days_offset=-1)
        make_claims(work_unit, 3)

        output = run_command("--work-unit", str(work_unit.id))

        assert refresh(due).lifecycle_state == LS.FOLLOW_UP_DUE
        assert Claim.objects.filter(
            lifecycle_state=LS.NEW_UNWORKED
        ).count() == 3
        assert "STEP 1" in output and "STEP 2" in output

    def test_output_reports_both_step_results(
        self, work_unit, make_agent, make_scheduled_claim, make_claims
    ):
        agent = make_agent(work_unit)
        make_scheduled_claim(work_unit, agent, days_offset=-1)
        make_claims(work_unit, 2)

        output = run_command("--work-unit", str(work_unit.id))

        assert "Claims surfaced:  1" in output
        assert "Assigned:         2" in output
        assert "Bucket Cap:   60" in output

    def test_dry_run_writes_nothing_in_either_step(
        self, work_unit, make_agent, make_scheduled_claim, make_claims, refresh
    ):
        agent = make_agent(work_unit)
        due = make_scheduled_claim(work_unit, agent, days_offset=-1)
        make_claims(work_unit, 3)

        output = run_command("--work-unit", str(work_unit.id), "--dry-run")

        assert refresh(due).lifecycle_state == LS.FOLLOW_UP_SCHEDULED
        assert ClaimAssignment.objects.count() == 0
        assert Claim.objects.filter(current_owner__isnull=False).count() == 1
        assert "DRY RUN" in output
        assert "Would surface" in output and "Would assign" in output

    def test_skip_surfacing_runs_allocation_only(
        self, work_unit, make_agent, make_scheduled_claim, make_claims, refresh
    ):
        agent = make_agent(work_unit)
        due = make_scheduled_claim(work_unit, agent, days_offset=-1)
        make_claims(work_unit, 2)

        output = run_command(
            "--work-unit", str(work_unit.id), "--skip-surfacing"
        )

        assert refresh(due).lifecycle_state == LS.FOLLOW_UP_SCHEDULED
        assert Claim.objects.filter(
            lifecycle_state=LS.NEW_UNWORKED
        ).count() == 2
        assert "SKIPPED" in output

    def test_project_flag_scopes_the_allocation(
        self, work_unit, make_agent, make_claim, make_project,
        add_claim_to_project
    ):
        make_agent(work_unit)
        project = make_project(work_unit, name="Escalation Batch")
        member = make_claim(work_unit)
        add_claim_to_project(project, member)
        ordinary = make_claim(work_unit)

        output = run_command(
            "--work-unit", str(work_unit.id), "--project", str(project.id)
        )

        member.refresh_from_db()
        ordinary.refresh_from_db()
        assert member.current_owner_id is not None
        assert ordinary.current_owner_id is None
        assert "Escalation Batch" in output

    def test_unknown_work_unit_is_a_clean_command_error(self):
        import uuid

        with pytest.raises(CommandError, match="not found or is inactive"):
            run_command("--work-unit", str(uuid.uuid4()))

    def test_inactive_work_unit_is_rejected(self, make_work_unit):
        wu = make_work_unit(is_active=False)

        with pytest.raises(CommandError, match="not found or is inactive"):
            run_command("--work-unit", str(wu.id))

    def test_unknown_project_is_a_clean_command_error(
        self, work_unit, make_agent
    ):
        import uuid

        make_agent(work_unit)

        with pytest.raises(CommandError, match="not found, not active"):
            run_command(
                "--work-unit", str(work_unit.id), "--project", str(uuid.uuid4())
            )

    def test_project_from_another_work_unit_is_rejected(
        self, make_work_unit, make_agent, make_project
    ):
        """Cross-tenant guard at the CLI boundary."""
        wu_a, wu_b = make_work_unit(), make_work_unit()
        make_agent(wu_a)
        foreign = make_project(wu_b)

        with pytest.raises(CommandError, match="not found, not active"):
            run_command(
                "--work-unit", str(wu_a.id), "--project", str(foreign.id)
            )

    def test_closed_project_is_rejected(
        self, work_unit, make_agent, make_project
    ):
        make_agent(work_unit)
        closed = make_project(work_unit, status=Project.Status.COMPLETED)

        with pytest.raises(CommandError, match="not found, not active"):
            run_command(
                "--work-unit", str(work_unit.id), "--project", str(closed.id)
            )

    def test_no_eligible_agents_fails_after_surfacing_succeeded(
        self, work_unit, make_agent, make_scheduled_claim, make_claims, refresh
    ):
        """
        Step 1 is not rolled back by a Step 2 failure — they are independent
        operations. The surfaced claims stay surfaced and a re-run with
        --skip-surfacing is safe.
        """
        from core.models import User

        lead = make_agent(work_unit, role=User.Role.TEAM_LEAD)
        due = make_scheduled_claim(work_unit, lead, days_offset=-1)
        make_claims(work_unit, 2)

        with pytest.raises(CommandError, match="no eligible agents"):
            run_command("--work-unit", str(work_unit.id))

        assert refresh(due).lifecycle_state == LS.FOLLOW_UP_DUE

    def test_work_unit_argument_is_required(self):
        with pytest.raises(CommandError):
            run_command()


# ── Repeat-run behaviour ─────────────────────────────────────────────────────

class TestRepeatRuns:

    def test_second_run_seats_nothing_new_and_does_not_displace(
        self, work_unit, make_agent, make_claims
    ):
        """
        Firm assignment: a seated claim is never re-pooled, so a second run
        on an unchanged population is a no-op.
        """
        make_agent(work_unit)
        make_claims(work_unit, 5)

        run_command("--work-unit", str(work_unit.id))
        owners_after_first = dict(
            Claim.objects.values_list("id", "current_owner_id")
        )

        run_command("--work-unit", str(work_unit.id))

        assert dict(
            Claim.objects.values_list("id", "current_owner_id")
        ) == owners_after_first
        assert ClaimAssignment.objects.count() == 5

    def test_new_claims_arriving_later_are_picked_up_by_the_next_run(
        self, work_unit, make_agent, make_claims
    ):
        agent = make_agent(work_unit)
        make_claims(work_unit, 2)
        run_command("--work-unit", str(work_unit.id))

        make_claims(work_unit, 3)          # a fresh ingestion lands
        run_command("--work-unit", str(work_unit.id))

        assert Claim.objects.filter(
            current_owner=agent, lifecycle_state=LS.NEW_UNWORKED
        ).count() == 5


# ── Scale ────────────────────────────────────────────────────────────────────

class TestScale:

    @pytest.mark.slow
    def test_pool_read_is_bounded_by_seats_not_by_inventory(
        self, work_unit, make_agent
    ):
        """
        THE scalability guard. Two agents = 120 seats. With 3,000 unowned
        claims in the WorkUnit, the pool query must return 120 rows, not
        3,000 — cost scales with capacity, never with backlog size.
        """
        make_agent(work_unit)
        make_agent(work_unit)
        Claim.objects.bulk_create([
            Claim(
                work_unit=work_unit, client=work_unit.client,
                claim_number=f"SCALE-{i:06d}", is_active=True,
                lifecycle_state=LS.UNASSIGNED, priority_tier="P3",
                aging_days=i % 400,
            )
            for i in range(3000)
        ])

        summary = run_allocation(work_unit, dry_run=True)

        assert summary["pool_size"] == 120
        assert summary["claims_assigned"] == 120
        assert summary["claims_unassigned"] == 0

    @pytest.mark.slow
    def test_highest_priority_claims_win_the_limited_seats(
        self, work_unit, make_agent
    ):
        """The LIMIT must not cost priority correctness: with 60 seats and
        a mixed backlog, every seat goes to a P1."""
        make_agent(work_unit)
        Claim.objects.bulk_create(
            [
                Claim(work_unit=work_unit, client=work_unit.client,
                      claim_number=f"HI-{i:05d}", is_active=True,
                      lifecycle_state=LS.UNASSIGNED, priority_tier="P1",
                      aging_days=100)
                for i in range(80)
            ] + [
                Claim(work_unit=work_unit, client=work_unit.client,
                      claim_number=f"LO-{i:05d}", is_active=True,
                      lifecycle_state=LS.UNASSIGNED, priority_tier="P5",
                      aging_days=900)
                for i in range(200)
            ]
        )

        run_allocation(work_unit)

        seated = Claim.objects.filter(lifecycle_state=LS.NEW_UNWORKED)
        assert seated.count() == 60
        assert set(seated.values_list("priority_tier", flat=True)) == {"P1"}
