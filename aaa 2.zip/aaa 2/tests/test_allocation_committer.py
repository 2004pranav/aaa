"""
test_allocation_committer.py — Database tests for the allocation write layer.

committer.py is the only code that mutates claim ownership, so these tests
carry the highest blast radius in the suite. They verify three things:

    1. The three writes (owner, lifecycle_state, ClaimAssignment) all land,
       correctly and together.
    2. The pre-write guard refuses to overwrite anything it should not —
       already-owned claims, wrong lifecycle states, other tenants' claims.
    3. The whole thing is atomic: a failure part-way leaves nothing behind.

A note on ClaimAssignment: its save() raises unconditionally (the append-only
guard tests `if self.pk`, and `id` has a uuid4 default so pk is always set).
Production writes it via bulk_create(), which bypasses save(). These tests
only ever read it back — see test_claim_assignment_cannot_be_saved_directly,
which pins that constraint so nobody "fixes" the committer into using
.create() and discovers the problem in production.
"""

from unittest.mock import patch

import pytest
from django.utils import timezone

from core.models import Claim, ClaimAssignment
from tests.conftest import skip_without_row_locking

pytestmark = pytest.mark.django_db

LS = Claim.LifecycleState


def result_for(assignments):
    """Wraps an assignment map in the engine's result-dict shape."""
    return {"assignments": assignments}


# ── The happy path ───────────────────────────────────────────────────────────

class TestSuccessfulCommit:

    def test_sets_current_owner(
        self, work_unit, make_agent, make_claim, refresh
    ):
        from core.services.allocation.committer import commit_assignments

        agent = make_agent(work_unit)
        claim = make_claim(work_unit)

        commit_assignments(result_for({claim.id: agent.id}), work_unit)

        assert refresh(claim).current_owner_id == agent.id

    def test_flips_lifecycle_state_to_new_unworked(
        self, work_unit, make_agent, make_claim, refresh
    ):
        from core.services.allocation.committer import commit_assignments

        agent = make_agent(work_unit)
        claim = make_claim(work_unit)

        commit_assignments(result_for({claim.id: agent.id}), work_unit)

        assert refresh(claim).lifecycle_state == LS.NEW_UNWORKED

    def test_bumps_updated_at(
        self, work_unit, make_agent, make_claim, refresh
    ):
        """
        bulk_update does not fire auto_now, so the committer sets updated_at
        explicitly. Without it a claim could change hands with no audit trace
        of when.
        """
        from core.services.allocation.committer import commit_assignments

        agent = make_agent(work_unit)
        claim = make_claim(work_unit)
        before = timezone.now()

        commit_assignments(result_for({claim.id: agent.id}), work_unit)

        assert refresh(claim).updated_at >= before

    def test_creates_one_claim_assignment_per_seating(
        self, work_unit, make_agent, make_claims
    ):
        from core.services.allocation.committer import commit_assignments

        agent = make_agent(work_unit)
        claims = make_claims(work_unit, 3)

        commit_assignments(
            result_for({c.id: agent.id for c in claims}), work_unit
        )

        assert ClaimAssignment.objects.count() == 3

    def test_claim_assignment_carries_the_full_audit_row(
        self, work_unit, make_agent, make_claim
    ):
        from core.services.allocation.committer import commit_assignments

        agent = make_agent(work_unit)
        manager = make_agent(work_unit)
        claim = make_claim(work_unit)

        commit_assignments(
            result_for({claim.id: agent.id}), work_unit, assigned_by=manager
        )

        row = ClaimAssignment.objects.get()
        assert row.claim_id == claim.id
        assert row.assigned_to_id == agent.id
        assert row.assigned_by_id == manager.id
        assert row.work_unit_id == work_unit.id
        assert row.client_id == work_unit.client_id
        assert row.bucket == ClaimAssignment.Bucket.ACTIVE

    def test_assigned_by_is_null_for_a_system_run(
        self, work_unit, make_agent, make_claim
    ):
        from core.services.allocation.committer import commit_assignments

        agent = make_agent(work_unit)
        claim = make_claim(work_unit)

        commit_assignments(result_for({claim.id: agent.id}), work_unit)

        assert ClaimAssignment.objects.get().assigned_by_id is None

    def test_returns_accurate_counts(
        self, work_unit, make_agent, make_claims
    ):
        from core.services.allocation.committer import commit_assignments

        agent = make_agent(work_unit)
        claims = make_claims(work_unit, 4)

        summary = commit_assignments(
            result_for({c.id: agent.id for c in claims}), work_unit
        )

        assert summary == {
            "claims_written": 4,
            "claims_skipped": 0,
            "assignments_created": 4,
        }

    def test_distributes_to_multiple_agents_correctly(
        self, work_unit, make_agents, make_claims
    ):
        from core.services.allocation.committer import commit_assignments

        a, b = make_agents(work_unit, count=2)
        c1, c2, c3 = make_claims(work_unit, 3)

        commit_assignments(
            result_for({c1.id: a.id, c2.id: b.id, c3.id: a.id}), work_unit
        )

        assert set(
            ClaimAssignment.objects.filter(assigned_to=a)
            .values_list("claim_id", flat=True)
        ) == {c1.id, c3.id}
        assert list(
            ClaimAssignment.objects.filter(assigned_to=b)
            .values_list("claim_id", flat=True)
        ) == [c2.id]


# ── The pre-write race guard ─────────────────────────────────────────────────

class TestRaceGuard:

    def test_skips_a_claim_that_gained_an_owner_since_the_engine_ran(
        self, work_unit, make_agents, make_claim, refresh
    ):
        from core.services.allocation.committer import commit_assignments

        winner, loser = make_agents(work_unit, count=2)
        claim = make_claim(work_unit, current_owner=winner,
                           lifecycle_state=LS.NEW_UNWORKED)

        summary = commit_assignments(
            result_for({claim.id: loser.id}), work_unit
        )

        assert summary["claims_written"] == 0
        assert summary["claims_skipped"] == 1
        assert refresh(claim).current_owner_id == winner.id

    def test_never_creates_an_assignment_row_for_a_skipped_claim(
        self, work_unit, make_agents, make_claim
    ):
        from core.services.allocation.committer import commit_assignments

        winner, loser = make_agents(work_unit, count=2)
        claim = make_claim(work_unit, current_owner=winner,
                           lifecycle_state=LS.NEW_UNWORKED)

        commit_assignments(result_for({claim.id: loser.id}), work_unit)

        assert ClaimAssignment.objects.count() == 0

    @pytest.mark.parametrize(
        "state", [LS.NEW_UNWORKED, LS.FOLLOW_UP_DUE, LS.FOLLOW_UP_SCHEDULED]
    )
    def test_skips_claims_not_in_unassigned_state(
        self, work_unit, make_agent, make_claim, state
    ):
        from core.services.allocation.committer import commit_assignments

        agent = make_agent(work_unit)
        claim = make_claim(work_unit, lifecycle_state=state,
                           current_owner=None)

        summary = commit_assignments(
            result_for({claim.id: agent.id}), work_unit
        )

        assert summary["claims_written"] == 0
        assert summary["claims_skipped"] == 1

    def test_writes_the_survivors_and_skips_the_rest(
        self, work_unit, make_agents, make_claim, refresh
    ):
        from core.services.allocation.committer import commit_assignments

        agent, other = make_agents(work_unit, count=2)
        fresh = make_claim(work_unit)
        taken = make_claim(work_unit, current_owner=other,
                           lifecycle_state=LS.NEW_UNWORKED)

        summary = commit_assignments(
            result_for({fresh.id: agent.id, taken.id: agent.id}), work_unit
        )

        assert summary["claims_written"] == 1
        assert summary["claims_skipped"] == 1
        assert refresh(fresh).current_owner_id == agent.id
        assert refresh(taken).current_owner_id == other.id

    def test_all_claims_skipped_returns_early_without_writing(
        self, work_unit, make_agents, make_claim
    ):
        from core.services.allocation.committer import commit_assignments

        agent, other = make_agents(work_unit, count=2)
        taken = make_claim(work_unit, current_owner=other,
                           lifecycle_state=LS.NEW_UNWORKED)

        summary = commit_assignments(
            result_for({taken.id: agent.id}), work_unit
        )

        assert summary == {
            "claims_written": 0,
            "claims_skipped": 1,
            "assignments_created": 0,
        }
        assert ClaimAssignment.objects.count() == 0

    def test_uses_row_locking_where_the_backend_supports_it(
        self, work_unit, make_agent, make_claim
    ):
        """
        On PostgreSQL the guard takes SELECT ... FOR UPDATE SKIP LOCKED so
        two concurrent runs cannot seat the same claim. SQLite ignores the
        clause entirely, so this assertion only means something on PG.
        """
        from core.services.allocation.committer import commit_assignments

        skip_without_row_locking()

        agent = make_agent(work_unit)
        claim = make_claim(work_unit)
        summary = commit_assignments(
            result_for({claim.id: agent.id}), work_unit
        )

        assert summary["claims_written"] == 1


# ── Tenant isolation ─────────────────────────────────────────────────────────

class TestTenantIsolation:

    def test_refuses_to_write_a_claim_from_another_work_unit(
        self, make_work_unit, make_agent, make_claim, refresh
    ):
        """
        The guard is scoped by work_unit, so a foreign claim id can never be
        seated — and can never receive a ClaimAssignment stamped with the
        wrong tenant's client.
        """
        from core.services.allocation.committer import commit_assignments

        wu_a, wu_b = make_work_unit(), make_work_unit()
        agent = make_agent(wu_a)
        foreign = make_claim(wu_b)

        summary = commit_assignments(
            result_for({foreign.id: agent.id}), wu_a
        )

        assert summary["claims_written"] == 0
        assert summary["claims_skipped"] == 1
        assert refresh(foreign).current_owner_id is None
        assert ClaimAssignment.objects.count() == 0

    def test_mixed_tenant_batch_writes_only_the_owning_tenant(
        self, make_work_unit, make_agent, make_claim, refresh
    ):
        from core.services.allocation.committer import commit_assignments

        wu_a, wu_b = make_work_unit(), make_work_unit()
        agent = make_agent(wu_a)
        mine, foreign = make_claim(wu_a), make_claim(wu_b)

        summary = commit_assignments(
            result_for({mine.id: agent.id, foreign.id: agent.id}), wu_a
        )

        assert summary["claims_written"] == 1
        assert refresh(mine).current_owner_id == agent.id
        assert refresh(foreign).current_owner_id is None


# ── Empty input ──────────────────────────────────────────────────────────────

class TestEmptyInput:

    def test_empty_assignments_returns_zeros_and_writes_nothing(
        self, work_unit
    ):
        from core.services.allocation.committer import commit_assignments

        summary = commit_assignments(result_for({}), work_unit)

        assert summary == {
            "claims_written": 0,
            "claims_skipped": 0,
            "assignments_created": 0,
        }
        assert ClaimAssignment.objects.count() == 0

    def test_missing_assignments_key_is_tolerated(self, work_unit):
        from core.services.allocation.committer import commit_assignments

        summary = commit_assignments({}, work_unit)

        assert summary["claims_written"] == 0


# ── Atomicity ────────────────────────────────────────────────────────────────

class TestAtomicity:

    def test_assignment_write_failure_rolls_back_the_claim_updates(
        self, work_unit, make_agent, make_claims, refresh
    ):
        """
        If the audit rows cannot be written, the ownership changes must not
        survive either — otherwise claims would be seated with no audit
        trail, which is unacceptable in a HIPAA-regulated system.
        """
        from core.services.allocation.committer import commit_assignments

        agent = make_agent(work_unit)
        claims = make_claims(work_unit, 3)
        assignments = {c.id: agent.id for c in claims}

        with patch.object(
            ClaimAssignment.objects, "bulk_create",
            side_effect=RuntimeError("audit write exploded"),
        ):
            with pytest.raises(RuntimeError):
                commit_assignments(result_for(assignments), work_unit)

        for claim in claims:
            reloaded = refresh(claim)
            assert reloaded.current_owner_id is None
            assert reloaded.lifecycle_state == LS.UNASSIGNED
        assert ClaimAssignment.objects.count() == 0


# ── Scale ────────────────────────────────────────────────────────────────────

class TestScale:

    @pytest.mark.slow
    def test_commits_more_than_one_batch(
        self, work_unit, make_agent, make_claim
    ):
        """
        batch_size=1000, so 1,200 seatings exercise the multi-batch path in
        both bulk_update and bulk_create.
        """
        from core.services.allocation.committer import commit_assignments

        agent = make_agent(work_unit)
        claims = Claim.objects.bulk_create([
            Claim(
                work_unit=work_unit, client=work_unit.client,
                claim_number=f"BULK-{i:06d}", is_active=True,
                lifecycle_state=LS.UNASSIGNED, priority_tier="P3",
                aging_days=10,
            )
            for i in range(1200)
        ])

        summary = commit_assignments(
            result_for({c.id: agent.id for c in claims}), work_unit
        )

        assert summary["claims_written"] == 1200
        assert summary["assignments_created"] == 1200
        assert Claim.objects.filter(
            current_owner=agent, lifecycle_state=LS.NEW_UNWORKED
        ).count() == 1200


# ── Model constraint the committer depends on ────────────────────────────────

class TestClaimAssignmentAppendOnly:

    def test_claim_assignment_cannot_be_saved_directly(
        self, work_unit, make_agent, make_claim
    ):
        """
        Pins a real quirk: ClaimAssignment.save() raises even for a brand-new
        instance, because its guard checks `if self.pk` and `id` has a uuid4
        default. The committer must therefore keep using bulk_create(). If
        someone later fixes the model guard, this test fails and tells them
        the committer is now free to use .create().
        """
        agent = make_agent(work_unit)
        claim = make_claim(work_unit)

        with pytest.raises(ValueError, match="append-only"):
            ClaimAssignment(
                claim=claim, assigned_to=agent, work_unit=work_unit,
                client=work_unit.client,
                bucket=ClaimAssignment.Bucket.ACTIVE,
            ).save()

    def test_claim_assignment_cannot_be_deleted(
        self, work_unit, make_agent, make_claim
    ):
        from core.services.allocation.committer import commit_assignments

        agent = make_agent(work_unit)
        claim = make_claim(work_unit)
        commit_assignments(result_for({claim.id: agent.id}), work_unit)

        with pytest.raises(ValueError):
            ClaimAssignment.objects.get().delete()
