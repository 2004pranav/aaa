"""
test_allocation_engine.py — Pure unit tests for the distribution algorithm.

engine.allocate_claims() is the one piece of the allocation package with
ZERO Django imports and ZERO database access, so these tests need no
database at all. They run in milliseconds and are the fastest feedback
loop in the suite — run them on every save.

What is locked here:
    - Most-loaded-first selection (the busiest not-yet-full agent wins)
    - The bucket cap is never exceeded, by anyone, ever
    - Priority order (P1 → P5) survives, and aging breaks ties within a tier
    - Null aging_days never crashes and never jumps the queue
    - The input lists are never mutated
    - Output is deterministic and the result dict is fully populated

These tests deliberately use plain strings for user_id/claim_id rather than
UUIDs. The engine treats IDs as opaque hashables, and readable ids make a
failure message ("expected A, got B") immediately intelligible.
"""

import pytest

from core.services.allocation.engine import DEFAULT_BUCKET_CAP, allocate_claims
from core.services.allocation.exceptions import (
    AllocationError,
    NoEligibleAgentsError,
)


# ── Builders ─────────────────────────────────────────────────────────────────

def agent(user_id, current_load=0):
    return {"user_id": user_id, "current_load": current_load}


def claim(claim_id, priority_tier="P3", aging_days=10):
    return {
        "claim_id": claim_id,
        "priority_tier": priority_tier,
        "aging_days": aging_days,
    }


def claims(n, priority_tier="P3", aging_days=10, prefix="c"):
    return [
        claim(f"{prefix}{i}", priority_tier, aging_days) for i in range(n)
    ]


def seated_for(result, user_id):
    """How many claims this agent received in this run."""
    return sum(1 for uid in result["assignments"].values() if uid == user_id)


# ── Pre-conditions and empty inputs ──────────────────────────────────────────

class TestPreconditions:

    def test_no_agents_raises_no_eligible_agents_error(self):
        with pytest.raises(NoEligibleAgentsError):
            allocate_claims([], claims(5))

    def test_no_eligible_agents_error_is_an_allocation_error(self):
        """Callers can catch the whole family with one except block."""
        with pytest.raises(AllocationError):
            allocate_claims([], claims(1))

    def test_empty_claim_pool_returns_empty_result(self):
        result = allocate_claims([agent("A")], [])

        assert result["assignments"] == {}
        assert result["claims_assigned"] == 0
        assert result["claims_unassigned"] == 0
        assert result["unassigned_claim_ids"] == []

    def test_result_always_has_the_full_contract_keys(self):
        """__init__.py reads every one of these; none may ever be absent."""
        result = allocate_claims([agent("A")], claims(1))

        assert set(result) == {
            "assignments",
            "claims_assigned",
            "claims_unassigned",
            "unassigned_claim_ids",
            "agents_at_capacity",
        }


# ── The cap ──────────────────────────────────────────────────────────────────

class TestBucketCap:

    def test_agent_is_never_seated_past_the_cap(self):
        result = allocate_claims([agent("A", current_load=58)], claims(10),
                                 bucket_cap=60)

        assert seated_for(result, "A") == 2
        assert result["claims_unassigned"] == 8

    def test_agent_already_at_cap_receives_nothing(self):
        result = allocate_claims([agent("A", current_load=60)], claims(5),
                                 bucket_cap=60)

        assert result["claims_assigned"] == 0
        assert result["claims_unassigned"] == 5

    def test_agent_over_cap_receives_nothing_and_does_not_crash(self):
        """
        An agent can exceed the cap through their own follow-up commitments
        (Principle #12 — Follow-Up Due is uncapped). Negative free capacity
        must simply mean 'no new work', never a crash or a negative seat.
        """
        result = allocate_claims([agent("A", current_load=75)], claims(5),
                                 bucket_cap=60)

        assert result["claims_assigned"] == 0
        assert "A" in result["agents_at_capacity"]

    def test_total_seated_never_exceeds_total_free_capacity(self):
        agents = [agent("A", 55), agent("B", 40), agent("C", 0)]
        total_free = (60 - 55) + (60 - 40) + (60 - 0)  # 85

        result = allocate_claims(agents, claims(500), bucket_cap=60)

        assert result["claims_assigned"] == total_free
        assert result["claims_unassigned"] == 500 - total_free

    def test_custom_bucket_cap_is_honoured(self):
        result = allocate_claims([agent("A", current_load=0)], claims(50),
                                 bucket_cap=10)

        assert result["claims_assigned"] == 10

    def test_default_cap_is_sixty(self):
        assert DEFAULT_BUCKET_CAP == 60

        result = allocate_claims([agent("A", current_load=0)], claims(100))

        assert result["claims_assigned"] == 60


# ── Most-loaded-first distribution (the locked rule) ─────────────────────────

class TestMostLoadedFirst:

    def test_busiest_agent_fills_to_cap_before_others_get_anything(self):
        """
        The canonical light-day scenario. A is busier (less free capacity),
        so all 10 claims go to A — work concentrates rather than spreading.
        """
        result = allocate_claims(
            [agent("A", current_load=50), agent("B", current_load=20)],
            claims(10),
            bucket_cap=60,
        )

        assert seated_for(result, "A") == 10
        assert seated_for(result, "B") == 0

    def test_overflow_spills_to_the_next_busiest(self):
        result = allocate_claims(
            [agent("A", current_load=57), agent("B", current_load=55)],
            claims(6),
            bucket_cap=60,
        )

        assert seated_for(result, "A") == 3   # free 3, fills first
        assert seated_for(result, "B") == 3   # free 5, takes remainder

    def test_plentiful_work_fills_everyone_to_cap(self):
        result = allocate_claims(
            [agent("A", 50), agent("B", 40), agent("C", 30)],
            claims(200),
            bucket_cap=60,
        )

        assert seated_for(result, "A") == 10
        assert seated_for(result, "B") == 20
        assert seated_for(result, "C") == 30
        assert set(result["agents_at_capacity"]) == {"A", "B", "C"}

    def test_idle_agent_is_used_only_after_busier_agents_are_full(self):
        result = allocate_claims(
            [agent("busy", 59), agent("idle", 0)],
            claims(3),
            bucket_cap=60,
        )

        assert seated_for(result, "busy") == 1   # tops off first
        assert seated_for(result, "idle") == 2   # then the remainder


# ── Ordering: priority, then aging ───────────────────────────────────────────

class TestOrdering:

    def test_highest_priority_claims_win_when_capacity_is_scarce(self):
        pool = [
            claim("p5", "P5"),
            claim("p1", "P1"),
            claim("p3", "P3"),
        ]
        result = allocate_claims([agent("A", 59)], pool, bucket_cap=60)

        assert set(result["assignments"]) == {"p1"}
        assert set(result["unassigned_claim_ids"]) == {"p5", "p3"}

    def test_engine_re_sorts_a_badly_ordered_pool(self):
        """
        The loader pre-sorts, but the engine must not depend on it — a
        caller passing an unsorted pool must still get priority order.
        """
        pool = [claim("p4", "P4"), claim("p2", "P2"), claim("p1", "P1")]
        result = allocate_claims([agent("A", 58)], pool, bucket_cap=60)

        assert set(result["assignments"]) == {"p1", "p2"}

    def test_oldest_claim_wins_within_the_same_tier(self):
        pool = [
            claim("new", "P2", aging_days=5),
            claim("old", "P2", aging_days=400),
            claim("mid", "P2", aging_days=100),
        ]
        result = allocate_claims([agent("A", 59)], pool, bucket_cap=60)

        assert set(result["assignments"]) == {"old"}

    def test_priority_outranks_aging(self):
        """A brand-new P1 beats a very old P5 — tier is the primary key."""
        pool = [
            claim("ancient_p5", "P5", aging_days=999),
            claim("fresh_p1", "P1", aging_days=1),
        ]
        result = allocate_claims([agent("A", 59)], pool, bucket_cap=60)

        assert set(result["assignments"]) == {"fresh_p1"}

    def test_unknown_tier_sorts_last_without_crashing(self):
        """
        A tier the engine does not recognise (bad data, or a future tier)
        must degrade to lowest priority, never raise.
        """
        pool = [claim("weird", "P9"), claim("normal", "P3")]
        result = allocate_claims([agent("A", 59)], pool, bucket_cap=60)

        assert set(result["assignments"]) == {"normal"}


# ── Null aging_days (the bug that used to crash every run) ───────────────────

class TestNullAgingDays:

    def test_null_aging_days_does_not_crash(self):
        result = allocate_claims(
            [agent("A")], [claim("c1", "P1", aging_days=None)]
        )

        assert result["claims_assigned"] == 1

    def test_missing_aging_days_key_does_not_crash(self):
        result = allocate_claims(
            [agent("A")], [{"claim_id": "c1", "priority_tier": "P1"}]
        )

        assert result["claims_assigned"] == 1

    def test_null_aging_claim_does_not_outrank_a_genuinely_old_claim(self):
        """
        Null aging is treated as 0 (newest), so a claim with missing aging
        data must never jump ahead of a real 300-day-old claim.
        """
        pool = [
            claim("null_aging", "P2", aging_days=None),
            claim("truly_old", "P2", aging_days=300),
        ]
        result = allocate_claims([agent("A", 59)], pool, bucket_cap=60)

        assert set(result["assignments"]) == {"truly_old"}

    def test_all_null_aging_pool_still_allocates(self):
        pool = [claim(f"c{i}", "P3", aging_days=None) for i in range(5)]
        result = allocate_claims([agent("A")], pool)

        assert result["claims_assigned"] == 5


# ── Purity: no mutation of caller data ───────────────────────────────────────

class TestInputImmutability:

    def test_agents_list_is_not_mutated(self):
        agents = [agent("A", current_load=10), agent("B", current_load=20)]
        snapshot = [dict(a) for a in agents]

        allocate_claims(agents, claims(5))

        assert agents == snapshot

    def test_claims_list_is_not_reordered_in_place(self):
        pool = [claim("p5", "P5"), claim("p1", "P1")]
        snapshot = [dict(c) for c in pool]

        allocate_claims([agent("A")], pool)

        assert pool == snapshot


# ── Reporting fields ─────────────────────────────────────────────────────────

class TestResultReporting:

    def test_counts_are_internally_consistent(self):
        result = allocate_claims([agent("A", 55)], claims(20), bucket_cap=60)

        assert result["claims_assigned"] == len(result["assignments"])
        assert result["claims_unassigned"] == len(result["unassigned_claim_ids"])
        assert result["claims_assigned"] + result["claims_unassigned"] == 20

    def test_unassigned_ids_are_exactly_the_claims_not_seated(self):
        pool = claims(10)
        result = allocate_claims([agent("A", 57)], pool, bucket_cap=60)

        all_ids = {c["claim_id"] for c in pool}
        assert set(result["assignments"]) | set(result["unassigned_claim_ids"]) == all_ids
        assert not set(result["assignments"]) & set(result["unassigned_claim_ids"])

    def test_agents_at_capacity_lists_only_full_agents(self):
        result = allocate_claims(
            [agent("full", 60), agent("roomy", 10)], claims(1), bucket_cap=60
        )

        assert "full" in result["agents_at_capacity"]
        assert "roomy" not in result["agents_at_capacity"]

    def test_every_assignment_targets_a_real_agent(self):
        agents = [agent("A", 30), agent("B", 40)]
        result = allocate_claims(agents, claims(50), bucket_cap=60)

        assert set(result["assignments"].values()) <= {"A", "B"}


# ── Determinism ──────────────────────────────────────────────────────────────

class TestDeterminism:

    def test_identical_input_produces_identical_output(self):
        def run():
            return allocate_claims(
                [agent("A", 50), agent("B", 50), agent("C", 20)],
                claims(15),
                bucket_cap=60,
            )

        assert run()["assignments"] == run()["assignments"]

    def test_equal_capacity_ties_resolve_consistently(self):
        """
        Two agents with identical free capacity must split predictably —
        a preview and its subsequent commit have to agree.
        """
        first = allocate_claims(
            [agent("A", 30), agent("B", 30)], claims(4), bucket_cap=60
        )
        second = allocate_claims(
            [agent("A", 30), agent("B", 30)], claims(4), bucket_cap=60
        )

        assert first["assignments"] == second["assignments"]


# ── Scale sanity ─────────────────────────────────────────────────────────────

class TestScale:

    @pytest.mark.slow
    def test_large_pool_and_team_completes_and_respects_cap(self):
        """
        20 agents × 60 cap = 1,200 seats against a 5,000-claim pool.
        Guards against an accidental O(n^2) rewrite of the selection loop.
        """
        agents = [agent(f"u{i}", current_load=0) for i in range(20)]
        pool = claims(5000, prefix="big")

        result = allocate_claims(agents, pool, bucket_cap=60)

        assert result["claims_assigned"] == 1200
        assert result["claims_unassigned"] == 3800
        assert len(result["agents_at_capacity"]) == 20
