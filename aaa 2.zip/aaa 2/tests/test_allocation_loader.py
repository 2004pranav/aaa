"""
test_allocation_loader.py — Database tests for the allocation read layer.

loader.py is where the allocation engine's correctness actually lives: the
engine is a simple algorithm over whatever data it is handed, so a wrong
filter here silently produces a confidently-wrong allocation. These tests
pin every filter, the ordering, the LIMIT, and the project scoping.

Three defects previously shipped in this file and each now has a regression
test that fails loudly if reintroduced:

    1. `.values(priority_tier=F("priority_tier"))` self-aliased a model field
       and raised ValueError on every single call.
    2. `-aging_days` without NULLS LAST let claims with missing aging data
       crowd genuinely-aged claims out of the capacity-limited pool.
    3. The pool did not filter `lifecycle_state=UNASSIGNED`, so it disagreed
       with the committer's write guard and stranded claims permanently.
"""

import pytest
from django.db import connection
from django.test.utils import CaptureQueriesContext

from core.models import Claim, Project, User
from core.services.allocation.loader import (
    build_engine_input,
    load_agent_loads,
    load_eligible_agents,
    load_unowned_pool,
)

pytestmark = pytest.mark.django_db

LS = Claim.LifecycleState


# ── load_eligible_agents ─────────────────────────────────────────────────────

class TestLoadEligibleAgents:

    def test_returns_mapped_active_ar_agents(self, work_unit, make_agents):
        agents = make_agents(work_unit, count=3)

        result = load_eligible_agents(work_unit)

        assert {a["user_id"] for a in result} == {a.id for a in agents}

    def test_returns_dicts_keyed_user_id(self, work_unit, make_agent):
        """build_engine_input indexes on this exact key."""
        make_agent(work_unit)

        result = load_eligible_agents(work_unit)

        assert list(result[0]) == ["user_id"]

    def test_excludes_non_ar_roles(self, work_unit, make_agent):
        """Team Leads and Managers are never auto-allocated work."""
        ar = make_agent(work_unit, role=User.Role.AR)
        make_agent(work_unit, role=User.Role.MANAGER)
        make_agent(work_unit, role=User.Role.TEAM_LEAD)
        make_agent(work_unit, role=User.Role.ADMIN)
        make_agent(work_unit, role=User.Role.LEADERSHIP)

        result = load_eligible_agents(work_unit)

        assert [a["user_id"] for a in result] == [ar.id]

    def test_excludes_deactivated_users(self, work_unit, make_agent):
        active = make_agent(work_unit)
        make_agent(work_unit, user_active=False)

        result = load_eligible_agents(work_unit)

        assert [a["user_id"] for a in result] == [active.id]

    def test_excludes_inactive_mappings(self, work_unit, make_agent):
        """Removing someone from a WorkUnit deactivates the mapping."""
        active = make_agent(work_unit)
        make_agent(work_unit, mapping_active=False)

        result = load_eligible_agents(work_unit)

        assert [a["user_id"] for a in result] == [active.id]

    def test_is_scoped_to_the_requested_work_unit(
        self, make_work_unit, make_agent
    ):
        wu_a, wu_b = make_work_unit(), make_work_unit()
        agent_a = make_agent(wu_a)
        make_agent(wu_b)

        result = load_eligible_agents(wu_a)

        assert [a["user_id"] for a in result] == [agent_a.id]

    def test_returns_empty_list_when_nobody_is_eligible(self, work_unit):
        assert load_eligible_agents(work_unit) == []


# ── load_agent_loads ─────────────────────────────────────────────────────────

class TestLoadAgentLoads:

    def test_counts_new_unworked_and_follow_up_due(
        self, work_unit, make_agent, make_claim
    ):
        agent = make_agent(work_unit)
        for _ in range(3):
            make_claim(work_unit, lifecycle_state=LS.NEW_UNWORKED,
                       current_owner=agent)
        for _ in range(2):
            make_claim(work_unit, lifecycle_state=LS.FOLLOW_UP_DUE,
                       current_owner=agent)

        loads = load_agent_loads(work_unit, [agent.id])

        assert loads[agent.id] == 5

    def test_excludes_deferred_follow_up_scheduled(
        self, work_unit, make_agent, make_claim
    ):
        """Deferred claims are not in the Active Bucket and must not
        consume capacity."""
        agent = make_agent(work_unit)
        make_claim(work_unit, lifecycle_state=LS.NEW_UNWORKED,
                   current_owner=agent)
        make_claim(work_unit, lifecycle_state=LS.FOLLOW_UP_SCHEDULED,
                   current_owner=agent)

        loads = load_agent_loads(work_unit, [agent.id])

        assert loads[agent.id] == 1

    def test_excludes_resolved_claims(self, work_unit, make_agent, make_claim):
        """
        Resolution is signalled by is_active=False, not by lifecycle_state,
        so a resolved claim keeps a stale NEW_UNWORKED state. It must not
        count against the agent's capacity.
        """
        agent = make_agent(work_unit)
        make_claim(work_unit, lifecycle_state=LS.NEW_UNWORKED,
                   current_owner=agent, is_active=True)
        make_claim(work_unit, lifecycle_state=LS.NEW_UNWORKED,
                   current_owner=agent, is_active=False)

        loads = load_agent_loads(work_unit, [agent.id])

        assert loads[agent.id] == 1

    def test_agents_with_no_claims_are_initialised_to_zero(
        self, work_unit, make_agents
    ):
        """A missing key would blow up the free-capacity arithmetic."""
        a, b = make_agents(work_unit, count=2)

        loads = load_agent_loads(work_unit, [a.id, b.id])

        assert loads == {a.id: 0, b.id: 0}

    def test_is_scoped_to_the_requested_work_unit(
        self, make_work_unit, make_agent, make_claim
    ):
        wu_a, wu_b = make_work_unit(), make_work_unit()
        agent = make_agent(wu_a)
        make_agent(wu_b, employee_id="SHARED1", email="shared@example.com")
        make_claim(wu_a, lifecycle_state=LS.NEW_UNWORKED, current_owner=agent)
        make_claim(wu_b, lifecycle_state=LS.NEW_UNWORKED, current_owner=agent)

        loads = load_agent_loads(wu_a, [agent.id])

        assert loads[agent.id] == 1

    def test_other_agents_claims_are_not_counted(
        self, work_unit, make_agents, make_claim
    ):
        a, b = make_agents(work_unit, count=2)
        make_claim(work_unit, lifecycle_state=LS.NEW_UNWORKED, current_owner=b)

        loads = load_agent_loads(work_unit, [a.id, b.id])

        assert loads[a.id] == 0
        assert loads[b.id] == 1


# ── load_unowned_pool: membership filters ────────────────────────────────────

class TestUnownedPoolFilters:

    def test_returns_unowned_active_unassigned_claims(
        self, work_unit, make_claim
    ):
        wanted = make_claim(work_unit)

        pool = load_unowned_pool(work_unit)

        assert [c["claim_id"] for c in pool] == [wanted.id]

    def test_pool_rows_have_exactly_the_engine_contract_keys(
        self, work_unit, make_claim
    ):
        make_claim(work_unit)

        pool = load_unowned_pool(work_unit)

        assert set(pool[0]) == {"claim_id", "priority_tier", "aging_days"}

    def test_excludes_owned_claims(self, work_unit, make_agent, make_claim):
        """No displacement — a seated claim is never re-pooled."""
        agent = make_agent(work_unit)
        make_claim(work_unit, current_owner=agent)

        assert load_unowned_pool(work_unit) == []

    def test_excludes_resolved_claims(self, work_unit, make_claim):
        make_claim(work_unit, is_active=False)

        assert load_unowned_pool(work_unit) == []

    def test_excludes_claims_with_uncomputed_is_active(
        self, work_unit, make_claim
    ):
        """is_active=None means 'never computed' and must not be allocated."""
        make_claim(work_unit, is_active=None)

        assert load_unowned_pool(work_unit) == []

    @pytest.mark.parametrize(
        "state",
        [LS.NEW_UNWORKED, LS.FOLLOW_UP_DUE, LS.FOLLOW_UP_SCHEDULED],
    )
    def test_excludes_non_unassigned_lifecycle_states(
        self, work_unit, make_claim, state
    ):
        """
        REGRESSION: the pool must agree with the committer's write guard,
        which only writes claims in UNASSIGNED. An owner-less claim in any
        other state would otherwise be picked, counted as assigned, then
        silently dropped at commit time — stranded forever.
        """
        make_claim(work_unit, lifecycle_state=state, current_owner=None)

        assert load_unowned_pool(work_unit) == []

    def test_is_scoped_to_the_requested_work_unit(
        self, make_work_unit, make_claim
    ):
        wu_a, wu_b = make_work_unit(), make_work_unit()
        mine = make_claim(wu_a)
        make_claim(wu_b)

        pool = load_unowned_pool(wu_a)

        assert [c["claim_id"] for c in pool] == [mine.id]


# ── load_unowned_pool: ordering ──────────────────────────────────────────────

class TestUnownedPoolOrdering:

    def test_orders_by_priority_tier_ascending(self, work_unit, make_claim):
        make_claim(work_unit, priority_tier="P5", claim_number="P5")
        make_claim(work_unit, priority_tier="P1", claim_number="P1")
        make_claim(work_unit, priority_tier="P3", claim_number="P3")

        pool = load_unowned_pool(work_unit)

        assert [c["priority_tier"] for c in pool] == ["P1", "P3", "P5"]

    def test_orders_by_aging_descending_within_a_tier(
        self, work_unit, make_claim
    ):
        make_claim(work_unit, priority_tier="P2", aging_days=10)
        make_claim(work_unit, priority_tier="P2", aging_days=400)
        make_claim(work_unit, priority_tier="P2", aging_days=100)

        pool = load_unowned_pool(work_unit)

        assert [c["aging_days"] for c in pool] == [400, 100, 10]

    def test_null_aging_sorts_last_not_first(self, work_unit, make_claim):
        """
        REGRESSION: PostgreSQL orders NULLs FIRST under DESC. Without an
        explicit NULLS LAST, claims with missing aging data would occupy
        the front of every tier and — once the pool is LIMITed to available
        capacity — crowd genuinely-aged claims out of allocation entirely.
        """
        make_claim(work_unit, priority_tier="P2", aging_days=None)
        make_claim(work_unit, priority_tier="P2", aging_days=300)
        make_claim(work_unit, priority_tier="P2", aging_days=50)

        pool = load_unowned_pool(work_unit)

        assert [c["aging_days"] for c in pool] == [300, 50, None]

    def test_null_aging_is_not_admitted_ahead_of_aged_claims_under_limit(
        self, work_unit, make_claim
    ):
        """The consequence that actually matters: with only one seat, the
        300-day claim must be the one that gets it."""
        make_claim(work_unit, priority_tier="P2", aging_days=None)
        old = make_claim(work_unit, priority_tier="P2", aging_days=300)

        pool = load_unowned_pool(work_unit, limit=1)

        assert [c["claim_id"] for c in pool] == [old.id]

    def test_priority_outranks_aging(self, work_unit, make_claim):
        make_claim(work_unit, priority_tier="P5", aging_days=999)
        p1 = make_claim(work_unit, priority_tier="P1", aging_days=1)

        pool = load_unowned_pool(work_unit)

        assert pool[0]["claim_id"] == p1.id


# ── load_unowned_pool: the LIMIT ─────────────────────────────────────────────

class TestUnownedPoolLimit:

    def test_limit_caps_the_number_of_rows_returned(
        self, work_unit, make_claims
    ):
        make_claims(work_unit, 25)

        assert len(load_unowned_pool(work_unit, limit=10)) == 10

    def test_limit_keeps_the_highest_priority_claims(
        self, work_unit, make_claim
    ):
        make_claim(work_unit, priority_tier="P1", claim_number="A")
        make_claim(work_unit, priority_tier="P2", claim_number="B")
        make_claim(work_unit, priority_tier="P5", claim_number="C")

        pool = load_unowned_pool(work_unit, limit=2)

        assert [c["priority_tier"] for c in pool] == ["P1", "P2"]

    def test_limit_larger_than_pool_returns_everything(
        self, work_unit, make_claims
    ):
        make_claims(work_unit, 3)

        assert len(load_unowned_pool(work_unit, limit=500)) == 3

    def test_limit_none_returns_everything(self, work_unit, make_claims):
        make_claims(work_unit, 5)

        assert len(load_unowned_pool(work_unit, limit=None)) == 5


# ── load_unowned_pool: SQL-level contract ────────────────────────────────────

class TestUnownedPoolSQLContract:
    """
    Asserts on the emitted SQL rather than on observed row order.

    Necessary because the two behaviours below are backend-dependent, and
    SQLite (the local dev database) masks a regression that PostgreSQL (the
    production target) would suffer:

      - SQLite already sorts NULLs last under DESC, so dropping the explicit
        nulls_last=True changes nothing locally while silently starving aged
        claims on PostgreSQL.
      - A Python-side slice would satisfy a row-count assertion while still
        pulling the entire unowned inventory over the wire.

    Checking the generated SQL pins both fixes on every backend.
    """

    def _captured_sql(self, work_unit, **kwargs):
        with CaptureQueriesContext(connection) as ctx:
            load_unowned_pool(work_unit, **kwargs)
        return " ".join(q["sql"] for q in ctx.captured_queries).upper()

    def test_ordering_is_emitted_with_nulls_last(self, work_unit, make_claim):
        """REGRESSION: guards the PostgreSQL NULLS-FIRST starvation bug."""
        make_claim(work_unit)

        assert "NULLS LAST" in self._captured_sql(work_unit, limit=10)

    def test_limit_is_pushed_into_sql_not_applied_in_python(
        self, work_unit, make_claims
    ):
        """
        THE scalability guarantee: the database must return only as many rows
        as there are seats, never the whole backlog for Python to trim.
        """
        make_claims(work_unit, 5)

        assert "LIMIT 2" in self._captured_sql(work_unit, limit=2)

    def test_pool_read_is_a_single_query(self, work_unit, make_claims):
        make_claims(work_unit, 5)

        with CaptureQueriesContext(connection) as ctx:
            load_unowned_pool(work_unit, limit=10)

        assert len(ctx.captured_queries) == 1

    def test_agent_loads_is_a_single_aggregation_query(
        self, work_unit, make_agents, make_claim
    ):
        """No N+1: one GROUP BY regardless of team size."""
        agents = make_agents(work_unit, count=5)
        for agent in agents:
            make_claim(work_unit, lifecycle_state=LS.NEW_UNWORKED,
                       current_owner=agent)

        with CaptureQueriesContext(connection) as ctx:
            load_agent_loads(work_unit, [a.id for a in agents])

        assert len(ctx.captured_queries) == 1


# ── load_unowned_pool: project scoping ───────────────────────────────────────

class TestUnownedPoolProjectScoping:

    def test_daily_run_excludes_claims_in_an_active_project(
        self, work_unit, make_claim, make_project, add_claim_to_project
    ):
        """P0/project claims are seated only by an explicit manual trigger."""
        ordinary = make_claim(work_unit)
        elevated = make_claim(work_unit)
        add_claim_to_project(make_project(work_unit), elevated)

        pool = load_unowned_pool(work_unit, project=None)

        assert [c["claim_id"] for c in pool] == [ordinary.id]

    @pytest.mark.parametrize(
        "status", [Project.Status.COMPLETED, Project.Status.CANCELLED]
    )
    def test_daily_run_includes_claims_from_closed_projects(
        self, work_unit, make_claim, make_project, add_claim_to_project, status
    ):
        """Only ACTIVE projects withhold a claim from ordinary allocation."""
        claim = make_claim(work_unit)
        add_claim_to_project(make_project(work_unit, status=status), claim)

        pool = load_unowned_pool(work_unit, project=None)

        assert [c["claim_id"] for c in pool] == [claim.id]

    def test_project_scoped_run_returns_only_that_projects_claims(
        self, work_unit, make_claim, make_project, add_claim_to_project
    ):
        project = make_project(work_unit)
        member = make_claim(work_unit)
        add_claim_to_project(project, member)
        make_claim(work_unit)  # ordinary, not in the project

        pool = load_unowned_pool(work_unit, project=project)

        assert [c["claim_id"] for c in pool] == [member.id]

    def test_project_scoped_run_excludes_other_projects_claims(
        self, work_unit, make_claim, make_project, add_claim_to_project
    ):
        target, other = make_project(work_unit), make_project(work_unit)
        mine = make_claim(work_unit)
        theirs = make_claim(work_unit)
        add_claim_to_project(target, mine)
        add_claim_to_project(other, theirs)

        pool = load_unowned_pool(work_unit, project=target)

        assert [c["claim_id"] for c in pool] == [mine.id]

    def test_project_scoped_run_still_excludes_owned_claims(
        self, work_unit, make_agent, make_claim, make_project,
        add_claim_to_project
    ):
        """Vacancy fill only — a manual project run never displaces."""
        project = make_project(work_unit)
        owned = make_claim(work_unit, current_owner=make_agent(work_unit))
        add_claim_to_project(project, owned)

        assert load_unowned_pool(work_unit, project=project) == []

    def test_claim_in_two_projects_appears_once(
        self, work_unit, make_claim, make_project, add_claim_to_project
    ):
        """The join must not duplicate rows and inflate the pool."""
        claim = make_claim(work_unit)
        add_claim_to_project(make_project(work_unit), claim)
        add_claim_to_project(make_project(work_unit), claim)

        pool = load_unowned_pool(work_unit, project=None)

        assert pool == []  # excluded once, not twice, and no crash


# ── build_engine_input ───────────────────────────────────────────────────────

class TestBuildEngineInput:

    def test_merges_agents_with_their_loads(
        self, work_unit, make_agents, make_claim
    ):
        a, b = make_agents(work_unit, count=2)
        make_claim(work_unit, lifecycle_state=LS.NEW_UNWORKED, current_owner=a)

        data = build_engine_input(work_unit)

        by_id = {x["user_id"]: x["current_load"] for x in data["agents"]}
        assert by_id == {a.id: 1, b.id: 0}

    def test_agent_dicts_match_the_engine_contract(
        self, work_unit, make_agent
    ):
        make_agent(work_unit)

        data = build_engine_input(work_unit)

        assert set(data["agents"][0]) == {"user_id", "current_load"}

    def test_no_agents_returns_empty_lists_without_loading_claims(
        self, work_unit, make_claims
    ):
        make_claims(work_unit, 5)

        data = build_engine_input(work_unit)

        assert data == {"agents": [], "claims": []}

    def test_pool_is_capped_at_total_free_capacity(
        self, work_unit, make_agent, make_claim, make_claims
    ):
        """
        One agent at 58/60 has 2 seats, so at most 2 claims should ever be
        read — this is the guard that makes the run cost scale with seats
        instead of with total unowned inventory.
        """
        agent = make_agent(work_unit)
        for _ in range(58):
            make_claim(work_unit, lifecycle_state=LS.NEW_UNWORKED,
                       current_owner=agent)
        make_claims(work_unit, 50)  # large unowned pool

        data = build_engine_input(work_unit)

        assert data["agents"][0]["current_load"] == 58
        assert len(data["claims"]) == 2

    def test_free_capacity_sums_across_all_agents(
        self, work_unit, make_agents, make_claim, make_claims
    ):
        a, b = make_agents(work_unit, count=2)
        for _ in range(59):
            make_claim(work_unit, lifecycle_state=LS.NEW_UNWORKED,
                       current_owner=a)
        for _ in range(58):
            make_claim(work_unit, lifecycle_state=LS.NEW_UNWORKED,
                       current_owner=b)
        make_claims(work_unit, 40)

        data = build_engine_input(work_unit)

        assert len(data["claims"]) == 3  # 1 free + 2 free

    def test_all_agents_full_returns_no_claims(
        self, work_unit, make_agent, make_claim, make_claims
    ):
        agent = make_agent(work_unit)
        for _ in range(60):
            make_claim(work_unit, lifecycle_state=LS.NEW_UNWORKED,
                       current_owner=agent)
        make_claims(work_unit, 10)

        data = build_engine_input(work_unit)

        assert data["claims"] == []
        assert data["agents"][0]["current_load"] == 60

    def test_over_capacity_agent_does_not_produce_negative_free_capacity(
        self, work_unit, make_agent, make_claim, make_claims
    ):
        """
        An agent may exceed the cap via uncapped Follow-Up Due commitments.
        Negative headroom must clamp to zero, never subtract from the pool
        budget of other agents.
        """
        heavy, light = make_agent(work_unit), make_agent(work_unit)
        for _ in range(70):
            make_claim(work_unit, lifecycle_state=LS.FOLLOW_UP_DUE,
                       current_owner=heavy)
        make_claims(work_unit, 100)

        data = build_engine_input(work_unit)

        loads = {a["user_id"]: a["current_load"] for a in data["agents"]}
        assert loads[heavy.id] == 70
        assert loads[light.id] == 0
        # light contributes all 60 seats; heavy clamps to 0, not -10
        assert len(data["claims"]) == 60

    def test_project_argument_is_passed_through_to_the_pool(
        self, work_unit, make_agent, make_claim, make_project,
        add_claim_to_project
    ):
        make_agent(work_unit)
        project = make_project(work_unit)
        member = make_claim(work_unit)
        add_claim_to_project(project, member)
        make_claim(work_unit)

        data = build_engine_input(work_unit, project=project)

        assert [c["claim_id"] for c in data["claims"]] == [member.id]
