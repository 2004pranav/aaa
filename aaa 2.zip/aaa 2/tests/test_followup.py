"""
test_followup.py — Database tests for the Follow-Up Surfacing workflow.

The followup package does one job: flip owned, active claims from
FOLLOW_UP_SCHEDULED to FOLLOW_UP_DUE once their next_follow_up_date has
arrived, so they reappear in the agent's Active Bucket. It runs as Step 1
of the daily workflow, immediately before allocation, because
load_agent_loads() counts FOLLOW_UP_DUE toward an agent's capacity.

Coverage is organised as:
    - load_surfacing_candidates : each of the five filters, independently
    - date semantics            : overdue / due today / future, date-only
    - surface_claims            : the write, and what it must NOT touch
    - run_surfacing             : dry-run vs live, idempotency, summary shape

Timing note: the suite assumes TIME_ZONE='UTC' with USE_TZ=True, where
`timezone.now().date()` (used by the loader) and the ORM's `__date__`
lookup agree. test_date_only_semantics_ignore_time_of_day pins that
contract, and would start failing if TIME_ZONE moved off UTC without the
loader switching to timezone.localdate().
"""

from datetime import timedelta

import pytest
from django.db.models import QuerySet
from django.utils import timezone

from core.models import Claim
from core.services.followup import run_surfacing
from core.services.followup.loader import load_surfacing_candidates
from core.services.followup.surfacer import surface_claims

pytestmark = pytest.mark.django_db

LS = Claim.LifecycleState


@pytest.fixture
def owner(work_unit, make_agent):
    """An agent who owns the scheduled follow-ups under test."""
    return make_agent(work_unit)


def candidate_ids(work_unit):
    return set(
        load_surfacing_candidates(work_unit).values_list("id", flat=True)
    )


# ── The five membership filters ──────────────────────────────────────────────

class TestSurfacingCandidateFilters:

    def test_finds_an_owned_active_due_scheduled_claim(
        self, work_unit, owner, make_scheduled_claim
    ):
        due = make_scheduled_claim(work_unit, owner, days_offset=-1)

        assert candidate_ids(work_unit) == {due.id}

    def test_excludes_resolved_claims(
        self, work_unit, owner, make_scheduled_claim
    ):
        """A resolved claim must never resurface, whatever its state says."""
        make_scheduled_claim(work_unit, owner, days_offset=-1, is_active=False)

        assert candidate_ids(work_unit) == set()

    def test_excludes_claims_with_uncomputed_is_active(
        self, work_unit, owner, make_scheduled_claim
    ):
        make_scheduled_claim(work_unit, owner, days_offset=-1, is_active=None)

        assert candidate_ids(work_unit) == set()

    def test_excludes_unowned_claims(
        self, work_unit, make_claim
    ):
        """
        Only owned claims can carry a scheduled follow-up. An unowned one
        indicates data drift and must not be surfaced into nobody's bucket.
        """
        make_claim(
            work_unit,
            lifecycle_state=LS.FOLLOW_UP_SCHEDULED,
            current_owner=None,
            next_follow_up_date=timezone.now() - timedelta(days=1),
        )

        assert candidate_ids(work_unit) == set()

    @pytest.mark.parametrize(
        "state", [LS.UNASSIGNED, LS.NEW_UNWORKED, LS.FOLLOW_UP_DUE]
    )
    def test_only_scheduled_claims_are_candidates(
        self, work_unit, owner, make_claim, state
    ):
        """
        Filtering on FOLLOW_UP_SCHEDULED is what makes surfacing idempotent —
        an already-DUE claim is never re-flipped.
        """
        make_claim(
            work_unit,
            lifecycle_state=state,
            current_owner=owner,
            next_follow_up_date=timezone.now() - timedelta(days=1),
        )

        assert candidate_ids(work_unit) == set()

    def test_excludes_claims_with_no_follow_up_date(
        self, work_unit, owner, make_claim
    ):
        """A NULL date can never satisfy <= today, so it stays deferred."""
        make_claim(
            work_unit,
            lifecycle_state=LS.FOLLOW_UP_SCHEDULED,
            current_owner=owner,
            next_follow_up_date=None,
        )

        assert candidate_ids(work_unit) == set()

    def test_is_scoped_to_the_requested_work_unit(
        self, make_work_unit, make_agent, make_scheduled_claim
    ):
        wu_a, wu_b = make_work_unit(), make_work_unit()
        mine = make_scheduled_claim(wu_a, make_agent(wu_a), days_offset=-1)
        make_scheduled_claim(wu_b, make_agent(wu_b), days_offset=-1)

        assert candidate_ids(wu_a) == {mine.id}

    def test_returns_an_unevaluated_queryset(self, work_unit):
        """
        The caller either counts it or hands it to .update(). Returning a
        materialised list would pull every scheduled claim into memory.
        """
        qs = load_surfacing_candidates(work_unit)

        assert isinstance(qs, QuerySet)
        assert qs._result_cache is None


# ── Date semantics ───────────────────────────────────────────────────────────

class TestDateSemantics:

    def test_claim_due_today_surfaces(
        self, work_unit, owner, make_scheduled_claim
    ):
        due = make_scheduled_claim(work_unit, owner, days_offset=0)

        assert candidate_ids(work_unit) == {due.id}

    def test_overdue_claim_surfaces(
        self, work_unit, owner, make_scheduled_claim
    ):
        """Self-healing: a missed run does not strand the follow-up."""
        stale = make_scheduled_claim(work_unit, owner, days_offset=-30)

        assert candidate_ids(work_unit) == {stale.id}

    def test_future_claim_does_not_surface(
        self, work_unit, owner, make_scheduled_claim
    ):
        make_scheduled_claim(work_unit, owner, days_offset=1)

        assert candidate_ids(work_unit) == set()

    def test_date_only_semantics_ignore_time_of_day(
        self, work_unit, owner, make_claim
    ):
        """
        Returns are date-aligned, not timestamp-aligned: a claim due at
        23:59 today is seated by today's run regardless of when the run
        fires. This keeps all bucket churn at run boundaries.
        """
        end_of_today = timezone.now().replace(
            hour=23, minute=59, second=59, microsecond=0
        )
        late = make_claim(
            work_unit,
            lifecycle_state=LS.FOLLOW_UP_SCHEDULED,
            current_owner=owner,
            next_follow_up_date=end_of_today,
        )

        assert candidate_ids(work_unit) == {late.id}

    def test_start_of_tomorrow_does_not_surface(
        self, work_unit, owner, make_claim
    ):
        start_of_tomorrow = (
            timezone.now() + timedelta(days=1)
        ).replace(hour=0, minute=0, second=1, microsecond=0)
        make_claim(
            work_unit,
            lifecycle_state=LS.FOLLOW_UP_SCHEDULED,
            current_owner=owner,
            next_follow_up_date=start_of_tomorrow,
        )

        assert candidate_ids(work_unit) == set()


# ── surface_claims: the write ────────────────────────────────────────────────

class TestSurfaceClaims:

    def test_flips_state_to_follow_up_due(
        self, work_unit, owner, make_scheduled_claim, refresh
    ):
        claim = make_scheduled_claim(work_unit, owner, days_offset=-1)

        surface_claims(load_surfacing_candidates(work_unit))

        assert refresh(claim).lifecycle_state == LS.FOLLOW_UP_DUE

    def test_returns_the_number_of_rows_updated(
        self, work_unit, owner, make_scheduled_claim
    ):
        for _ in range(4):
            make_scheduled_claim(work_unit, owner, days_offset=-1)

        assert surface_claims(load_surfacing_candidates(work_unit)) == 4

    def test_bumps_updated_at(
        self, work_unit, owner, make_scheduled_claim, refresh
    ):
        claim = make_scheduled_claim(work_unit, owner, days_offset=-1)
        before = timezone.now()

        surface_claims(load_surfacing_candidates(work_unit))

        assert refresh(claim).updated_at >= before

    def test_does_not_change_ownership_priority_or_the_follow_up_date(
        self, work_unit, owner, make_scheduled_claim, refresh
    ):
        """
        Surfacing changes *timing visibility* only. Ownership is sticky and
        priority reflects urgency — neither is a surfacing concern.
        """
        claim = make_scheduled_claim(
            work_unit, owner, days_offset=-1, priority_tier="P2"
        )
        original_date = claim.next_follow_up_date

        surface_claims(load_surfacing_candidates(work_unit))

        reloaded = refresh(claim)
        assert reloaded.current_owner_id == owner.id
        assert reloaded.priority_tier == "P2"
        assert reloaded.next_follow_up_date == original_date

    def test_leaves_non_candidates_untouched(
        self, work_unit, owner, make_scheduled_claim, refresh
    ):
        due = make_scheduled_claim(work_unit, owner, days_offset=-1)
        future = make_scheduled_claim(work_unit, owner, days_offset=10)

        surface_claims(load_surfacing_candidates(work_unit))

        assert refresh(due).lifecycle_state == LS.FOLLOW_UP_DUE
        assert refresh(future).lifecycle_state == LS.FOLLOW_UP_SCHEDULED


# ── run_surfacing: the orchestrator ──────────────────────────────────────────

class TestRunSurfacing:

    def test_live_run_surfaces_and_reports(
        self, work_unit, owner, make_scheduled_claim, refresh
    ):
        claim = make_scheduled_claim(work_unit, owner, days_offset=-1)

        summary = run_surfacing(work_unit)

        assert summary["candidates_found"] == 1
        assert summary["claims_surfaced"] == 1
        assert summary["dry_run"] is False
        assert refresh(claim).lifecycle_state == LS.FOLLOW_UP_DUE

    def test_dry_run_counts_but_never_writes(
        self, work_unit, owner, make_scheduled_claim, refresh
    ):
        claim = make_scheduled_claim(work_unit, owner, days_offset=-1)

        summary = run_surfacing(work_unit, dry_run=True)

        assert summary["candidates_found"] == 1
        assert summary["claims_surfaced"] == 0
        assert summary["dry_run"] is True
        assert refresh(claim).lifecycle_state == LS.FOLLOW_UP_SCHEDULED

    def test_no_candidates_returns_a_complete_zero_summary(self, work_unit):
        """The early-return path must produce the same keys as any other."""
        summary = run_surfacing(work_unit)

        assert summary["candidates_found"] == 0
        assert summary["claims_surfaced"] == 0
        assert summary["elapsed_seconds"] >= 0

    def test_summary_contract_keys_are_stable(self, work_unit):
        """allocate_claims.py reads these by name."""
        assert set(run_surfacing(work_unit)) == {
            "work_unit",
            "work_unit_id",
            "candidates_found",
            "claims_surfaced",
            "dry_run",
            "elapsed_seconds",
        }

    def test_is_idempotent_within_the_same_day(
        self, work_unit, owner, make_scheduled_claim
    ):
        """
        A re-run after a partial failure must be safe: already-surfaced
        claims are no longer FOLLOW_UP_SCHEDULED, so they are not candidates.
        """
        make_scheduled_claim(work_unit, owner, days_offset=-1)

        assert run_surfacing(work_unit)["claims_surfaced"] == 1
        assert run_surfacing(work_unit)["claims_surfaced"] == 0

    def test_surfaces_only_the_requested_work_units_claims(
        self, make_work_unit, make_agent, make_scheduled_claim, refresh
    ):
        wu_a, wu_b = make_work_unit(), make_work_unit()
        mine = make_scheduled_claim(wu_a, make_agent(wu_a), days_offset=-1)
        theirs = make_scheduled_claim(wu_b, make_agent(wu_b), days_offset=-1)

        run_surfacing(wu_a)

        assert refresh(mine).lifecycle_state == LS.FOLLOW_UP_DUE
        assert refresh(theirs).lifecycle_state == LS.FOLLOW_UP_SCHEDULED

    def test_surfaces_a_mixed_population_correctly(
        self, work_unit, owner, make_scheduled_claim, make_claim
    ):
        for _ in range(3):
            make_scheduled_claim(work_unit, owner, days_offset=-2)
        for _ in range(2):
            make_scheduled_claim(work_unit, owner, days_offset=+5)
        make_claim(work_unit)                                   # unassigned
        make_claim(work_unit, lifecycle_state=LS.NEW_UNWORKED,
                   current_owner=owner)                          # already active

        summary = run_surfacing(work_unit)

        assert summary["claims_surfaced"] == 3
        assert Claim.objects.filter(
            work_unit=work_unit, lifecycle_state=LS.FOLLOW_UP_DUE
        ).count() == 3


# ── Scale ────────────────────────────────────────────────────────────────────

class TestScale:

    @pytest.mark.slow
    def test_surfaces_a_large_population_in_one_statement(
        self, work_unit, owner
    ):
        """
        Surfacing is a single set-based UPDATE — 2,000 due claims must not
        materialise 2,000 Python objects.
        """
        yesterday = timezone.now() - timedelta(days=1)
        Claim.objects.bulk_create([
            Claim(
                work_unit=work_unit, client=work_unit.client,
                claim_number=f"FU-{i:06d}", is_active=True,
                lifecycle_state=LS.FOLLOW_UP_SCHEDULED,
                current_owner=owner, next_follow_up_date=yesterday,
                priority_tier="P3", aging_days=10,
            )
            for i in range(2000)
        ])

        summary = run_surfacing(work_unit)

        assert summary["claims_surfaced"] == 2000
        assert Claim.objects.filter(
            lifecycle_state=LS.FOLLOW_UP_DUE
        ).count() == 2000
