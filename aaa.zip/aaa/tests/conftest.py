"""
conftest.py — Shared fixtures and object factories for the ARxTracker
allocation + follow-up test suite.

Everything here is a *factory* rather than a fixed fixture, because the
scenarios under test differ mainly in the SHAPE of the data (how many
agents, what lifecycle states, which priority tiers) rather than in the
objects themselves. Factories keep each test's setup explicit and local:
you can read a test top-to-bottom and see exactly which claims exist and
why, without cross-referencing a fixture defined 200 lines away.

Why counters instead of hardcoded codes:
    Client.code, Process.code, SubProcess.code, User.employee_id and
    User.email are all `unique=True`, and WorkUnit has a UniqueConstraint
    on (client, process, sub_process). A test that builds two WorkUnits
    would collide on any hardcoded value. The module-level counters make
    every factory call produce globally unique identifiers, so factories
    compose freely.

Database access:
    Every factory depends on the `db` fixture, so simply requesting a
    factory in a test grants that test database access. Tests that need
    no database (the pure engine tests) request nothing and stay fast.

Note on ClaimAssignment:
    ClaimAssignment.save() raises unconditionally (its append-only guard
    checks `if self.pk`, which is always truthy because `id` has a
    uuid4 default). Fixtures therefore never call .create() on it —
    production code writes it via bulk_create(), and tests only ever
    READ what the committer wrote.
"""

import itertools
import uuid
from datetime import timedelta

import pytest
from django.utils import timezone

from core.models import (
    Claim,
    Client,
    Process,
    Project,
    ProjectClaim,
    SubProcess,
    User,
    UserWorkUnitMapping,
    WorkUnit,
)

# ── Uniqueness counters ──────────────────────────────────────────────────────
# Shared across the whole session so no two factory calls can collide on a
# unique column, no matter how many objects a single test builds.

_client_seq = itertools.count(1)
_process_seq = itertools.count(1)
_subprocess_seq = itertools.count(1)
_user_seq = itertools.count(1)
_claim_seq = itertools.count(1)


# ── Capability helpers ───────────────────────────────────────────────────────

def db_supports_row_locking() -> bool:
    """
    True when the active database can honour SELECT ... FOR UPDATE.

    PostgreSQL (the production target) can; SQLite cannot and silently
    ignores the clause instead of raising. Tests asserting on genuine
    row-locking semantics call skip_without_row_locking() rather than
    pretending to verify something the backend never executed.
    """
    from django.db import connection
    return connection.features.has_select_for_update


@pytest.fixture
def requires_row_locking():
    """
    Skips the requesting test unless the backend supports row locking.

    Exposed as a fixture rather than an importable helper so that no test
    module ever needs to import from conftest by path. A cross-directory
    import (`from tests.conftest import ...`) silently ties the suite to
    one directory layout and breaks the moment the tests are relocated.
    Fixtures are resolved by pytest, so they keep working wherever the
    conftest sits relative to the tests.
    """
    if not db_supports_row_locking():
        pytest.skip(
            "Backend has no SELECT ... FOR UPDATE support (SQLite). "
            "Run against PostgreSQL to exercise real row locking."
        )


# ── Core org-structure factories ─────────────────────────────────────────────

@pytest.fixture
def make_client(db):
    """Creates a Client with a unique code."""
    def _make(name=None, **kwargs):
        n = next(_client_seq)
        return Client.objects.create(
            name=name or f"Test Client {n}",
            code=kwargs.pop("code", f"CL{n}"),
            **kwargs,
        )
    return _make


@pytest.fixture
def make_work_unit(db, make_client):
    """
    Creates a fully-formed WorkUnit (Client + Process + SubProcess).

    Each call produces a brand-new Process/SubProcess pair so that two
    WorkUnits built in the same test never violate the
    (client, process, sub_process) unique constraint.
    """
    def _make(client=None, **kwargs):
        p = next(_process_seq)
        s = next(_subprocess_seq)
        return WorkUnit.objects.create(
            client=client or make_client(),
            process=Process.objects.create(name=f"AR {p}", code=f"AR{p}"),
            sub_process=SubProcess.objects.create(name=f"Loc {s}", code=f"L{s}"),
            **kwargs,
        )
    return _make


@pytest.fixture
def work_unit(make_work_unit):
    """The default WorkUnit used by most tests."""
    return make_work_unit()


# ── User / agent factories ───────────────────────────────────────────────────

@pytest.fixture
def make_user(db):
    """Creates a User with unique employee_id and email. Defaults to role=AR."""
    def _make(role=User.Role.AR, is_active=True, **kwargs):
        n = next(_user_seq)
        return User.objects.create(
            employee_id=kwargs.pop("employee_id", f"E{n:05d}"),
            username=kwargs.pop("username", f"agent{n}"),
            email=kwargs.pop("email", f"agent{n}@example.com"),
            role=role,
            is_active=is_active,
            **kwargs,
        )
    return _make


@pytest.fixture
def make_agent(db, make_user):
    """
    Creates a User AND their UserWorkUnitMapping — i.e. someone the
    allocation engine will consider eligible, unless a flag says otherwise.

    Args:
        work_unit:     the WorkUnit to map them into.
        role:          User.Role — anything other than AR is ineligible.
        user_active:   User.is_active.
        mapping_active: UserWorkUnitMapping.is_active.

    Returns the User.
    """
    def _make(work_unit, role=User.Role.AR, user_active=True,
              mapping_active=True, **kwargs):
        user = make_user(role=role, is_active=user_active, **kwargs)
        UserWorkUnitMapping.objects.create(
            user=user,
            work_unit=work_unit,
            is_active=mapping_active,
        )
        return user
    return _make


@pytest.fixture
def make_agents(make_agent):
    """Creates N eligible AR agents mapped to one WorkUnit."""
    def _make(work_unit, count=3, **kwargs):
        return [make_agent(work_unit, **kwargs) for _ in range(count)]
    return _make


# ── Claim factory ────────────────────────────────────────────────────────────

@pytest.fixture
def make_claim(db):
    """
    Creates a Claim, defaulting to the shape the allocation pool looks for:
    active, unowned, UNASSIGNED.

    `is_active` is explicitly defaulted to True because the model default is
    None (meaning "not yet computed"), and a None claim is invisible to every
    allocation query — an easy and silent way to write a test that passes for
    the wrong reason.
    """
    def _make(work_unit, *, claim_number=None, priority_tier="P3",
              aging_days=10, lifecycle_state=Claim.LifecycleState.UNASSIGNED,
              current_owner=None, is_active=True, next_follow_up_date=None,
              client=None, **kwargs):
        return Claim.objects.create(
            work_unit=work_unit,
            client=client or work_unit.client,
            claim_number=claim_number or f"CLM-{next(_claim_seq):06d}",
            priority_tier=priority_tier,
            aging_days=aging_days,
            lifecycle_state=lifecycle_state,
            current_owner=current_owner,
            is_active=is_active,
            next_follow_up_date=next_follow_up_date,
            **kwargs,
        )
    return _make


@pytest.fixture
def make_claims(make_claim):
    """Creates N claims sharing the same attributes. Returns a list."""
    def _make(work_unit, count, **kwargs):
        return [make_claim(work_unit, **kwargs) for _ in range(count)]
    return _make


@pytest.fixture
def make_scheduled_claim(make_claim):
    """
    Creates an owned claim sitting in FOLLOW_UP_SCHEDULED — the input shape
    the follow-up surfacer looks for.

    `days_offset` is relative to today: negative = overdue (should surface),
    0 = due today (should surface), positive = future (should not).
    """
    def _make(work_unit, owner, days_offset=0, **kwargs):
        return make_claim(
            work_unit,
            lifecycle_state=Claim.LifecycleState.FOLLOW_UP_SCHEDULED,
            current_owner=owner,
            next_follow_up_date=timezone.now() + timedelta(days=days_offset),
            **kwargs,
        )
    return _make


# ── Project factories ────────────────────────────────────────────────────────

@pytest.fixture
def make_project(db):
    """Creates a Project scoped to a WorkUnit. Defaults to ACTIVE."""
    def _make(work_unit, status=Project.Status.ACTIVE, name=None, **kwargs):
        return Project.objects.create(
            work_unit=work_unit,
            client=work_unit.client,
            name=name or f"Project {uuid.uuid4().hex[:8]}",
            status=status,
            **kwargs,
        )
    return _make


@pytest.fixture
def add_claim_to_project(db):
    """Links an existing Claim to an existing Project via ProjectClaim."""
    def _add(project, claim, **kwargs):
        return ProjectClaim.objects.create(
            project=project,
            claim=claim,
            client=claim.client,
            **kwargs,
        )
    return _add


# ── Assertion helpers ────────────────────────────────────────────────────────

@pytest.fixture
def refresh():
    """Reloads a model instance from the database and returns it."""
    def _refresh(obj):
        obj.refresh_from_db()
        return obj
    return _refresh
