"""
loader.py - Database queries for the ARxTracker Allocation Engine.

The only file in the allocation package that imports Django or
touches the database. All queries are READ-only. Writes happen 
exclusively in committer.py

Every function returns plain Python dicts/lists that match the
contract engine.py expects.

Type contract with engine.py:
    - user_id: UUID (from User.id, UUIDField)
    - claim_id: UUID (from Claim.id, aliased via F("id"))
    - All IDs are UUID objects throughout
"""

import logging
from django.db.models import Count, F
from core.services.allocation.engine import DEFAULT_BUCKET_CAP

from core.models import (
    Claim,
    User,
    UserWorkUnitMapping,
    WorkUnit,
    Project,
)

logger = logging.getLogger("arxtracker.allocation")



# Eligible Agents-----------------------------------------------------------

def load_eligible_agents(work_unit: WorkUnit) -> list[dict]:
    """
    Return AR agents eligible for allocation in this WorkUnit.

    Eligible = role AR + active UserWorkUnitMapping + user.is_active
    Team Leads, Managers, Admins, and Leadership are excluded.

    Returns:
        [{"user_id": UUID}, ...]
        One dict per eligible agent. Empty list if none exist.
        The caller (__init__.py) raises NoEligibleAgentsError
        if this returns empty - the loader does not raise.
    """
    agents = list(
        UserWorkUnitMapping.objects.filter(
            work_unit=work_unit,
            is_active=True,
            user__is_active=True,
            user__role=User.Role.AR,
        ).values("user_id")
    )

    logger.info(
        "Loaded %d eligible AR agent(s) for WorkUnit '%s'.",
        len(agents), work_unit,
    )

    return agents



# Agent Loads------------------------------------------------------------

def load_agent_loads(
        work_unit: WorkUnit,
        agent_ids: list,
) -> dict:
    """
    Return the current Active Bucket load per agent

    Active Bucket load = claims where current_owner is this agent
    and lifecycle_state is NEW_UNWORKED or FOLLOW_UP_DUE

    This is a single aggregation query regardless of agent count.
    Agents with zero active claims are initialised at 0.

    Deferred claims (lifecycle_state = FOLLOW_UP_SCHEDULED) are
    NOT counted - they are not in the agent's Active Bucket

    Returns:
        {UUID: int, ...} - agent user_id -> active claim count
    """
    rows = (
        Claim.objects.filter(
            work_unit=work_unit,
            current_owner_id__in=agent_ids,
            is_active=True,
            lifecycle_state__in=[
                Claim.LifecycleState.NEW_UNWORKED,
                Claim.LifecycleState.FOLLOW_UP_DUE,
            ],
        )
        .values("current_owner_id")
        .annotate(load=Count("id"))
    )

    # Initialise all agents at 0 - agents with no active claims 
    # won't appear in the aggregation result
    loads = {agent_id: 0 for agent_id in agent_ids}
    for row in rows:
        loads[row["current_owner_id"]] = row["load"]

    logger.debug(
        "Agent loads for WorkUnit '%s': %s",
        work_unit,
        {str(k): v for k, v in loads.items()}
    )

    return loads



# Unowned Pool------------------------------------------------------------

def load_unowned_pool(
    work_unit: WorkUnit,
    project=None,
    limit: int | None = None,
) -> list[dict]:
    """
    Return unassigned, active claims for distribution.

    These are claims with no current_owner, ready to be assigned
    to an agent's Active Bucket. Pre-sorted by priority_tier ASC
    (P1 first) then aging_days DESC (oldest first).

    Excludes P0/project-elevated claims by default. When
    project is not None (manual Manager trigger), project
    claims are included in the pool.

    Returns:
        [{"claim_id": UUID, "priority_tier": str,
          "aging_days": int}, ...]
        Sorted: P1 first, oldest first within each tier
    """
    qs = Claim.objects.filter(
        work_unit=work_unit,
        current_owner__isnull=True,
        is_active=True,
        lifecycle_state=Claim.LifecycleState.UNASSIGNED,
    )

    if project is not None:
        # Project-scoped run - only claims tagged to this Project
        qs = qs.filter(project_claims__project=project)
    else:
        # Daily run - exclude claims in any ACTIVE Project
        # Claims in completed/cancelled Projects are available
        qs = qs.exclude(
            project_claims__project__status=Project.Status.ACTIVE
        )

    qs = qs.annotate(claim_id=F("id")).order_by(
        "priority_tier", F("aging_days").desc(nulls_last=True)
    )

    if limit is not None:
        qs = qs[:limit]

    pool = list(
        qs.values(
            "claim_id", "priority_tier", "aging_days"
        )
    )

    logger.debug(
        "Loaded %d unowned claim(s) for WorkUnit '%s' "
        "(project=%s).",
        len(pool), work_unit,
        project.name if project else "daily run",
    )

    return pool



# Build Engine Input---------------------------------------------------------------------

def build_engine_input(
        work_unit: WorkUnit,
        project=None,
) -> dict:
    """
    Single entry point that calls all loader functions and 
    assembles the complete input for engine.allocate_claims().

    This is what __init__.py calls. It returns a dict with 
    two keys: "agents" and "claims" - matching the engine's
    two parameters exactly

    The agents list is the list with eligible agents and their
    current loads:
        [{"user_id": UUID, "current_load": int}, ...]

    The claims list is the unowned claim pool:
        [{"claim_id": UUID, "priority_tier": str, "aging_days": int}, ...]
        

    Returns:
        {
            "agents": [{"user_id": UUID, "current_load": int}, ...],
            "claims": [{"claim_id": UUID, ...}, ...],
        }

    Returns empty lists if no agents or no claims exist.
    The caller decides whether empty agents is an error.
    """
    # Step 1: Eligible agents
    agents = load_eligible_agents(work_unit)

    if not agents:
        return {"agents": [], "claims": []}

    agent_ids = [a["user_id"] for a in agents]

    # Step 2: Current loads (one aggregation query)
    loads = load_agent_loads(work_unit, agent_ids)

    # Step 3: Merge agents + loads into engine input format
    engine_agents = [
        {
            "user_id": a["user_id"],
            "current_load": loads.get(a["user_id"], 0),
        }
        for a in agents
    ]

    # Step 3.5: Calculate total free capacity
    bucket_capacity = DEFAULT_BUCKET_CAP

    total_free = sum(
        max(0, bucket_capacity - a["current_load"])
        for a in engine_agents
    )

    # No seats available anywhere
    if total_free <= 0:
        return {
            "agents": engine_agents,
            "claims": [],
        }

    # Step 4: Unowned pool
    claims = load_unowned_pool(
        work_unit=work_unit,
        project=project,
        limit=total_free,
    )

    return {
        "agents": engine_agents,
        "claims": claims,
    }