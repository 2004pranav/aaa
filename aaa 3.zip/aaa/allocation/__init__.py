"""
Allocation Engine - Public Interface

External code imports only from this module.

Orchestration sequence:
    1. Load eligible agents + current loads + unowned pool via loader.py
    2. Run the most-loaded-first algorithm via engine.py
    3. Commit assignments to the database via committer.py
    4. Return a summary dict with counts, timing, and agent details

Trigger Strategy:
    - Scheduled daily run: management command or future scheduler
    - Manual manager trigger: API endpoint or command
    - Never auto-triggered by ingestion or priority evaluation
"""

import logging
import time

from core.services.allocation.engine import DEFAULT_BUCKET_CAP

from core.models import User, WorkUnit
from core.services.allocation.engine import allocate_claims
from core.services.allocation.loader import build_engine_input
from core.services.allocation.committer import commit_assignments
from core.services.allocation.exceptions import NoEligibleAgentsError

logger = logging.getLogger("arxtracker.allocation")


def run_allocation(
        work_unit: WorkUnit,
        project=None,
        dry_run: bool = False,
        assigned_by: User | None = None,
) -> dict:
    """
    Run the allocation engine for a single WorkUnit.

    This is the only function external code should call.
    It orchestrates: loads → compute → commit.

    Args:
        work_unit: The WorkUnit to allocate claims for.

        project: Optional Project instance. When set, only
        claims tagged to this Project are included in the
        pool. When None (default / daily run), claims in 
        any ACTIVE project are excluded from the pool.

        dry_run: If True, run the algorithm and return the
        result without writing to the database. The summary
        shows what would have been assigned.

        assigned_by: The User who triggered this run. Stored
        on each ClaimAssignment for audit. None for scheduled/
        system runs.

    Returns a Summary dict with all the necessary details
    
    Raises:
        NoEligibleAgentsError: if no AR agents are eligible
        for this WorkUnit.
    """
    start = time.time()
    bucket_cap = DEFAULT_BUCKET_CAP
    by_whom = assigned_by.username if assigned_by else "system"
    project_name = project.name if project else None

    logger.info(
        "═══ Allocation run starting for WorkUnit: '%s' "
        "(project=%s, dry_run=%s, triggered_by=%s, "
        "bucket_cap=%d) ═══",
        work_unit, project_name or "daily run",
        dry_run, by_whom, bucket_cap,
    )

    # Step 1: Load from database
    data = build_engine_input(work_unit, project)

    agents = data["agents"]
    claims = data["claims"]

    if not agents:
        raise NoEligibleAgentsError(
            f"No eligible AR agents for WorkUnit '{work_unit}'. "
            f"Assign AR users via UserWorkUnitMapping before "
            f"running allocation."
        )

    logger.info(
        "Loaded %d eligible agent(s), %d unowned claim(s) in the pool.",
        len(agents), len(claims),
    )

    # Step 2: Run the algorithm
    result = allocate_claims(
        agents=agents,
        claims=claims,
        bucket_cap=bucket_cap,
    )

    logger.info(
        "Engine complete: %d assigned, %d unassigned, "
        "%d agent(s) at capacity.",
        result["claims_assigned"],
        result["claims_unassigned"],
        len(result["agents_at_capacity"]),
    )

    # Step 3: Commit to database
    commit_result = {
        "claims_written": 0,
        "claims_skipped": 0,
        "assignments_created": 0,
    }

    if dry_run:
        logger.info(
            "DRY RUN - no writes performed. %d assignment(s) "
            "would have been committed.",
            result["claims_assigned"]
        )
    elif result["claims_assigned"] > 0:
        commit_result = commit_assignments(
            allocation_result=result,
            work_unit=work_unit,
            assigned_by=assigned_by,
        )

        logger.info(
            "Committed: %d written, %d skipped (race guard), "
            "%d ClaimAssignment records created.",
            commit_result["claims_written"],
            commit_result["claims_skipped"],
            commit_result["assignments_created"],
        )
    else:
        logger.info(
            "No assignments to commit (pool empty or all agents are full).",
        )

    # Step 4: Build summary
    elapsed = round(time.time() - start, 3)

    summary = {
        "work_unit": str(work_unit),
        "work_unit_id": work_unit.id,
        "project": project_name,
        "dry_run": dry_run,
        "assigned_by": by_whom,
        "bucket_cap": bucket_cap,

        "agents_eligible": len(agents),
        "pool_size": len(claims),
        "claims_assigned": result["claims_assigned"],
        "claims_unassigned": result["claims_unassigned"],
        "unassigned_claim_ids": result["unassigned_claim_ids"],
        "agents_at_capacity": result["agents_at_capacity"],

        "claims_written": commit_result["claims_written"],
        "claims_skipped": commit_result["claims_skipped"],
        "assignments_created": commit_result["assignments_created"],

        "elapsed_seconds": elapsed,
    }

    logger.info(
        "═══ Allocation run complete for WorkUnit '%s' in %.3fs "
        "— %d assigned, %d written, %d skipped ═══",
        work_unit, elapsed,
        result["claims_assigned"],
        commit_result["claims_written"],
        commit_result["claims_skipped"],
    )

    return summary
