"""
Follow-Up Surfacing - Public Interface/Orchestrator

Orchestration sequence:
    1. loader.py finds claims ready to surface
    2. surfacer.py flips their lifecycle_state
    3. This module orchestrates and returns the summary

Trigger:
    Called by allocate_claims.py management command as Step 1,
    immediately before the allocation engine runs as Step 2.
"""

import logging
import time

from core.models import WorkUnit
from core.services.followup.loader import load_surfacing_candidates
from core.services.followup.surfacer import surface_claims

logger = logging.getLogger("arxtracker.followup")


def run_surfacing(
        work_unit: WorkUnit,
        dry_run: bool = False,
) -> dict:
    """
    Run Follow-Up Surfacing for a Single WorkUnit.

    This is the only function external code should call.
    It orchestrates: load candidates → flip state → return summary.

    Args:
        work_unit: The WorkUnit to surface follow-ups for.

        dry_run: If True, count how many claims would be 
        surfaced but do not write. Useful for preview.

    Returns: A well structured summary dict
    """
    start = time.time()

    logger.info(
        "═══ Follow-Up Surfacing starting for WorkUnit '%s' "
        "(dry_run=%s) ═══",
        work_unit, dry_run,
    )

    # Step 1: Find claims ready to surface
    candidate_qs = load_surfacing_candidates(work_unit)
    candidates_count = candidate_qs.count()

    if candidates_count == 0:
        elapsed = round(time.time() - start, 3)

        logger.info(
            "No claims to surface for WorkUnit '%s'. "
            "Completed in %.3fs. ",
            work_unit, elapsed,
        )

        return {
            "work_unit": str(work_unit),
            "work_unit_id": work_unit.id,
            "candidates_found": 0,
            "claims_surfaced": 0,
            "dry_run": dry_run,
            "elapsed_seconds": elapsed,
        }

    # Step 2: Flip lifecycle_state (or count if dry_run)
    if dry_run:
        surfaced_count = 0

        logger.info(
            "DRY RUN - %d claim(s) would be surfaced for "
            "WorkUnit '%s'. No writes performed.",
            candidates_count, work_unit,
        )
    else:
        surfaced_count = surface_claims(candidate_qs)

        logger.info(
            "Surfaced %d claim(s) for WorkUnit '%s': "
            "FOLLOW_UP_SCHEDULED → FOLLOW_UP_DUE.",
            surfaced_count, work_unit,
        )

    elapsed = round(time.time() - start, 3)

    logger.info(
        "═══ Follow-Up Surfacing complete for WorkUnit '%s' "
        "in %.3fs ═══",
        work_unit, elapsed,
    )

    return {
        "work_unit": str(work_unit),
        "work_unit_id": work_unit.id,
        "candidates_found": candidates_count,
        "claims_surfaced": surfaced_count,
        "dry_run": dry_run,
        "elapsed_seconds": elapsed,
    }
