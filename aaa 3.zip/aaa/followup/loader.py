"""
followup/loader.py - Database queries for Follow-Up Surfacing.

The only file in the followup package that builds database queries.
Returns a queryset (not a list) so the caller can either count it
(dry run) or pass it to surfacer.py for the UPDATE.
"""

import logging
from django.utils import timezone
from core.models import Claim, WorkUnit

logger = logging.getLogger("arxtracker.followup")


def load_surfacing_candidates(
        work_unit: WorkUnit,
):
    """
    Find claims that are ready to surface: scheduled follow-ups
    whose date has arrived.

    Criteria - all five must be true:
        1. work_unit = the specified WorkUnit (tenant isolation)
        2. is_active = True (resolved/archived claims never resurface)
        3. current_owner IS NOT NULL (only owned claims can have 
            scheduled follow-ups)
        4. lifecycle_state = FOLLOW_UP_SCHEDULED
        5. next_follow_up_date <= today (the date has arrived)

    Returns: A Django QuerySet.
    """
    today = timezone.now().date()

    qs = Claim.objects.filter(
        work_unit=work_unit,
        is_active=True,
        current_owner__isnull=False,
        lifecycle_state=Claim.LifecycleState.FOLLOW_UP_SCHEDULED,
        next_follow_up_date__date__lte=today,
    )

    logger.debug(
        "Built surfacing candidate queryset for WorkUnit '%s' "
        "(next_follow_up_date <= %s).",
        work_unit, today,
    )

    return qs