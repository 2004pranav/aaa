"""
surfacer.py - The state flip for Follow-Up Surfacing

Only file in the followup package that writes to the database.

Receives a pre-built queryset from loader.py and executes a single
UPDATE query that flips lifecycle_state from FOLLOW_UP_SCHEDULED
to FOLLOW_UP_DUE
"""

import logging
from core.models import Claim
from django.utils import timezone

logger = logging.getLogger("arxtracker.followup")


def surface_claims(candidate_qs) -> int:
    """
    Flip lifecycle_state from FOLLOW_UP_SCHEDULED to FOLLOW_UP_DUE
    for all claims in the candidate queryset.

    Args:
        candidate_qs: A Django QuerySet of Claim objects to surface.
        Built by loader.load_surfacing_candidates().

    Returns:
        int - the number of claims that were updated. Comes directly
        from Django's .update() return value, which is the row count
        affected by the UPDATE statement.
    """
    surfaced_count = candidate_qs.update(
        lifecycle_state=Claim.LifecycleState.FOLLOW_UP_DUE,
        updated_at=timezone.now()
    )

    logger.debug(
        "Surfaced %d claim(s): FOLLOW_UP_SCHEDULED → FOLLOW_UP_DUE",
        surfaced_count,
    )

    return surfaced_count